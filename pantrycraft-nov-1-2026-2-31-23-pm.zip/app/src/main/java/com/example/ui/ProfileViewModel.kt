package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DietaryProfile
import com.example.data.repository.DietaryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ProfileUiState {
    data object Loading : ProfileUiState
    data class Success(val profile: DietaryProfile) : ProfileUiState
    data class Error(val message: String) : ProfileUiState
}

class ProfileViewModel(
    private val repository: DietaryRepository
) : ViewModel() {

    private val _draftProfile = MutableStateFlow(DietaryProfile())
    val draftProfile = _draftProfile.asStateFlow()

    private val _saveStatus = MutableStateFlow<String?>(null)
    val saveStatus = _saveStatus.asStateFlow()

    val uiState: StateFlow<ProfileUiState> = repository.observeDietaryProfile()
        .map<DietaryProfile?, ProfileUiState> { profile ->
            val resolved = profile ?: DietaryProfile(
                diets = emptyList(),
                allergies = emptyList(),
                dislikes = emptyList(),
                calorieTarget = 2000,
                servingsPreference = 2,
                cookingTimePreference = "Under 30 mins"
            )
            _draftProfile.value = resolved
            ProfileUiState.Success(resolved)
        }
        .catch { error ->
            emit(ProfileUiState.Error(error.localizedMessage ?: "Failed to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = ProfileUiState.Loading
        )

    fun toggleDiet(diet: String) {
        val current = _draftProfile.value.diets.toMutableList()
        if (current.contains(diet)) {
            current.remove(diet)
        } else {
            current.add(diet)
        }
        _draftProfile.value = _draftProfile.value.copy(diets = current)
    }

    fun toggleAllergy(allergy: String) {
        val current = _draftProfile.value.allergies.toMutableList()
        if (current.contains(allergy)) {
            current.remove(allergy)
        } else {
            current.add(allergy)
        }
        _draftProfile.value = _draftProfile.value.copy(allergies = current)
    }

    fun addDislike(item: String) {
        val trimmed = item.trim()
        if (trimmed.isNotBlank() && !_draftProfile.value.dislikes.contains(trimmed)) {
            _draftProfile.value = _draftProfile.value.copy(
                dislikes = _draftProfile.value.dislikes + trimmed
            )
        }
    }

    fun removeDislike(item: String) {
        _draftProfile.value = _draftProfile.value.copy(
            dislikes = _draftProfile.value.dislikes.filterNot { it.equals(item, ignoreCase = true) }
        )
    }

    fun setCalorieTarget(target: Int) {
        _draftProfile.value = _draftProfile.value.copy(calorieTarget = target.coerceIn(800, 5000))
    }

    fun setServings(servings: Int) {
        _draftProfile.value = _draftProfile.value.copy(servingsPreference = servings.coerceIn(1, 12))
    }

    fun setCookingTime(time: String) {
        _draftProfile.value = _draftProfile.value.copy(cookingTimePreference = time)
    }

    fun setChefName(name: String) {
        _draftProfile.value = _draftProfile.value.copy(chefName = name.trim().ifBlank { "Chef" })
    }

    fun saveProfile() {
        viewModelScope.launch {
            try {
                repository.saveDietaryProfile(_draftProfile.value)
                _saveStatus.value = "Dietary preferences saved successfully!"
            } catch (e: Exception) {
                _saveStatus.value = "Failed to save: ${e.message}"
            }
        }
    }

    fun clearSaveStatus() {
        _saveStatus.value = null
    }
}
