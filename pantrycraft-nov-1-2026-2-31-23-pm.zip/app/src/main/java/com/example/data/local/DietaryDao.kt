package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DietaryProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface DietaryDao {
    @Query("SELECT * FROM dietary_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<DietaryProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: DietaryProfile)
}
