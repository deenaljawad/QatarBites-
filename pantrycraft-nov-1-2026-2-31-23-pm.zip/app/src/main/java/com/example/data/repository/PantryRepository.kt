package com.example.data.repository

import android.content.Context
import com.example.data.local.PantryCraftDatabase
import com.example.data.local.PantryDao
import com.example.data.model.PantryItem
import kotlinx.coroutines.flow.Flow

class PantryRepository(
    private val pantryDao: PantryDao
) {
    constructor(context: Context) : this(
        PantryCraftDatabase.getDatabase(context).pantryDao()
    )

    fun observePantryItems(): Flow<List<PantryItem>> = pantryDao.getAll()

    suspend fun addPantryItem(name: String, category: String, quantity: String, expiryDate: String = ""): Long {
        val item = PantryItem(
            name = name.trim(),
            category = category.trim(),
            quantity = quantity.trim(),
            expiryDate = expiryDate.trim(),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        return pantryDao.insert(item)
    }

    suspend fun updatePantryItem(item: PantryItem) {
        pantryDao.update(item.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deletePantryItem(itemId: Long) {
        pantryDao.deleteById(itemId)
    }

    suspend fun seedStarterPantry() {
        val starterItems = listOf(
            Triple("Olive Oil", "Pantry Staples", "500ml"),
            Triple("Garlic", "Produce", "1 bulb"),
            Triple("Yellow Onion", "Produce", "2 pcs"),
            Triple("Eggs", "Dairy & Eggs", "6 pcs"),
            Triple("Chicken Breast", "Proteins", "400g"),
            Triple("Jasmine Rice", "Grains & Pasta", "1 kg"),
            Triple("Penne Pasta", "Grains & Pasta", "500g"),
            Triple("Crushed Tomatoes", "Canned Goods", "1 can (400g)"),
            Triple("Butter", "Dairy & Eggs", "200g"),
            Triple("Black Pepper", "Spices & Seasoning", "1 container"),
            Triple("Sea Salt", "Spices & Seasoning", "1 container"),
            Triple("Soy Sauce", "Sauces & Condiments", "250ml")
        ).map { (name, cat, qty) ->
            PantryItem(
                name = name,
                category = cat,
                quantity = qty,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
        }
        pantryDao.insertAll(starterItems)
    }
}
