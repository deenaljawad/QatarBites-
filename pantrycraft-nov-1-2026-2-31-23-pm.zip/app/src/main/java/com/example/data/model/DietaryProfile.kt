package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dietary_profile")
data class DietaryProfile(
    @PrimaryKey val id: Int = 1,
    val chefName: String = "Chef",
    val diets: List<String> = emptyList(),
    val allergies: List<String> = emptyList(),
    val dislikes: List<String> = emptyList(),
    val calorieTarget: Int = 2000,
    val servingsPreference: Int = 2,
    val cookingTimePreference: String = "Under 30 mins",
    val updatedAt: Long = System.currentTimeMillis()
)
