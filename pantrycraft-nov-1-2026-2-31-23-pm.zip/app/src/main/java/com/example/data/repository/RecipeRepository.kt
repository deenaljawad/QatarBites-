package com.example.data.repository

import android.content.Context
import com.example.data.local.PantryCraftDatabase
import com.example.data.local.RecipeDao
import com.example.data.model.Recipe
import kotlinx.coroutines.flow.Flow

class RecipeRepository(
    private val recipeDao: RecipeDao
) {
    constructor(context: Context) : this(
        PantryCraftDatabase.getDatabase(context).recipeDao()
    )

    fun observeRecipes(): Flow<List<Recipe>> = recipeDao.getAll()

    suspend fun saveRecipe(recipe: Recipe): Long {
        return recipeDao.insert(
            recipe.copy(
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun toggleFavorite(recipe: Recipe) {
        recipeDao.update(
            recipe.copy(
                isFavorite = !recipe.isFavorite,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updatePlannedDate(recipe: Recipe, plannedDate: String) {
        recipeDao.update(
            recipe.copy(
                plannedDate = plannedDate,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteRecipe(recipeId: Long) {
        recipeDao.deleteById(recipeId)
    }
}
