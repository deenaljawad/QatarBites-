package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipes")
data class Recipe(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String = "",
    val description: String = "",
    val mealType: String = "Dinner",
    val prepTime: Int = 15,
    val cookTime: Int = 25,
    val servings: Int = 2,
    val calories: Int = 450,
    val protein: Int = 30,
    val carbs: Int = 40,
    val fat: Int = 15,
    val ingredients: List<String> = emptyList(),
    val instructions: List<String> = emptyList(),
    val matchingPantryIngredients: List<String> = emptyList(),
    val missingIngredients: List<String> = emptyList(),
    val isFavorite: Boolean = false,
    val plannedDate: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
