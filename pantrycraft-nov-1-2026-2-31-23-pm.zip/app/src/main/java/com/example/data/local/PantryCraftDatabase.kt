package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.DietaryProfile
import com.example.data.model.PantryItem
import com.example.data.model.Recipe

@Database(
    entities = [PantryItem::class, DietaryProfile::class, Recipe::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(StringListConverter::class)
abstract class PantryCraftDatabase : RoomDatabase() {
    abstract fun pantryDao(): PantryDao
    abstract fun dietaryDao(): DietaryDao
    abstract fun recipeDao(): RecipeDao

    companion object {
        @Volatile
        private var INSTANCE: PantryCraftDatabase? = null

        fun getDatabase(context: Context): PantryCraftDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PantryCraftDatabase::class.java,
                    "pantry_craft.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
