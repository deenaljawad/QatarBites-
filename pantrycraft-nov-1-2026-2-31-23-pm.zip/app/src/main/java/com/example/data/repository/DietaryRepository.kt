package com.example.data.repository

import android.content.Context
import com.example.data.local.DietaryDao
import com.example.data.local.PantryCraftDatabase
import com.example.data.model.DietaryProfile
import kotlinx.coroutines.flow.Flow

class DietaryRepository(
    private val dietaryDao: DietaryDao
) {
    constructor(context: Context) : this(
        PantryCraftDatabase.getDatabase(context).dietaryDao()
    )

    fun observeDietaryProfile(): Flow<DietaryProfile?> = dietaryDao.getProfile()

    suspend fun saveDietaryProfile(profile: DietaryProfile) {
        dietaryDao.saveProfile(profile.copy(id = 1, updatedAt = System.currentTimeMillis()))
    }
}
