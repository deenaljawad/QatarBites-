package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PantryCraftDatabase
import com.example.data.model.DietaryProfile
import com.example.data.model.Recipe
import com.example.data.repository.DietaryRepository
import com.example.data.repository.PantryRepository
import com.example.data.repository.RecipeRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PantryRepositoryRuleTest {

    private lateinit var database: PantryCraftDatabase
    private lateinit var pantryRepo: PantryRepository
    private lateinit var dietaryRepo: DietaryRepository
    private lateinit var recipeRepo: RecipeRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, PantryCraftDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        pantryRepo = PantryRepository(database.pantryDao())
        dietaryRepo = DietaryRepository(database.dietaryDao())
        recipeRepo = RecipeRepository(database.recipeDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testPantryItemLifecycle() = runBlocking {
        val id = pantryRepo.addPantryItem("Olive Oil", "Pantry", "500ml")
        assertTrue(id > 0)
        val items = pantryRepo.observePantryItems().first { it.isNotEmpty() }
        assertEquals(1, items.size)
        assertEquals("Olive Oil", items[0].name)
        assertEquals("500ml", items[0].quantity)

        val item = items[0]
        pantryRepo.updatePantryItem(item.copy(quantity = "750ml"))
        val updated = pantryRepo.observePantryItems().first { it.any { i -> i.quantity == "750ml" } }
        assertEquals("750ml", updated[0].quantity)

        pantryRepo.deletePantryItem(item.id)
        val empty = pantryRepo.observePantryItems().first { it.isEmpty() }
        assertTrue(empty.isEmpty())
    }

    @Test
    fun testDietaryProfileLifecycle() = runBlocking {
        val profile = DietaryProfile(
            chefName = "Chef Alex",
            diets = listOf("Keto"),
            allergies = listOf("Peanuts"),
            dislikes = listOf("Cilantro"),
            calorieTarget = 2100,
            servingsPreference = 2,
            cookingTimePreference = "Under 30 mins"
        )
        dietaryRepo.saveDietaryProfile(profile)

        val loaded = dietaryRepo.observeDietaryProfile().first { it != null }
        assertNotNull(loaded)
        assertEquals("Chef Alex", loaded?.chefName)
        assertEquals(listOf("Keto"), loaded?.diets)
        assertEquals(2100, loaded?.calorieTarget)
    }

    @Test
    fun testRecipeLifecycle() = runBlocking {
        val recipe = Recipe(
            title = "Lemon Herb Salmon",
            description = "Crispy pan-seared salmon with lemon and dill.",
            mealType = "Dinner",
            prepTime = 10,
            cookTime = 12,
            servings = 2,
            calories = 420,
            protein = 38,
            carbs = 2,
            fat = 26,
            ingredients = listOf("2 salmon fillets", "1 lemon", "Fresh dill", "1 tbsp olive oil"),
            instructions = listOf("Season salmon.", "Sear skin-down for 5 mins.", "Flip and finish with lemon."),
            matchingPantryIngredients = listOf("Olive oil"),
            missingIngredients = listOf("Salmon", "Lemon", "Dill"),
            isFavorite = false
        )
        val id = recipeRepo.saveRecipe(recipe)
        assertTrue(id > 0)

        val recipes = recipeRepo.observeRecipes().first { it.isNotEmpty() }
        assertEquals(1, recipes.size)
        assertEquals("Lemon Herb Salmon", recipes[0].title)

        recipeRepo.toggleFavorite(recipes[0])
        val favRecipes = recipeRepo.observeRecipes().first { it.any { r -> r.isFavorite } }
        assertTrue(favRecipes[0].isFavorite)
    }
}
