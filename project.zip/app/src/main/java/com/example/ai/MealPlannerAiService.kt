package com.example.ai

import android.util.Log
import com.example.data.model.DietaryProfile
import com.example.data.model.Recipe
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "MealPlannerAiService"

data class PlannedDay(
    val dayName: String,
    val dateLabel: String,
    val breakfast: String,
    val lunch: String,
    val dinner: String,
    val pantryIngredientsUsed: List<String>,
    val totalEstimatedCalories: Int
)

data class WeeklyMealPlan(
    val planTitle: String,
    val summary: String,
    val days: List<PlannedDay>
)

class MealPlannerAiService {

    private val recipeSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "The title of the recipe"),
                "description" to Schema.string(description = "A brief 1-2 sentence appetizing description"),
                "mealType" to Schema.string(description = "Meal category: Breakfast, Lunch, Dinner, Snack, or Dessert"),
                "prepTime" to Schema.integer(description = "Preparation time in minutes"),
                "cookTime" to Schema.integer(description = "Cooking time in minutes"),
                "servings" to Schema.integer(description = "Number of servings produced"),
                "calories" to Schema.integer(description = "Estimated calories per serving"),
                "protein" to Schema.integer(description = "Estimated protein in grams per serving"),
                "carbs" to Schema.integer(description = "Estimated carbohydrates in grams per serving"),
                "fat" to Schema.integer(description = "Estimated fat in grams per serving"),
                "ingredients" to Schema.array(
                    items = Schema.string(),
                    description = "Full ingredient list with exact quantities and units"
                ),
                "instructions" to Schema.array(
                    items = Schema.string(),
                    description = "Step-by-step sequential cooking instructions"
                ),
                "matchingPantryIngredients" to Schema.array(
                    items = Schema.string(),
                    description = "Ingredients in this recipe that match items from user's pantry"
                ),
                "missingIngredients" to Schema.array(
                    items = Schema.string(),
                    description = "Ingredients needed for this dish that are NOT in user's pantry"
                )
            )
        )
    }

    private val weeklyPlanSchema by lazy {
        val daySchema = Schema.obj(
            properties = mapOf(
                "dayName" to Schema.string(description = "Day of week (e.g. Monday, Tuesday)"),
                "dateLabel" to Schema.string(description = "Day index label (e.g. Day 1, Day 2)"),
                "breakfast" to Schema.string(description = "Breakfast recipe name & brief highlight"),
                "lunch" to Schema.string(description = "Lunch recipe name & brief highlight"),
                "dinner" to Schema.string(description = "Dinner recipe name & brief highlight"),
                "pantryIngredientsUsed" to Schema.array(
                    items = Schema.string(),
                    description = "Key pantry items used on this day"
                ),
                "totalEstimatedCalories" to Schema.integer(description = "Estimated total daily calories")
            )
        )
        Schema.obj(
            properties = mapOf(
                "planTitle" to Schema.string(description = "Catchy title for the meal plan"),
                "summary" to Schema.string(description = "Nutrition and pantry efficiency summary"),
                "days" to Schema.array(
                    items = daySchema,
                    description = "Day-by-day meal schedule"
                )
            )
        )
    }

    private val recipeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = recipeSchema
            }
        )
    }

    private val weeklyPlanModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = weeklyPlanSchema
            }
        )
    }

    suspend fun generateRecipe(
        pantryItems: List<String>,
        dietaryProfile: DietaryProfile?,
        mealType: String,
        targetPrepTime: String,
        cravingsNote: String,
        strictPantryOnly: Boolean
    ): Recipe = withContext(Dispatchers.IO) {
        val pantryListStr = if (pantryItems.isEmpty()) {
            "No specific pantry items listed (assume basic kitchen staples)."
        } else {
            pantryItems.joinToString(", ")
        }

        val dietsStr = dietaryProfile?.diets?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "None specified"
        val allergiesStr = dietaryProfile?.allergies?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "None"
        val dislikesStr = dietaryProfile?.dislikes?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "None"
        val calorieTarget = dietaryProfile?.calorieTarget ?: 2000
        val targetServings = dietaryProfile?.servingsPreference ?: 2

        val strictInstruction = if (strictPantryOnly) {
            "STRICT PANTRY MODE: You MUST use ONLY ingredients currently present in the pantry list, plus water, salt, and pepper. Do NOT add missing ingredients unless absolutely unavoidable."
        } else {
            "FLEXIBLE CHEF MODE: Maximize use of pantry items first, but you may recommend 1-3 common missing ingredients if they elevate the dish."
        }

        val prompt = """
            You are an expert executive chef and personalized AI nutritionist.
            Generate a personalized, delicious, and creative recipe with the following constraints:
            - Meal Type: $mealType
            - User's Available Pantry Ingredients: $pantryListStr
            - Target Cook/Prep Time: $targetPrepTime
            - Target Servings: $targetServings
            - Dietary Lifestyles / Restrictions: $dietsStr
            - CRITICAL ALLERGIES TO STRICTLY AVOID: $allergiesStr
            - Disliked Ingredients: $dislikesStr
            - Target Daily Calories Reference: ~$calorieTarget kcal
            - Special Cravings or User Note: ${cravingsNote.ifBlank { "Create something delicious, satisfying, and balanced." }}
            - Mode: $strictInstruction

            Ensure all instructions are clear, descriptive, and easy to follow.
            Accurately populate matchingPantryIngredients (which pantry items are used) and missingIngredients.
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                recipeModel.generateContent(prompt)
            }
            val jsonText = response.text ?: throw IllegalStateException("AI returned an empty response.")
            val json = JSONObject(jsonText)

            val ingredientsJson = json.optJSONArray("ingredients") ?: JSONArray()
            val ingredientsList = (0 until ingredientsJson.length()).map { ingredientsJson.getString(it) }

            val instructionsJson = json.optJSONArray("instructions") ?: JSONArray()
            val instructionsList = (0 until instructionsJson.length()).map { instructionsJson.getString(it) }

            val matchingJson = json.optJSONArray("matchingPantryIngredients") ?: JSONArray()
            val matchingList = (0 until matchingJson.length()).map { matchingJson.getString(it) }

            val missingJson = json.optJSONArray("missingIngredients") ?: JSONArray()
            val missingList = (0 until missingJson.length()).map { missingJson.getString(it) }

            Recipe(
                title = json.optString("title", "Chef's Pantry Special"),
                description = json.optString("description", "A personalized meal crafted from your pantry."),
                mealType = json.optString("mealType", mealType),
                prepTime = json.optInt("prepTime", 15),
                cookTime = json.optInt("cookTime", 20),
                servings = json.optInt("servings", targetServings),
                calories = json.optInt("calories", 450),
                protein = json.optInt("protein", 28),
                carbs = json.optInt("carbs", 35),
                fat = json.optInt("fat", 14),
                ingredients = ingredientsList,
                instructions = instructionsList,
                matchingPantryIngredients = matchingList,
                missingIngredients = missingList,
                isFavorite = false
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Recipe generation timed out", e)
            throw IllegalStateException("Recipe generation timed out after 60 seconds. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Recipe generation failed", e)
            throw IllegalStateException(e.localizedMessage ?: "Failed to generate personalized recipe.")
        }
    }

    suspend fun generateWeeklyMealPlan(
        pantryItems: List<String>,
        dietaryProfile: DietaryProfile?,
        daysCount: Int = 7
    ): WeeklyMealPlan = withContext(Dispatchers.IO) {
        val pantryListStr = if (pantryItems.isEmpty()) {
            "Standard pantry items (oil, eggs, rice, flour, spices, chicken, greens)."
        } else {
            pantryItems.joinToString(", ")
        }
        val dietsStr = dietaryProfile?.diets?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "Balanced"
        val allergiesStr = dietaryProfile?.allergies?.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "None"
        val calorieTarget = dietaryProfile?.calorieTarget ?: 2000

        val prompt = """
            You are a master meal planner and nutritionist.
            Generate a comprehensive $daysCount-day meal plan based on:
            - Available Pantry Ingredients: $pantryListStr
            - Diets: $dietsStr
            - STRICT Allergies to exclude: $allergiesStr
            - Daily Target Calories: ~$calorieTarget kcal
            
            Each day must include Breakfast, Lunch, and Dinner suggestions that heavily utilize the pantry items while preventing food waste.
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                weeklyPlanModel.generateContent(prompt)
            }
            val jsonText = response.text ?: throw IllegalStateException("AI returned an empty response.")
            val json = JSONObject(jsonText)

            val daysJson = json.optJSONArray("days") ?: JSONArray()
            val days = (0 until daysJson.length()).map { idx ->
                val dayObj = daysJson.getJSONObject(idx)
                val usedItemsJson = dayObj.optJSONArray("pantryIngredientsUsed") ?: JSONArray()
                val usedItems = (0 until usedItemsJson.length()).map { usedItemsJson.getString(it) }

                PlannedDay(
                    dayName = dayObj.optString("dayName", "Day ${idx + 1}"),
                    dateLabel = dayObj.optString("dateLabel", "Day ${idx + 1}"),
                    breakfast = dayObj.optString("breakfast", "Healthy Breakfast"),
                    lunch = dayObj.optString("lunch", "Nutritious Lunch"),
                    dinner = dayObj.optString("dinner", "Satisfying Dinner"),
                    pantryIngredientsUsed = usedItems,
                    totalEstimatedCalories = dayObj.optInt("totalEstimatedCalories", calorieTarget)
                )
            }

            WeeklyMealPlan(
                planTitle = json.optString("planTitle", "$daysCount-Day Pantry Meal Plan"),
                summary = json.optString("summary", "A personalized weekly meal schedule designed to utilize your pantry ingredients efficiently."),
                days = days
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Weekly plan generation timed out", e)
            throw IllegalStateException("Meal plan generation timed out after 60 seconds.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Weekly plan generation failed", e)
            throw IllegalStateException(e.localizedMessage ?: "Failed to generate weekly meal plan.")
        }
    }
}
