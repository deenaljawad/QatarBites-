package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.MealPlannerAiService
import com.example.data.repository.DietaryRepository
import com.example.data.repository.PantryRepository
import com.example.data.repository.RecipeRepository
import com.example.ui.MealPlannerViewModel
import com.example.ui.PantryViewModel
import com.example.ui.ProfileViewModel
import com.example.ui.RecipeBookViewModel
import com.example.ui.screens.MainScreen
import com.example.ui.theme.PantryCraftTheme
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            PantryCraftTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRootContent()
                }
            }
        }
    }
}

@Composable
fun AppRootContent() {
    val context = LocalContext.current
    val pantryRepo = remember { PantryRepository(context) }
    val recipeRepo = remember { RecipeRepository(context) }
    val dietaryRepo = remember { DietaryRepository(context) }
    val aiService = remember { MealPlannerAiService() }

    val pantryVm: PantryViewModel = viewModel { PantryViewModel(pantryRepo) }
    val recipeVm: RecipeBookViewModel = viewModel { RecipeBookViewModel(recipeRepo) }
    val profileVm: ProfileViewModel = viewModel { ProfileViewModel(dietaryRepo) }
    val mealPlanVm: MealPlannerViewModel = viewModel { MealPlannerViewModel(aiService, recipeRepo) }

    MainScreen(
        mealPlannerViewModel = mealPlanVm,
        pantryViewModel = pantryVm,
        recipeBookViewModel = recipeVm,
        profileViewModel = profileVm
    )
}
