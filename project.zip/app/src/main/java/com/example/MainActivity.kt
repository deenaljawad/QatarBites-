package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Restaurant
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.components.MatchDialog
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.QatarMapExploreScreen
import com.example.ui.screens.RestaurantDetailSheet
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.QatarGold
import com.example.ui.theme.QatarMaroon
import com.example.ui.theme.QatarBitesTheme

enum class ScreenTab {
    DISCOVER,
    MATCHES,
    MAP_EXPLORE,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            QatarBitesTheme(themeMode = uiState.userPreferences.themeMode) {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isExpanded = maxWidth >= 600.dp
                    MainApp(
                        viewModel = viewModel,
                        uiState = uiState,
                        isExpanded = isExpanded
                    )
                }
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: MainViewModel,
    uiState: MainUiState,
    isExpanded: Boolean
) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(ScreenTab.DISCOVER) }

    // Android back navigation handler
    if (currentTab != ScreenTab.DISCOVER) {
        BackHandler {
            currentTab = ScreenTab.DISCOVER
        }
    }

    val openGoogleMaps: (Restaurant) -> Unit = { restaurant ->
        val gmmIntentUri = Uri.parse("geo:${restaurant.latitude},${restaurant.longitude}?q=${Uri.encode("${restaurant.name}, ${restaurant.area}, Doha")}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
        }
        if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
        } else {
            val webUri = Uri.parse(restaurant.googleMapsUrl)
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    val callRestaurant: (String) -> Unit = { phoneNumber ->
        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${phoneNumber.replace(" ", "")}")
        }
        context.startActivity(dialIntent)
    }

    if (isExpanded) {
        // Tablet / Foldable Expanded Layout with Navigation Rail
        Row(modifier = Modifier.fillMaxSize()) {
            NavigationRail(
                modifier = Modifier.fillMaxHeight(),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface
            ) {
                NavigationRailItem(
                    selected = currentTab == ScreenTab.DISCOVER,
                    onClick = { currentTab = ScreenTab.DISCOVER },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Discover") },
                    label = { Text("Discover") },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = QatarMaroon,
                        selectedTextColor = QatarMaroon,
                        indicatorColor = QatarGold.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_rail_discover")
                )

                NavigationRailItem(
                    selected = currentTab == ScreenTab.MATCHES,
                    onClick = { currentTab = ScreenTab.MATCHES },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (uiState.likedRestaurants.isNotEmpty()) {
                                    Badge(containerColor = QatarMaroon) {
                                        Text("${uiState.likedRestaurants.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = "Saved Matches")
                        }
                    },
                    label = { Text("Matches") },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = QatarMaroon,
                        selectedTextColor = QatarMaroon,
                        indicatorColor = QatarGold.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_rail_matches")
                )

                NavigationRailItem(
                    selected = currentTab == ScreenTab.MAP_EXPLORE,
                    onClick = { currentTab = ScreenTab.MAP_EXPLORE },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Qatar Map") },
                    label = { Text("Map") },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = QatarMaroon,
                        selectedTextColor = QatarMaroon,
                        indicatorColor = QatarGold.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_rail_map")
                )

                NavigationRailItem(
                    selected = currentTab == ScreenTab.SETTINGS,
                    onClick = { currentTab = ScreenTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = QatarMaroon,
                        selectedTextColor = QatarMaroon,
                        indicatorColor = QatarGold.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_rail_settings")
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                when (currentTab) {
                    ScreenTab.DISCOVER -> DiscoverScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        onNavigateToMatches = { currentTab = ScreenTab.MATCHES }
                    )
                    ScreenTab.MATCHES -> MatchesScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        onNavigateToDiscover = { currentTab = ScreenTab.DISCOVER }
                    )
                    ScreenTab.MAP_EXPLORE -> QatarMapExploreScreen(
                        viewModel = viewModel,
                        uiState = uiState
                    )
                    ScreenTab.SETTINGS -> SettingsScreen(
                        viewModel = viewModel,
                        uiState = uiState
                    )
                }
            }
        }
    } else {
        // Standard Mobile Phone Layout with Bottom NavigationBar
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.DISCOVER,
                        onClick = { currentTab = ScreenTab.DISCOVER },
                        icon = { Icon(Icons.Default.Explore, contentDescription = "Discover") },
                        label = { Text("Discover") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QatarMaroon,
                            selectedTextColor = QatarMaroon,
                            indicatorColor = QatarGold.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("bottom_nav_discover")
                    )

                    NavigationBarItem(
                        selected = currentTab == ScreenTab.MATCHES,
                        onClick = { currentTab = ScreenTab.MATCHES },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (uiState.likedRestaurants.isNotEmpty()) {
                                        Badge(containerColor = QatarMaroon) {
                                            Text("${uiState.likedRestaurants.size}")
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Favorite, contentDescription = "Matches")
                            }
                        },
                        label = { Text("Matches") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QatarMaroon,
                            selectedTextColor = QatarMaroon,
                            indicatorColor = QatarGold.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("bottom_nav_matches")
                    )

                    NavigationBarItem(
                        selected = currentTab == ScreenTab.MAP_EXPLORE,
                        onClick = { currentTab = ScreenTab.MAP_EXPLORE },
                        icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                        label = { Text("Qatar Map") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QatarMaroon,
                            selectedTextColor = QatarMaroon,
                            indicatorColor = QatarGold.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("bottom_nav_map")
                    )

                    NavigationBarItem(
                        selected = currentTab == ScreenTab.SETTINGS,
                        onClick = { currentTab = ScreenTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QatarMaroon,
                            selectedTextColor = QatarMaroon,
                            indicatorColor = QatarGold.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("bottom_nav_settings")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    ScreenTab.DISCOVER -> DiscoverScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        onNavigateToMatches = { currentTab = ScreenTab.MATCHES }
                    )
                    ScreenTab.MATCHES -> MatchesScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        onNavigateToDiscover = { currentTab = ScreenTab.DISCOVER }
                    )
                    ScreenTab.MAP_EXPLORE -> QatarMapExploreScreen(
                        viewModel = viewModel,
                        uiState = uiState
                    )
                    ScreenTab.SETTINGS -> SettingsScreen(
                        viewModel = viewModel,
                        uiState = uiState
                    )
                }
            }
        }
    }

    // Match Celebration Modal
    if (uiState.matchedRestaurant != null) {
        MatchDialog(
            restaurant = uiState.matchedRestaurant!!,
            onDismiss = { viewModel.dismissMatchDialog() },
            onOpenMaps = openGoogleMaps,
            onCallRestaurant = callRestaurant
        )
    }

    // Restaurant Detail Bottom Sheet
    if (uiState.detailRestaurant != null) {
        RestaurantDetailSheet(
            restaurant = uiState.detailRestaurant!!,
            onDismiss = { viewModel.dismissRestaurantDetails() },
            onOpenMaps = openGoogleMaps
        )
    }
}
