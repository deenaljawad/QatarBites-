package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Garage
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Garage
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Car
import com.example.ui.components.BrowseScreen
import com.example.ui.components.CarDetailScreen
import com.example.ui.components.ComparisonScreen
import com.example.ui.components.DealsScreen
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.GarageScreen
import com.example.ui.components.MakeOfferDialog
import com.example.ui.components.TestDriveDialog
import com.example.ui.theme.DealOrange
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.CarViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

  private val viewModel: CarViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        AutoVaultApp(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoVaultApp(
  viewModel: CarViewModel
) {
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val filterState by viewModel.filters.collectAsStateWithLifecycle()
  val filteredCars by viewModel.filteredCars.collectAsStateWithLifecycle()
  val dealsCars by viewModel.dealsCars.collectAsStateWithLifecycle()
  val favoriteCars by viewModel.favoriteCars.collectAsStateWithLifecycle()
  val comparisonCars by viewModel.comparisonCars.collectAsStateWithLifecycle()
  val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
  val comparisonIds by viewModel.comparisonIds.collectAsStateWithLifecycle()
  val testDrives by viewModel.testDrives.collectAsStateWithLifecycle()
  val offers by viewModel.offers.collectAsStateWithLifecycle()
  val selectedCar by viewModel.selectedCar.collectAsStateWithLifecycle()
  val dealsBrandFilter by viewModel.dealsBrandFilter.collectAsStateWithLifecycle()

  val isFilterSheetOpen by viewModel.isFilterSheetOpen.collectAsStateWithLifecycle()
  val isTestDriveDialogOpen by viewModel.isTestDriveDialogOpen.collectAsStateWithLifecycle()
  val isMakeOfferDialogOpen by viewModel.isMakeOfferDialogOpen.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }

  // Listen to snackbar messages
  LaunchedEffect(Unit) {
    viewModel.snackbarMessage.collectLatest { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  // Detail screen overlay (if a car is selected)
  if (selectedCar != null) {
    val car = selectedCar!!
    CarDetailScreen(
      car = car,
      isFavorite = favoriteIds.contains(car.id),
      isCompared = comparisonIds.contains(car.id),
      onBack = { viewModel.selectCar(null) },
      onToggleFavorite = { viewModel.toggleFavorite(car) },
      onToggleCompare = { viewModel.toggleComparison(car) },
      onScheduleTestDrive = { viewModel.openTestDriveDialog(car) },
      onMakeOffer = { viewModel.openMakeOfferDialog(car) }
    )
  } else {
    // Main App Shell
    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .windowInsetsPadding(WindowInsets.statusBars),
      snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
      topBar = {
        CenterAlignedTopAppBar(
          title = {
            Text(
              text = when (currentTab) {
                AppTab.BROWSE -> "AutoVault"
                AppTab.DEALS -> "Hot Deals & Offers"
                AppTab.COMPARE -> "Spec Comparison"
                AppTab.GARAGE -> "My Garage"
              },
              fontWeight = FontWeight.Black,
              letterSpacing = 0.5.sp
            )
          },
          colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            titleContentColor = MaterialTheme.colorScheme.onBackground
          )
        )
      },
      bottomBar = {
        NavigationBar(
          modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
          containerColor = MaterialTheme.colorScheme.surface,
          tonalElevation = 6.dp
        ) {
          NavigationBarItem(
            selected = currentTab == AppTab.BROWSE,
            onClick = { viewModel.setTab(AppTab.BROWSE) },
            icon = {
              Icon(
                imageVector = if (currentTab == AppTab.BROWSE) Icons.Filled.DirectionsCar else Icons.Outlined.DirectionsCar,
                contentDescription = "Browse inventory"
              )
            },
            label = { Text("Browse") },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_browse_tab")
          )

          NavigationBarItem(
            selected = currentTab == AppTab.DEALS,
            onClick = { viewModel.setTab(AppTab.DEALS) },
            icon = {
              BadgedBox(
                badge = {
                  Badge(containerColor = DealOrange) {
                    Text("${viewModel.allCars.count { it.isHotDeal }}")
                  }
                }
              ) {
                Icon(
                  imageVector = if (currentTab == AppTab.DEALS) Icons.Filled.LocalFireDepartment else Icons.Outlined.LocalFireDepartment,
                  contentDescription = "Deals"
                )
              }
            },
            label = { Text("Deals") },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = DealOrange,
              indicatorColor = DealOrange.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("nav_deals_tab")
          )

          NavigationBarItem(
            selected = currentTab == AppTab.COMPARE,
            onClick = { viewModel.setTab(AppTab.COMPARE) },
            icon = {
              if (comparisonIds.isNotEmpty()) {
                BadgedBox(
                  badge = {
                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                      Text("${comparisonIds.size}")
                    }
                  }
                ) {
                  Icon(
                    imageVector = Icons.Default.CompareArrows,
                    contentDescription = "Compare"
                  )
                }
              } else {
                Icon(
                  imageVector = Icons.Default.CompareArrows,
                  contentDescription = "Compare"
                )
              }
            },
            label = { Text("Compare") },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_compare_tab")
          )

          NavigationBarItem(
            selected = currentTab == AppTab.GARAGE,
            onClick = { viewModel.setTab(AppTab.GARAGE) },
            icon = {
              if (favoriteIds.isNotEmpty()) {
                BadgedBox(
                  badge = {
                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                      Text("${favoriteIds.size}")
                    }
                  }
                ) {
                  Icon(
                    imageVector = if (currentTab == AppTab.GARAGE) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = "Garage"
                  )
                }
              } else {
                Icon(
                  imageVector = if (currentTab == AppTab.GARAGE) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                  contentDescription = "Garage"
                )
              }
            },
            label = { Text("Garage") },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_garage_tab")
          )
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .background(MaterialTheme.colorScheme.background)
      ) {
        when (currentTab) {
          AppTab.BROWSE -> {
            BrowseScreen(
              cars = filteredCars,
              allCarsList = viewModel.allCars,
              brands = viewModel.allBrands,
              filterState = filterState,
              favoriteIds = favoriteIds,
              comparisonIds = comparisonIds,
              onSearchChange = { viewModel.updateSearchQuery(it) },
              onSelectBrand = { viewModel.selectSingleBrand(it) },
              onToggleDealsOnly = { viewModel.toggleDealsOnly() },
              onOpenFilterSheet = { viewModel.openFilterSheet() },
              onResetFilters = { viewModel.resetFilters() },
              onCarClick = { viewModel.selectCar(it) },
              onFavoriteClick = { viewModel.toggleFavorite(it) },
              onCompareClick = { viewModel.toggleComparison(it) }
            )
          }

          AppTab.DEALS -> {
            DealsScreen(
              dealCars = dealsCars,
              brands = viewModel.allBrands,
              selectedBrand = dealsBrandFilter,
              favoriteIds = favoriteIds,
              comparisonIds = comparisonIds,
              onSelectBrand = { viewModel.setDealsBrandFilter(it) },
              onCarClick = { viewModel.selectCar(it) },
              onFavoriteClick = { viewModel.toggleFavorite(it) },
              onCompareClick = { viewModel.toggleComparison(it) }
            )
          }

          AppTab.COMPARE -> {
            ComparisonScreen(
              cars = comparisonCars,
              onRemoveCar = { viewModel.removeComparison(it) },
              onClearAll = { viewModel.clearComparison() },
              onCarClick = { viewModel.selectCar(it) },
              onBrowseMore = { viewModel.setTab(AppTab.BROWSE) }
            )
          }

          AppTab.GARAGE -> {
            GarageScreen(
              favoriteCars = favoriteCars,
              testDrives = testDrives,
              offers = offers,
              comparisonIds = comparisonIds,
              onCarClick = { viewModel.selectCar(it) },
              onFavoriteClick = { viewModel.toggleFavorite(it) },
              onCompareClick = { viewModel.toggleComparison(it) },
              onBrowseClick = { viewModel.setTab(AppTab.BROWSE) }
            )
          }
        }
      }
    }
  }

  // Filter Bottom Sheet
  if (isFilterSheetOpen) {
    FilterBottomSheet(
      filterState = filterState,
      brands = viewModel.allBrands,
      bodyTypes = viewModel.bodyTypes,
      conditions = viewModel.conditions,
      fuelTypes = viewModel.fuelTypes,
      matchedCount = filteredCars.size,
      onDismiss = { viewModel.closeFilterSheet() },
      onToggleBrand = { viewModel.toggleBrand(it) },
      onToggleDealsOnly = { viewModel.toggleDealsOnly() },
      onPriceRangeChange = { min, max -> viewModel.setPriceRange(min, max) },
      onToggleBodyType = { viewModel.toggleBodyType(it) },
      onToggleCondition = { viewModel.toggleCondition(it) },
      onToggleFuelType = { viewModel.toggleFuelType(it) },
      onSortChange = { viewModel.setSortOption(it) },
      onReset = { viewModel.resetFilters() }
    )
  }

  // Test Drive Dialog
  if (isTestDriveDialogOpen && selectedCar != null) {
    TestDriveDialog(
      car = selectedCar!!,
      onDismiss = { viewModel.closeTestDriveDialog() },
      onConfirm = { date, timeSlot, name, phone ->
        viewModel.submitTestDriveBooking(date, timeSlot, name, phone)
      }
    )
  }

  // Make Offer Dialog
  if (isMakeOfferDialogOpen && selectedCar != null) {
    MakeOfferDialog(
      car = selectedCar!!,
      onDismiss = { viewModel.closeMakeOfferDialog() },
      onSubmitOffer = { amount, hasTradeIn, note ->
        viewModel.submitOffer(amount, hasTradeIn, note)
      }
    )
  }
}
