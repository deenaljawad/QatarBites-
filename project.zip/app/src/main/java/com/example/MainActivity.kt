package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.MealPlannerAiService
import com.example.data.repository.DietaryRepository
import com.example.data.repository.PantryRepository
import com.example.data.repository.RecipeRepository
import com.example.ui.AuthUiState
import com.example.ui.AuthViewModel
import com.example.ui.MealPlannerViewModel
import com.example.ui.PantryViewModel
import com.example.ui.ProfileViewModel
import com.example.ui.RecipeBookViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.MainScreen
import com.example.ui.theme.PantryCraftTheme
import com.example.util.configureAppCheck
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            PantryCraftTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRootContent(authViewModel = authViewModel)
                }
            }
        }
    }
}

@Composable
fun AppRootContent(authViewModel: AuthViewModel) {
    val authState by authViewModel.uiState.collectAsState()

    when (val state = authState) {
        is AuthUiState.Authenticated -> {
            val context = LocalContext.current
            val db = remember {
                FirebaseFirestore.getInstance(
                    context.getString(R.string.firestore_database_id)
                )
            }
            val pantryRepo = remember(db) { PantryRepository(db) }
            val recipeRepo = remember(db) { RecipeRepository(db) }
            val dietaryRepo = remember(db) { DietaryRepository(db) }
            val aiService = remember { MealPlannerAiService() }

            val pantryVm: PantryViewModel = viewModel { PantryViewModel(pantryRepo) }
            val recipeVm: RecipeBookViewModel = viewModel { RecipeBookViewModel(recipeRepo) }
            val profileVm: ProfileViewModel = viewModel { ProfileViewModel(dietaryRepo) }
            val mealPlanVm: MealPlannerViewModel = viewModel { MealPlannerViewModel(aiService, recipeRepo) }

            MainScreen(
                currentUser = state.user,
                authViewModel = authViewModel,
                mealPlannerViewModel = mealPlanVm,
                pantryViewModel = pantryVm,
                recipeBookViewModel = recipeVm,
                profileViewModel = profileVm
            )
        }
        else -> {
            AuthScreen(authViewModel = authViewModel)
        }
    }
}
