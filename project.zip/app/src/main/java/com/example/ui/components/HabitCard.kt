package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FrequencyType
import com.example.data.HabitEntity
import com.example.data.HabitLogEntity
import com.example.ui.theme.EmeraldPrimary

@Composable
fun HabitCard(
    habit: HabitEntity,
    log: HabitLogEntity?,
    onToggleComplete: () -> Unit,
    onIncrement: (Double) -> Unit,
    onEditClick: () -> Unit,
    onTestNotification: () -> Unit,
    modifier: Modifier = Modifier,
    isReorderMode: Boolean = false,
    positionIndex: Int = 1,
    canMoveUp: Boolean = true,
    canMoveDown: Boolean = true,
    onMoveUp: () -> Unit = {},
    onMoveDown: () -> Unit = {}
) {
    val isCompleted = log?.isCompleted ?: false
    val currentValue = log?.value ?: 0.0
    val targetValue = habit.targetValue
    val progressRatio = (currentValue / targetValue).coerceIn(0.0, 1.0).toFloat()

    val habitColor = parseColor(habit.colorHex)

    val animatedProgress by animateFloatAsState(
        targetValue = progressRatio,
        label = "habit_progress"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = if (isCompleted) 1.5.dp else 1.dp,
                color = if (isCompleted) EmeraldPrimary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onEditClick)
            .testTag("habit_card_${habit.id}"),
        color = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f) else MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = if (isCompleted) 0.dp else 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Icon
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(habitColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getHabitIcon(habit.iconName),
                        contentDescription = habit.title,
                        tint = habitColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Title and Frequency / Target Details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = habit.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                        color = if (isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = getFrequencyLabel(habit),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "•",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = formatGoalString(habit.targetValue, habit.unit),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = habitColor
                        )
                    }
                }

                if (isReorderMode) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.padding(end = 2.dp)
                        ) {
                            Text(
                                text = "#$positionIndex",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        IconButton(
                            onClick = onMoveUp,
                            enabled = canMoveUp,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("move_up_habit_${habit.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Move Up",
                                tint = if (canMoveUp) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = onMoveDown,
                            enabled = canMoveDown,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("move_down_habit_${habit.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Move Down",
                                tint = if (canMoveDown) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                } else {
                    // Checkoff Button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = 2.dp,
                                color = if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                                shape = CircleShape
                            )
                            .clickable(onClick = onToggleComplete)
                            .testTag("toggle_habit_${habit.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Completed",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress bar and incremental controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isCompleted) "Completed! (+60 XP)" else "${formatValue(currentValue)} / ${formatValue(targetValue)} ${habit.unit}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isCompleted) FontWeight.Bold else FontWeight.Medium,
                            color = if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "${(progressRatio * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = habitColor,
                        trackColor = MaterialTheme.colorScheme.surface
                    )
                }

                // Incremental "+1" button if habit goal is > 1 unit
                if (targetValue > 1.0) {
                    Spacer(modifier = Modifier.width(12.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = habitColor.copy(alpha = 0.15f),
                        modifier = Modifier
                            .clickable { onIncrement(1.0) }
                            .testTag("increment_habit_${habit.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add 1",
                                tint = habitColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "+1",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = habitColor
                            )
                        }
                    }
                }
            }

            // Reminder status row
            if (habit.reminderEnabled && habit.reminderHour != null && habit.reminderMinute != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Reminder active",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formatTime(habit.reminderHour, habit.reminderMinute),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    // Test Reminder notification trigger
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.clickable(onClick = onTestNotification)
                    ) {
                        Text(
                            text = "Test Reminder",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

fun formatTime(hour: Int, minute: Int): String {
    val amPm = if (hour < 12) "AM" else "PM"
    val displayHour = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
    val displayMinute = String.format("%02d", minute)
    return "$displayHour:$displayMinute $amPm"
}

fun formatGoalString(targetValue: Double, unit: String): String {
    return if (targetValue % 1.0 == 0.0) {
        "${targetValue.toInt()} $unit"
    } else {
        "$targetValue $unit"
    }
}

fun formatValue(v: Double): String {
    return if (v % 1.0 == 0.0) "${v.toInt()}" else "$v"
}

fun getFrequencyLabel(habit: HabitEntity): String {
    return when (habit.frequencyType) {
        FrequencyType.DAILY -> "Daily"
        FrequencyType.WEEKLY -> "Weekly"
        FrequencyType.MONTHLY -> "Monthly"
        FrequencyType.SPECIFIC_DAYS -> {
            val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
            habit.targetDaysOfWeek.mapNotNull { dayIndex ->
                if (dayIndex in 1..7) dayNames[dayIndex - 1] else null
            }.joinToString(", ")
        }
    }
}

fun getHabitIcon(iconName: String): ImageVector {
    return when (iconName) {
        "fitness" -> Icons.Default.FitnessCenter
        "run" -> Icons.Default.DirectionsRun
        "water" -> Icons.Default.WaterDrop
        "book" -> Icons.Default.MenuBook
        "meditation" -> Icons.Default.SelfImprovement
        else -> Icons.Default.FitnessCenter
    }
}

fun parseColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        EmeraldPrimary
    }
}
