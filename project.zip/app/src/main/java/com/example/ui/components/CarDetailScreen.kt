package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.ui.theme.DealGreen
import com.example.ui.theme.DealOrange
import com.example.ui.theme.DealRed
import com.example.ui.theme.ElectricBlue
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CarDetailScreen(
  car: Car,
  isFavorite: Boolean,
  isCompared: Boolean,
  onBack: () -> Unit,
  onToggleFavorite: () -> Unit,
  onToggleCompare: () -> Unit,
  onScheduleTestDrive: () -> Unit,
  onMakeOffer: () -> Unit,
  modifier: Modifier = Modifier
) {
  // BackHandler to satisfy navigation guidelines
  BackHandler {
    onBack()
  }

  val scrollState = rememberScrollState()

  // Financing calculator state
  var downPaymentPercent by remember { mutableFloatStateOf(0.15f) }
  var loanTermMonths by remember { mutableIntStateOf(60) }

  val downPaymentAmount = car.price * downPaymentPercent
  val principal = car.price - downPaymentAmount
  val monthlyInterestRate = 0.055 / 12
  val calculatedMonthly = remember(principal, loanTermMonths) {
    val rate = monthlyInterestRate
    val n = loanTermMonths.toDouble()
    val payment = principal * (rate * Math.pow(1 + rate, n)) / (Math.pow(1 + rate, n) - 1)
    payment.toInt()
  }

  Box(modifier = modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(bottom = 90.dp) // Leave space for sticky bottom CTA bar
    ) {
      // Hero Header with Canvas styling
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
          .background(
            Brush.verticalGradient(
              listOf(
                Color(car.gradientColors.getOrElse(0) { 0xFF1E293B }),
                Color(car.gradientColors.getOrElse(1) { 0xFF0F172A })
              )
            )
          )
      ) {
        // Futuristic car silhouette canvas
        Canvas(modifier = Modifier.matchParentSize()) {
          val w = size.width
          val h = size.height

          // Soft lighting
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color.White.copy(alpha = 0.18f), Color.Transparent),
              center = Offset(w * 0.5f, h * 0.45f),
              radius = w * 0.45f
            )
          )

          // Sports car contour
          val carPath = Path().apply {
            moveTo(w * 0.08f, h * 0.70f)
            cubicTo(w * 0.25f, h * 0.68f, w * 0.35f, h * 0.36f, w * 0.60f, h * 0.38f)
            cubicTo(w * 0.75f, h * 0.39f, w * 0.88f, h * 0.56f, w * 0.94f, h * 0.62f)
            lineTo(w * 0.94f, h * 0.72f)
          }
          drawPath(
            path = carPath,
            color = Color.White.copy(alpha = 0.35f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4.dp.toPx())
          )

          // Ground reflection line
          drawLine(
            color = Color.White.copy(alpha = 0.2f),
            start = Offset(0f, h * 0.78f),
            end = Offset(w, h * 0.78f),
            strokeWidth = 2.dp.toPx()
          )

          // Wheel circles
          drawCircle(
            color = Color.White.copy(alpha = 0.35f),
            center = Offset(w * 0.26f, h * 0.78f),
            radius = 24.dp.toPx(),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
          )
          drawCircle(
            color = Color.White.copy(alpha = 0.35f),
            center = Offset(w * 0.78f, h * 0.78f),
            radius = 24.dp.toPx(),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
          )
        }

        // Top Navigation & Action icons
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.5f),
            modifier = Modifier.size(42.dp)
          ) {
            IconButton(
              onClick = onBack,
              modifier = Modifier.testTag("detail_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back to listings",
                tint = Color.White
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Compare action
            Surface(
              shape = CircleShape,
              color = if (isCompared) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.5f),
              modifier = Modifier.size(42.dp)
            ) {
              IconButton(
                onClick = onToggleCompare,
                modifier = Modifier.testTag("detail_compare_button")
              ) {
                Icon(
                  imageVector = if (isCompared) Icons.Default.Check else Icons.Default.CompareArrows,
                  contentDescription = "Compare",
                  tint = Color.White
                )
              }
            }

            // Favorite action
            Surface(
              shape = CircleShape,
              color = Color.Black.copy(alpha = 0.5f),
              modifier = Modifier.size(42.dp)
            ) {
              val favTint by animateColorAsState(
                targetValue = if (isFavorite) DealRed else Color.White,
                label = "favTint"
              )
              IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.testTag("detail_favorite_button")
              ) {
                Icon(
                  imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                  contentDescription = "Bookmark",
                  tint = favTint
                )
              }
            }
          }
        }

        // Bottom condition pill on hero
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color.Black.copy(alpha = 0.6f),
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = "${car.condition} • VIN: ${car.vin}",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color.White
            )
          }
        }
      }

      // Main Detail Content
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Brand & Title
        Text(
          text = "${car.year} ${car.brand.uppercase()}",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          letterSpacing = 1.sp
        )
        Text(
          text = car.model,
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Black,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = car.trim,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Hot Deal Banner if on deal
        if (car.isHotDeal) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = DealOrange.copy(alpha = 0.12f),
            border = androidx.compose.foundation.BorderStroke(1.dp, DealOrange.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Surface(
                shape = CircleShape,
                color = DealOrange,
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }

              Column {
                Text(
                  text = car.dealBadge ?: "HOT DEAL",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = DealOrange
                )
                Text(
                  text = "Discounted $${String.format(Locale.US, "%,.0f", car.discountAmount)} (${car.discountPercent}% off MSRP). Limited inventory incentive.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        // Price Overview Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              if (car.originalPrice != null && car.originalPrice > car.price) {
                Text(
                  text = "MSRP: $${String.format(Locale.US, "%,.0f", car.originalPrice)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textDecoration = TextDecoration.LineThrough
                )
              }
              Text(
                text = "$${String.format(Locale.US, "%,.0f", car.price)}",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "Vehicle Cash Price (Excl. Tax & Reg)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "Estimated Payment",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = "$$calculatedMonthly/mo",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "${loanTermMonths}mo @ 5.5% APR",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Performance & Technical Specs Grid
        Text(
          text = "PERFORMANCE & SPECIFICATIONS",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            DetailSpecCard(title = "0-60 MPH", value = "${car.zeroToSixty}s", subtitle = "Acceleration", modifier = Modifier.weight(1f))
            DetailSpecCard(title = "HORSEPOWER", value = "${car.horsepower} HP", subtitle = "Max Output", modifier = Modifier.weight(1f))
            DetailSpecCard(title = "TOP SPEED", value = "${car.topSpeed} MPH", subtitle = "Governed", modifier = Modifier.weight(1f))
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            DetailSpecCard(title = "DRIVETRAIN", value = car.drivetrain, subtitle = "Traction", modifier = Modifier.weight(1f))
            DetailSpecCard(title = "EFFICIENCY", value = car.rangeOrMpg, subtitle = "Combined", modifier = Modifier.weight(1f))
            DetailSpecCard(title = "ODOMETER", value = if (car.mileage == 0) "New" else "${String.format(Locale.US, "%,d", car.mileage)} mi", subtitle = "Miles", modifier = Modifier.weight(1f))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Additional Specs Info
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            SpecRowItem(label = "Engine / Powertrain", value = car.fuelType)
            SpecRowItem(label = "Transmission", value = car.transmission)
            SpecRowItem(label = "Exterior Color", value = car.exteriorColor)
            SpecRowItem(label = "Interior Finish", value = car.interiorColor)
            SpecRowItem(label = "Body Architecture", value = car.bodyType)
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Interactive Financing & Payment Calculator
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Calculate,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "Interactive Payment Calculator",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "Down Payment (${(downPaymentPercent * 100).toInt()}%)",
                style = MaterialTheme.typography.bodyMedium
              )
              Text(
                text = "$${String.format(Locale.US, "%,.0f", downPaymentAmount)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Slider(
              value = downPaymentPercent,
              onValueChange = { downPaymentPercent = it },
              valueRange = 0f..0.40f,
              steps = 7,
              colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary),
              modifier = Modifier.testTag("down_payment_slider")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Loan Duration:",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              listOf(36, 48, 60, 72).forEach { term ->
                FilterChip(
                  selected = loanTermMonths == term,
                  onClick = { loanTermMonths = term },
                  label = { Text("${term} Mo") },
                  modifier = Modifier.weight(1f)
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Estimated Monthly Installment",
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Medium
                )
                Text(
                  text = "$$calculatedMonthly / mo",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Black,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Features & Packages
        Text(
          text = "KEY EQUIPMENT & PACKAGES",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          car.features.forEach { feature ->
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
              border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(14.dp)
                )
                Text(
                  text = feature,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Medium,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Description
        Text(
          text = "VEHICLE OVERVIEW",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = car.description,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Dealer Info Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Text(
                    text = car.dealerName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified Dealer",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                  )
                }
                Text(
                  text = car.dealerLocation,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                modifier = Modifier.size(40.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Call Dealer",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Direct Hotline: ${car.dealerPhone}",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }

    // Sticky Bottom CTA Action Bar
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .navigationBarsPadding(),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp,
      shadowElevation = 12.dp,
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = onMakeOffer,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("make_offer_action_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(
            text = "Make an Offer",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }

        Button(
          onClick = onScheduleTestDrive,
          modifier = Modifier
            .weight(1.3f)
            .height(48.dp)
            .testTag("schedule_test_drive_action_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(
            imageVector = Icons.Default.DirectionsCar,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Book Test Drive",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }
      }
    }
  }
}

@Composable
private fun DetailSpecCard(
  title: String,
  value: String,
  subtitle: String,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
  ) {
    Column(
      modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Composable
private fun SpecRowItem(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}
