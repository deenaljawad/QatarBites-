package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.PantryItem
import com.example.data.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface PantryUiState {
    data object Loading : PantryUiState
    data class Success(
        val items: List<PantryItem>,
        val filteredItems: List<PantryItem>,
        val categories: List<String>,
        val selectedCategory: String?,
        val searchQuery: String,
        val selectedItemNames: Set<String>
    ) : PantryUiState
    data class Error(val message: String) : PantryUiState
}

class PantryViewModel(
    private val repository: PantryRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _selectedItemNames = MutableStateFlow<Set<String>>(emptySet())
    val selectedItemNames = _selectedItemNames.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage = _actionMessage.asStateFlow()

    val uiState: StateFlow<PantryUiState> = combine(
        repository.observePantryItems(),
        _searchQuery,
        _selectedCategory,
        _selectedItemNames
    ) { items, query, category, selectedNames ->
        val categories = items.map { it.category }.distinct().sorted()
        val filtered = items.filter { item ->
            val matchesCat = category == null || item.category.equals(category, ignoreCase = true)
            val matchesQuery = query.isBlank() || item.name.contains(query, ignoreCase = true)
            matchesCat && matchesQuery
        }
        PantryUiState.Success(
            items = items,
            filteredItems = filtered,
            categories = categories,
            selectedCategory = category,
            searchQuery = query,
            selectedItemNames = selectedNames
        ) as PantryUiState
    }.catch { error ->
        emit(PantryUiState.Error(error.localizedMessage ?: "Failed to load pantry items"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = PantryUiState.Loading
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String?) {
        _selectedCategory.value = category
    }

    fun toggleItemSelection(name: String) {
        val current = _selectedItemNames.value.toMutableSet()
        if (current.contains(name)) {
            current.remove(name)
        } else {
            current.add(name)
        }
        _selectedItemNames.value = current
    }

    fun selectAll() {
        val state = uiState.value
        if (state is PantryUiState.Success) {
            _selectedItemNames.value = state.items.map { it.name }.toSet()
        }
    }

    fun clearSelection() {
        _selectedItemNames.value = emptySet()
    }

    fun addItem(name: String, category: String, quantity: String, expiryDate: String = "") {
        viewModelScope.launch {
            try {
                repository.addPantryItem(name, category, quantity, expiryDate)
                _actionMessage.value = "Added '$name' to your pantry"
            } catch (e: Exception) {
                _actionMessage.value = "Error adding item: ${e.message}"
            }
        }
    }

    fun updateItem(item: PantryItem) {
        viewModelScope.launch {
            try {
                repository.updatePantryItem(item)
                _actionMessage.value = "Updated '${item.name}'"
            } catch (e: Exception) {
                _actionMessage.value = "Error updating item: ${e.message}"
            }
        }
    }

    fun deleteItem(itemId: String, name: String) {
        viewModelScope.launch {
            try {
                repository.deletePantryItem(itemId)
                _actionMessage.value = "Removed '$name' from pantry"
            } catch (e: Exception) {
                _actionMessage.value = "Error deleting item: ${e.message}"
            }
        }
    }

    fun seedStarterPantry() {
        viewModelScope.launch {
            try {
                repository.seedStarterPantry()
                _actionMessage.value = "Populated 12 pantry kitchen essentials!"
            } catch (e: Exception) {
                _actionMessage.value = "Error adding starter items: ${e.message}"
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }
}
