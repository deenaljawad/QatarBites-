package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AppSettings
import com.example.data.local.AppThemeMode
import com.example.data.local.CredentialRepository
import com.example.data.local.SavedCredential
import com.example.data.local.SettingsManager
import com.example.domain.GeneratorOptions
import com.example.domain.PasswordEvaluation
import com.example.domain.PasswordGenerator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CredentialRepository
    private val settingsManager: SettingsManager

    init {
        val db = AppDatabase.getInstance(application)
        repository = CredentialRepository(db.credentialDao())
        settingsManager = SettingsManager(application)
    }

    // --- Settings State ---
    val settingsState: StateFlow<AppSettings> = settingsManager.settingsState

    // --- Generator State ---
    private val _generatorOptions = MutableStateFlow(GeneratorOptions(length = 16))
    val generatorOptions: StateFlow<GeneratorOptions> = _generatorOptions.asStateFlow()

    private val _generatedPassword = MutableStateFlow("")
    val generatedPassword: StateFlow<String> = _generatedPassword.asStateFlow()

    private val _passwordEvaluation = MutableStateFlow(PasswordGenerator.evaluate(""))
    val passwordEvaluation: StateFlow<PasswordEvaluation> = _passwordEvaluation.asStateFlow()

    // --- Search & Filter State ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // --- Revealed Credentials (Session Map) ---
    private val _revealedIds = MutableStateFlow<Set<Long>>(emptySet())
    val revealedIds: StateFlow<Set<Long>> = _revealedIds.asStateFlow()

    // --- Toast / Feedback ---
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Removed automatic generation on startup so app launches in clean, pristine state

    // --- Filtered Credentials Flow ---
    @OptIn(ExperimentalCoroutinesApi::class)
    val savedCredentials: StateFlow<List<SavedCredential>> = _searchQuery
        .flatMapLatest { query ->
            repository.searchCredentials(query)
        }
        .combine(_selectedCategory) { list, category ->
            if (category == "All") {
                list
            } else {
                list.filter { it.category.equals(category, ignoreCase = true) }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Generator Actions ---
    fun generatePassword() {
        val pwd = PasswordGenerator.generate(_generatorOptions.value)
        _generatedPassword.value = pwd
        _passwordEvaluation.value = PasswordGenerator.evaluate(pwd)
    }

    fun clearGeneratedPassword() {
        _generatedPassword.value = ""
        _passwordEvaluation.value = PasswordGenerator.evaluate("")
    }

    fun setLength(length: Int) {
        val clamped = length.coerceIn(6, 64)
        _generatorOptions.value = _generatorOptions.value.copy(length = clamped)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun toggleUppercase(value: Boolean) {
        if (!value && !_generatorOptions.value.includeLowercase && !_generatorOptions.value.includeNumbers && !_generatorOptions.value.includeSymbols) return
        _generatorOptions.value = _generatorOptions.value.copy(includeUppercase = value)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun toggleLowercase(value: Boolean) {
        if (!value && !_generatorOptions.value.includeUppercase && !_generatorOptions.value.includeNumbers && !_generatorOptions.value.includeSymbols) return
        _generatorOptions.value = _generatorOptions.value.copy(includeLowercase = value)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun toggleNumbers(value: Boolean) {
        if (!value && !_generatorOptions.value.includeUppercase && !_generatorOptions.value.includeLowercase && !_generatorOptions.value.includeSymbols) return
        _generatorOptions.value = _generatorOptions.value.copy(includeNumbers = value)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun toggleSymbols(value: Boolean) {
        if (!value && !_generatorOptions.value.includeUppercase && !_generatorOptions.value.includeLowercase && !_generatorOptions.value.includeNumbers) return
        _generatorOptions.value = _generatorOptions.value.copy(includeSymbols = value)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun toggleExcludeAmbiguous(value: Boolean) {
        _generatorOptions.value = _generatorOptions.value.copy(excludeAmbiguous = value)
        if (_generatedPassword.value.isNotEmpty()) {
            generatePassword()
        }
    }

    fun applyPreset(presetName: String) {
        when (presetName) {
            "Fortress" -> {
                _generatorOptions.value = GeneratorOptions(
                    length = 24,
                    includeUppercase = true,
                    includeLowercase = true,
                    includeNumbers = true,
                    includeSymbols = true,
                    excludeAmbiguous = false
                )
            }
            "Balanced" -> {
                _generatorOptions.value = GeneratorOptions(
                    length = 16,
                    includeUppercase = true,
                    includeLowercase = true,
                    includeNumbers = true,
                    includeSymbols = true,
                    excludeAmbiguous = false
                )
            }
            "Readable" -> {
                _generatorOptions.value = GeneratorOptions(
                    length = 16,
                    includeUppercase = true,
                    includeLowercase = true,
                    includeNumbers = true,
                    includeSymbols = false,
                    excludeAmbiguous = true
                )
            }
            "PIN" -> {
                _generatorOptions.value = GeneratorOptions(
                    length = 6,
                    includeUppercase = false,
                    includeLowercase = false,
                    includeNumbers = true,
                    includeSymbols = false,
                    excludeAmbiguous = false
                )
            }
        }
        generatePassword()
    }

    // --- Search & Filter ---
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    // --- Credential Operations ---
    fun saveCredential(
        label: String,
        password: String,
        username: String = "",
        category: String = "General",
        notes: String = ""
    ): Boolean {
        val trimmedLabel = label.trim()
        if (trimmedLabel.isEmpty()) {
            _snackbarMessage.value = "Label is required to save credential."
            return false
        }
        val trimmedPassword = password.trim()
        if (trimmedPassword.isEmpty()) {
            _snackbarMessage.value = "Password cannot be empty."
            return false
        }

        viewModelScope.launch {
            val credential = SavedCredential(
                label = trimmedLabel,
                password = trimmedPassword,
                username = username.trim(),
                category = category,
                notes = notes.trim(),
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.saveCredential(credential)
            _snackbarMessage.value = "Saved '$trimmedLabel' to vault!"
        }
        return true
    }

    fun updateCredential(credential: SavedCredential) {
        viewModelScope.launch {
            repository.updateCredential(credential.copy(updatedAt = System.currentTimeMillis()))
            _snackbarMessage.value = "Updated '${credential.label}'"
        }
    }

    fun deleteCredential(credential: SavedCredential) {
        viewModelScope.launch {
            repository.deleteCredential(credential)
            _snackbarMessage.value = "Deleted '${credential.label}'"
            hidePassword(credential.id)
        }
    }

    // --- Password Reveal & PIN Unlock ---
    fun togglePasswordVisibility(
        credentialId: Long,
        onPinRequired: () -> Unit
    ) {
        if (_revealedIds.value.contains(credentialId)) {
            // Already visible, hide it
            hidePassword(credentialId)
        } else {
            // Needs reveal
            val isPinEnabled = settingsState.value.isPinProtectionEnabled
            if (isPinEnabled) {
                onPinRequired()
            } else {
                revealPassword(credentialId)
            }
        }
    }

    fun revealPassword(credentialId: Long) {
        _revealedIds.value = _revealedIds.value + credentialId
    }

    fun hidePassword(credentialId: Long) {
        _revealedIds.value = _revealedIds.value - credentialId
    }

    fun hideAllPasswords() {
        _revealedIds.value = emptySet()
    }

    // --- Settings & PIN Operations ---
    fun setThemeMode(mode: AppThemeMode) {
        settingsManager.setThemeMode(mode)
    }

    fun setPin(pin: String): Boolean {
        val success = settingsManager.setPin(pin)
        if (success) {
            _snackbarMessage.value = "PIN protection enabled successfully"
        }
        return success
    }

    fun verifyPin(pin: String): Boolean {
        return settingsManager.verifyPin(pin)
    }

    fun disablePin(currentPin: String): Boolean {
        if (!settingsManager.verifyPin(currentPin)) {
            _snackbarMessage.value = "Incorrect PIN. Cannot disable."
            return false
        }
        settingsManager.clearPin()
        _snackbarMessage.value = "PIN protection removed"
        return true
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (!settingsManager.verifyPin(oldPin)) {
            _snackbarMessage.value = "Current PIN is incorrect"
            return false
        }
        if (newPin.length < 4) {
            _snackbarMessage.value = "New PIN must be at least 4 digits"
            return false
        }
        settingsManager.setPin(newPin)
        _snackbarMessage.value = "PIN changed successfully"
        return true
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.deleteAll()
            _snackbarMessage.value = "All saved passwords cleared"
        }
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}
