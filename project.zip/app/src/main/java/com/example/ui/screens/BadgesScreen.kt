package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserStatsEntity
import com.example.model.Badge
import com.example.model.BadgeCatalog
import com.example.model.BadgeCategory
import com.example.model.GamificationManager
import com.example.ui.theme.AmberStreak
import com.example.ui.theme.BadgeGold
import com.example.ui.theme.CrimsonQuit
import com.example.ui.theme.EmeraldPrimary

@Composable
fun BadgesScreen(
    userStats: UserStatsEntity?,
    levelInfo: GamificationManager.LevelInfo,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<BadgeCategory?>(null) }
    var inspectBadge by remember { mutableStateOf<Badge?>(null) }

    val unlockedIds = remember(userStats) {
        userStats?.unlockedBadgeIds?.toSet() ?: emptySet()
    }

    val filteredBadges = remember(selectedCategory) {
        if (selectedCategory == null) {
            BadgeCatalog.ALL_BADGES
        } else {
            BadgeCatalog.ALL_BADGES.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("badges_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Level & Badges Summary Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(listOf(AmberStreak, EmeraldPrimary))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MilitaryTech,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Level ${levelInfo.currentLevel} • ${levelInfo.rankTitle}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${unlockedIds.size} of ${BadgeCatalog.ALL_BADGES.size} Badges Earned",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AmberStreak,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CategoryChip(
                    label = "All",
                    isSelected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    modifier = Modifier.weight(1f)
                )

                CategoryChip(
                    label = "Streak",
                    isSelected = selectedCategory == BadgeCategory.STREAK,
                    onClick = { selectedCategory = BadgeCategory.STREAK },
                    modifier = Modifier.weight(1f)
                )

                CategoryChip(
                    label = "Quit",
                    isSelected = selectedCategory == BadgeCategory.QUIT_HABITS,
                    onClick = { selectedCategory = BadgeCategory.QUIT_HABITS },
                    modifier = Modifier.weight(1f)
                )

                CategoryChip(
                    label = "Mastery",
                    isSelected = selectedCategory == BadgeCategory.MASTERY,
                    onClick = { selectedCategory = BadgeCategory.MASTERY },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Badge Cards List
        items(filteredBadges, key = { it.id }) { badge ->
            val isUnlocked = unlockedIds.contains(badge.id)

            BadgeItemCard(
                badge = badge,
                isUnlocked = isUnlocked,
                onClick = { inspectBadge = badge }
            )
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Badge Details Inspector Dialog
    if (inspectBadge != null) {
        val b = inspectBadge!!
        val isUnlocked = unlockedIds.contains(b.id)

        AlertDialog(
            onDismissRequest = { inspectBadge = null },
            icon = {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isUnlocked) AmberStreak else MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (isUnlocked) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = b.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = b.description,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "XP Reward: +${b.xpReward} XP",
                        fontWeight = FontWeight.Bold,
                        color = AmberStreak,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isUnlocked) "Status: UNLOCKED ✓" else "Status: In Progress",
                        fontWeight = FontWeight.SemiBold,
                        color = if (isUnlocked) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { inspectBadge = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun CategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun BadgeItemCard(
    badge: Badge,
    isUnlocked: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isUnlocked) 1.5.dp else 1.dp,
                color = if (isUnlocked) AmberStreak.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .testTag("badge_card_${badge.id}"),
        color = if (isUnlocked) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        tonalElevation = if (isUnlocked) 3.dp else 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (isUnlocked) {
                            Brush.linearGradient(listOf(AmberStreak, BadgeGold))
                        } else {
                            Brush.linearGradient(listOf(Color(0xFF2D3748), Color(0xFF1A202C)))
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (isUnlocked) Color.Black else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = badge.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (isUnlocked) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Unlocked",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = badge.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // XP Reward Pill
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isUnlocked) AmberStreak.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
            ) {
                Text(
                    text = "+${badge.xpReward} XP",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUnlocked) AmberStreak else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
