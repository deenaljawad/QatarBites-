package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AppThemeMode
import com.example.ui.screens.GeneratorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.PassForgeTheme
import com.example.ui.viewmodel.MainViewModel

enum class AppDestination(val label: String) {
    GENERATOR("Generator"),
    VAULT("Vault"),
    SETTINGS("Settings")
}

@Composable
fun PassForgeApp(viewModel: MainViewModel) {
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val options by viewModel.generatorOptions.collectAsStateWithLifecycle()
    val password by viewModel.generatedPassword.collectAsStateWithLifecycle()
    val evaluation by viewModel.passwordEvaluation.collectAsStateWithLifecycle()
    val credentials by viewModel.savedCredentials.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val revealedIds by viewModel.revealedIds.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var currentDestination by remember { mutableStateOf(AppDestination.GENERATOR) }

    // Display snackbar whenever message is emitted
    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Handle back button for secondary screens
    if (currentDestination != AppDestination.GENERATOR) {
        BackHandler {
            currentDestination = AppDestination.GENERATOR
        }
    }

    PassForgeTheme(themeMode = settings.themeMode) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("bottom_navigation_bar"),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    // Generator
                    NavigationBarItem(
                        selected = currentDestination == AppDestination.GENERATOR,
                        onClick = { currentDestination = AppDestination.GENERATOR },
                        icon = {
                            Icon(
                                imageVector = if (currentDestination == AppDestination.GENERATOR) Icons.Filled.Key else Icons.Outlined.Key,
                                contentDescription = "Generator"
                            )
                        },
                        label = { Text("Generator") },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_generator")
                    )

                    // Vault
                    NavigationBarItem(
                        selected = currentDestination == AppDestination.VAULT,
                        onClick = { currentDestination = AppDestination.VAULT },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (credentials.isNotEmpty()) {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        ) {
                                            Text("${credentials.size}")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (currentDestination == AppDestination.VAULT) Icons.Filled.Lock else Icons.Outlined.Lock,
                                    contentDescription = "Vault"
                                )
                            }
                        },
                        label = { Text("Vault") },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_vault")
                    )

                    // Settings
                    NavigationBarItem(
                        selected = currentDestination == AppDestination.SETTINGS,
                        onClick = { currentDestination = AppDestination.SETTINGS },
                        icon = {
                            Icon(
                                imageVector = if (currentDestination == AppDestination.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = "Settings"
                            )
                        },
                        label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_settings")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentDestination) {
                    AppDestination.GENERATOR -> {
                        GeneratorScreen(
                            options = options,
                            password = password,
                            evaluation = evaluation,
                            onGenerate = { viewModel.generatePassword() },
                            onSetLength = { viewModel.setLength(it) },
                            onToggleUpper = { viewModel.toggleUppercase(it) },
                            onToggleLower = { viewModel.toggleLowercase(it) },
                            onToggleNumbers = { viewModel.toggleNumbers(it) },
                            onToggleSymbols = { viewModel.toggleSymbols(it) },
                            onToggleAmbiguous = { viewModel.toggleExcludeAmbiguous(it) },
                            onApplyPreset = { viewModel.applyPreset(it) },
                            onSaveCredential = { label, pwd, username, cat, notes ->
                                val success = viewModel.saveCredential(label, pwd, username, cat, notes)
                                if (success) {
                                    // Optionally switch to Vault so user sees their saved item
                                    currentDestination = AppDestination.VAULT
                                }
                            },
                            onClearPassword = { viewModel.clearGeneratedPassword() },
                            onShowToast = { viewModel.showSnackbar(it) }
                        )
                    }

                    AppDestination.VAULT -> {
                        VaultScreen(
                            credentials = credentials,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            revealedIds = revealedIds,
                            isPinProtectionEnabled = settings.isPinProtectionEnabled,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onSelectCategory = { viewModel.setSelectedCategory(it) },
                            onTogglePasswordVisibility = { id, onPinRequired ->
                                viewModel.togglePasswordVisibility(id, onPinRequired)
                            },
                            onPinValidated = { id ->
                                viewModel.revealPassword(id)
                            },
                            onVerifyPin = { pin ->
                                viewModel.verifyPin(pin)
                            },
                            onDeleteCredential = { viewModel.deleteCredential(it) },
                            onUpdateCredential = { viewModel.updateCredential(it) },
                            onShowToast = { viewModel.showSnackbar(it) },
                            onNavigateToGenerator = { currentDestination = AppDestination.GENERATOR }
                        )
                    }

                    AppDestination.SETTINGS -> {
                        SettingsScreen(
                            settings = settings,
                            totalCredentialsCount = credentials.size,
                            onSetThemeMode = { viewModel.setThemeMode(it) },
                            onSetupPin = { pin ->
                                if (pin.isEmpty()) {
                                    // Re-enabling with existing pin
                                    viewModel.setPin(pin) // or toggle
                                    viewModel.settingsState.value.hasPinSet
                                } else {
                                    viewModel.setPin(pin)
                                }
                            },
                            onDisablePin = { currentPin ->
                                viewModel.disablePin(currentPin)
                            },
                            onChangePin = { oldPin, newPin ->
                                viewModel.changePin(oldPin, newPin)
                            },
                            onClearAllData = { viewModel.clearAllData() }
                        )
                    }
                }
            }
        }
    }
}
