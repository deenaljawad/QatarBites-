package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Recipe
import com.example.data.repository.RecipeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface RecipeBookUiState {
    data object Loading : RecipeBookUiState
    data class Success(
        val allRecipes: List<Recipe>,
        val filteredRecipes: List<Recipe>,
        val selectedMealType: String?,
        val onlyFavorites: Boolean,
        val searchQuery: String
    ) : RecipeBookUiState
    data class Error(val message: String) : RecipeBookUiState
}

class RecipeBookViewModel(
    private val repository: RecipeRepository
) : ViewModel() {

    private val _selectedMealType = MutableStateFlow<String?>(null)
    val selectedMealType = _selectedMealType.asStateFlow()

    private val _onlyFavorites = MutableStateFlow(false)
    val onlyFavorites = _onlyFavorites.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage = _actionMessage.asStateFlow()

    val uiState: StateFlow<RecipeBookUiState> = combine(
        repository.observeRecipes(),
        _selectedMealType,
        _onlyFavorites,
        _searchQuery
    ) { recipes, mealType, favOnly, query ->
        val filtered = recipes.filter { r ->
            val matchesType = mealType == null || r.mealType.equals(mealType, ignoreCase = true)
            val matchesFav = !favOnly || r.isFavorite
            val matchesQuery = query.isBlank() || r.title.contains(query, ignoreCase = true) || r.ingredients.any { it.contains(query, ignoreCase = true) }
            matchesType && matchesFav && matchesQuery
        }
        RecipeBookUiState.Success(
            allRecipes = recipes,
            filteredRecipes = filtered,
            selectedMealType = mealType,
            onlyFavorites = favOnly,
            searchQuery = query
        ) as RecipeBookUiState
    }.catch { error ->
        emit(RecipeBookUiState.Error(error.localizedMessage ?: "Failed to load saved recipes"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = RecipeBookUiState.Loading
    )

    fun setMealTypeFilter(type: String?) {
        _selectedMealType.value = type
    }

    fun toggleFavoritesFilter() {
        _onlyFavorites.value = !_onlyFavorites.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(recipe: Recipe) {
        viewModelScope.launch {
            try {
                repository.toggleFavorite(recipe)
            } catch (e: Exception) {
                _actionMessage.value = "Failed to update favorite: ${e.message}"
            }
        }
    }

    fun updatePlannedDate(recipe: Recipe, plannedDate: String) {
        viewModelScope.launch {
            try {
                repository.updatePlannedDate(recipe, plannedDate)
                _actionMessage.value = if (plannedDate.isNotBlank()) "Scheduled for $plannedDate" else "Removed from schedule"
            } catch (e: Exception) {
                _actionMessage.value = "Failed to update schedule: ${e.message}"
            }
        }
    }

    fun deleteRecipe(recipe: Recipe) {
        viewModelScope.launch {
            try {
                repository.deleteRecipe(recipe.id)
                _actionMessage.value = "Deleted '${recipe.title}'"
            } catch (e: Exception) {
                _actionMessage.value = "Failed to delete recipe: ${e.message}"
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }
}
