package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import com.example.data.models.UrgencyLevel
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SecurityTeal
import com.example.ui.theme.Slate700
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingFlowDialog(
    service: TechService,
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val step by viewModel.bookingStep.collectAsState()
    val isProcessing by viewModel.isProcessingPayment.collectAsState()
    val createdBooking by viewModel.createdBooking.collectAsState()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = if (step == 3) "Booking Confirmed!" else "Book Tech Support",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = service.title,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_booking_flow_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step Indicator (only on steps 0, 1, 2)
            if (step < 3) {
                BookingStepIndicator(currentStep = step)
                Spacer(modifier = Modifier.height(18.dp))
            }

            when (step) {
                0 -> StepDateTime(service = service, viewModel = viewModel)
                1 -> StepDetailsAndMode(service = service, viewModel = viewModel)
                2 -> StepPaymentCheckout(service = service, viewModel = viewModel, isProcessing = isProcessing)
                3 -> StepConfirmationReceipt(
                    booking = createdBooking,
                    onViewBookings = {
                        viewModel.closeBookingFlow()
                        viewModel.selectTab(AppTab.BOOKINGS)
                    },
                    onClose = onDismiss
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun BookingStepIndicator(currentStep: Int) {
    val steps = listOf("Schedule", "Details", "Payment")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, label ->
            val isActive = index == currentStep
            val isDone = index < currentStep

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isDone -> SuccessGreen
                                isActive -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = "${index + 1}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                    color = if (isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .padding(horizontal = 8.dp)
                        .background(
                            if (index < currentStep) SuccessGreen else MaterialTheme.colorScheme.outlineVariant
                        )
                )
            }
        }
    }
}

@Composable
fun StepDateTime(
    service: TechService,
    viewModel: MainViewModel
) {
    val appointmentDate by viewModel.appointmentDate.collectAsState()
    val appointmentTimeSlot by viewModel.appointmentTimeSlot.collectAsState()

    val dateOptions = if (service.isEmergency) {
        listOf("Immediate Priority", "Today", "Tomorrow")
    } else {
        listOf("Today", "Tomorrow", "In 2 Days", "This Weekend")
    }

    val timeSlots = if (service.isEmergency) {
        listOf("Immediate (Next 15 min)", "Within 1 Hour", "2:00 PM - 3:00 PM", "5:00 PM - 6:00 PM")
    } else {
        listOf(
            "9:00 AM - 10:00 AM",
            "11:30 AM - 12:30 PM",
            "2:00 PM - 3:00 PM",
            "4:30 PM - 5:30 PM",
            "7:00 PM - 8:00 PM"
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            text = "1. Select Appointment Date",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            dateOptions.forEach { date ->
                val isSelected = appointmentDate == date
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.appointmentDate.value = date },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    label = { Text(date, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("date_chip_$date")
                )
            }
        }

        Text(
            text = "2. Select Time Window",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            timeSlots.forEach { slot ->
                val isSelected = appointmentTimeSlot == slot
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.appointmentTimeSlot.value = slot }
                        .testTag("slot_option_$slot")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = slot,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { viewModel.setBookingStep(1) },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("next_step_details_button")
        ) {
            Text("Continue to Client Details", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StepDetailsAndMode(
    service: TechService,
    viewModel: MainViewModel
) {
    val name by viewModel.customerName.collectAsState()
    val email by viewModel.customerEmail.collectAsState()
    val phone by viewModel.customerPhone.collectAsState()
    val modeDetail by viewModel.serviceModeDetail.collectAsState()
    val issueDescription by viewModel.issueDescription.collectAsState()
    val urgency by viewModel.urgencyLevel.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Client Contact Information",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = name,
            onValueChange = { viewModel.customerName.value = it },
            label = { Text("Full Name") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_customer_name")
        )

        OutlinedTextField(
            value = email,
            onValueChange = { viewModel.customerEmail.value = it },
            label = { Text("Email Address for Confirmation") },
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_customer_email")
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { viewModel.customerPhone.value = it },
            label = { Text("Direct Phone / Callback Number") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_customer_phone")
        )

        // Mode Specific Field
        when (service.category) {
            ServiceCategory.VIRTUAL -> {
                OutlinedTextField(
                    value = modeDetail,
                    onValueChange = { viewModel.serviceModeDetail.value = it },
                    label = { Text("Remote Connection Preference (AnyDesk ID / Zoom / Phone)") },
                    placeholder = { Text("e.g. AnyDesk 9-digit code or Zoom meeting link") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_service_mode_detail")
                )
            }
            ServiceCategory.PHYSICAL -> {
                OutlinedTextField(
                    value = modeDetail,
                    onValueChange = { viewModel.serviceModeDetail.value = it },
                    label = { Text("Physical Service Address / Drop-off location") },
                    placeholder = { Text("e.g. 742 Evergreen Terrace, Springfield, OR") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_service_mode_detail")
                )
            }
            ServiceCategory.SCAM_SPAM -> {
                OutlinedTextField(
                    value = modeDetail,
                    onValueChange = { viewModel.serviceModeDetail.value = it },
                    label = { Text("Incident Details (Caller name, amount asked, app installed)") },
                    placeholder = { Text("e.g. Caller claimed to be Amazon, had me install AnyDesk") },
                    leadingIcon = { Icon(Icons.Default.Shield, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_service_mode_detail")
                )
            }
        }

        OutlinedTextField(
            value = issueDescription,
            onValueChange = { viewModel.issueDescription.value = it },
            label = { Text("Brief Description of the Tech Problem") },
            placeholder = { Text("Describe what symptoms you see or what needs repairing...") },
            minLines = 2,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_issue_description")
        )

        // Urgency Level selection
        Text(
            text = "Response Priority",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            UrgencyLevel.values().forEach { level ->
                val isSelected = urgency == level
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.urgencyLevel.value = level }
                        .testTag("urgency_option_${level.name}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        RadioButton(selected = isSelected, onClick = { viewModel.urgencyLevel.value = level })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = level.label,
                                fontWeight = FontWeight.Bold,
                                color = if (level == UrgencyLevel.CRITICAL_EMERGENCY) DangerRed else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = when (level) {
                                    UrgencyLevel.NORMAL -> "Regular queue schedule ($0)"
                                    UrgencyLevel.HIGH -> "Priority dispatch within 2 hours (+$10)"
                                    UrgencyLevel.CRITICAL_EMERGENCY -> "Immediate emergency lockout dispatch (+$15)"
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = { viewModel.setBookingStep(0) },
                modifier = Modifier.weight(1f)
            ) {
                Text("Back")
            }
            Button(
                onClick = { viewModel.setBookingStep(2) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("next_step_payment_button")
            ) {
                Text("Proceed to Checkout", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StepPaymentCheckout(
    service: TechService,
    viewModel: MainViewModel,
    isProcessing: Boolean
) {
    val urgency by viewModel.urgencyLevel.collectAsState()
    val paymentMethodType by viewModel.paymentMethodType.collectAsState()
    val cardNumber by viewModel.cardNumber.collectAsState()
    val cardExpiry by viewModel.cardExpiry.collectAsState()
    val cardCvv by viewModel.cardCvv.collectAsState()
    val cardHolder by viewModel.cardHolder.collectAsState()
    val promoCode by viewModel.promoCode.collectAsState()
    val promoDiscount by viewModel.promoDiscount.collectAsState()

    val basePrice = service.price
    val urgencyFee = when (urgency) {
        UrgencyLevel.CRITICAL_EMERGENCY -> 15.0
        UrgencyLevel.HIGH -> 10.0
        UrgencyLevel.NORMAL -> 0.0
    }
    val subtotal = basePrice + urgencyFee
    val discountAmount = subtotal * promoDiscount
    val totalAmount = (subtotal - discountAmount).coerceAtLeast(0.0)

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Order Summary Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Order Breakdown",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                PriceRow(label = service.title, amount = "$${String.format("%.2f", basePrice)}")
                if (urgencyFee > 0) {
                    PriceRow(label = "Priority Urgency Fee", amount = "+$${String.format("%.2f", urgencyFee)}")
                }
                PriceRow(label = "Diagnostic Consultation", amount = "FREE", highlight = true)

                if (promoDiscount > 0) {
                    PriceRow(
                        label = "Promo Discount (${(promoDiscount * 100).toInt()}%)",
                        amount = "-$${String.format("%.2f", discountAmount)}",
                        isDiscount = true
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Total Due Today",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "$${String.format("%.2f", totalAmount)}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Promo Code Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = promoCode,
                onValueChange = { viewModel.promoCode.value = it },
                label = { Text("Promo Code (e.g. TECHSAFE10)") },
                leadingIcon = { Icon(Icons.Default.Discount, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_promo_code")
            )
            Button(
                onClick = { viewModel.applyPromoCode(promoCode) },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("apply_promo_button")
            ) {
                Text("Apply")
            }
        }
        if (promoDiscount > 0) {
            Text(
                text = "✓ Promo code applied successfully!",
                color = SuccessGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Payment Method Selector
        Text(
            text = "Select Payment Method",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            PaymentMethodChip(
                label = "Card",
                icon = Icons.Default.CreditCard,
                isSelected = paymentMethodType == "CARD",
                onClick = { viewModel.paymentMethodType.value = "CARD" },
                modifier = Modifier.weight(1f)
            )
            PaymentMethodChip(
                label = "Google Pay",
                icon = Icons.Default.Shield,
                isSelected = paymentMethodType == "GPAY",
                onClick = { viewModel.paymentMethodType.value = "GPAY" },
                modifier = Modifier.weight(1f)
            )
            PaymentMethodChip(
                label = "On Arrival",
                icon = Icons.Default.CheckCircle,
                isSelected = paymentMethodType == "CASH",
                onClick = { viewModel.paymentMethodType.value = "CASH" },
                modifier = Modifier.weight(1f)
            )
        }

        if (paymentMethodType == "CARD") {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = cardNumber,
                        onValueChange = { viewModel.cardNumber.value = it },
                        label = { Text("Card Number") },
                        leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_card_number")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = cardExpiry,
                            onValueChange = { viewModel.cardExpiry.value = it },
                            label = { Text("MM/YY") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_card_expiry")
                        )
                        OutlinedTextField(
                            value = cardCvv,
                            onValueChange = { viewModel.cardCvv.value = it },
                            label = { Text("CVV") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_card_cvv")
                        )
                    }

                    OutlinedTextField(
                        value = cardHolder,
                        onValueChange = { viewModel.cardHolder.value = it },
                        label = { Text("Cardholder Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_card_holder")
                    )
                }
            }
        } else if (paymentMethodType == "GPAY") {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .padding(vertical = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Google Pay 1-Tap Ready",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        } else {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "💵 Pay in cash or by invoice when the technician arrives or upon picking up your repaired device. No upfront payment required.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = { viewModel.setBookingStep(1) },
                enabled = !isProcessing,
                modifier = Modifier.weight(1f)
            ) {
                Text("Back")
            }
            Button(
                onClick = { viewModel.processPaymentAndConfirm() },
                enabled = !isProcessing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("confirm_and_pay_button")
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Securing...")
                } else {
                    Text("Pay $${String.format("%.2f", totalAmount)} & Confirm", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StepConfirmationReceipt(
    booking: com.example.data.models.Booking?,
    onViewBookings: () -> Unit,
    onClose: () -> Unit
) {
    if (booking == null) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(12.dp))
            Text("Finalizing your confirmation...")
        }
        return
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(70.dp)
                .clip(CircleShape)
                .background(SuccessGreen.copy(alpha = 0.15f))
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = SuccessGreen,
                modifier = Modifier.size(46.dp)
            )
        }

        Text(
            text = "Booking Confirmed & Dispatched!",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Text(
            text = "A certified TechHelp4U technician has been notified and scheduled for your appointment.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // Receipt Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Booking Reference:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = booking.id,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Service:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(booking.serviceTitle, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Scheduled For:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${booking.appointmentDate} • ${booking.appointmentTimeSlot}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Assigned Tech:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(booking.assignedTechnician ?: "Queued for Dispatch", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SecurityTeal)
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Payment Status:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("PAID ($${String.format("%.2f", booking.amountPaid)})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Transaction ID:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(booking.transactionId, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Button(
            onClick = onViewBookings,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("go_to_my_bookings_button")
        ) {
            Text("Track in My Bookings", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Done")
        }
    }
}

@Composable
private fun PriceRow(
    label: String,
    amount: String,
    highlight: Boolean = false,
    isDiscount: Boolean = false
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = amount,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = when {
                isDiscount -> SuccessGreen
                highlight -> SecurityTeal
                else -> MaterialTheme.colorScheme.onSurface
            }
        )
    }
}

@Composable
private fun PaymentMethodChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("pay_chip_$label")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
