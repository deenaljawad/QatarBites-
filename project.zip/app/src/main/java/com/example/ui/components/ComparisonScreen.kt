package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.ui.theme.DealGreen
import com.example.ui.theme.DealOrange
import java.util.Locale

@Composable
fun ComparisonScreen(
  cars: List<Car>,
  onRemoveCar: (String) -> Unit,
  onClearAll: () -> Unit,
  onCarClick: (Car) -> Unit,
  onBrowseMore: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .verticalScroll(scrollState)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Vehicle Comparison",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = if (cars.size == 2) "Side-by-side performance breakdown" else "Select 2 cars to compare specs",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (cars.isNotEmpty()) {
        TextButton(
          onClick = onClearAll,
          modifier = Modifier.testTag("clear_comparison_button")
        ) {
          Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Clear")
        }
      }
    }

    if (cars.isEmpty()) {
      // Empty state
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 32.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            modifier = Modifier.size(64.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.CompareArrows,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
              )
            }
          }

          Text(
            text = "No Cars in Comparison",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "Tap the compare button on any two car listings to evaluate prices, acceleration, and power side by side.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
          )

          Button(
            onClick = onBrowseMore,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("browse_to_compare_button")
          ) {
            Text("Browse Inventory")
          }
        }
      }
    } else {
      val car1 = cars.firstOrNull()
      val car2 = cars.getOrNull(1)

      // Comparison Header Cards (Vehicle 1 and Vehicle 2)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Car 1 Card
        if (car1 != null) {
          ComparisonVehicleHeader(
            car = car1,
            onRemove = { onRemoveCar(car1.id) },
            onCarClick = { onCarClick(car1) },
            modifier = Modifier.weight(1f)
          )
        }

        // Car 2 Card or Placeholder
        if (car2 != null) {
          ComparisonVehicleHeader(
            car = car2,
            onRemove = { onRemoveCar(car2.id) },
            onCarClick = { onCarClick(car2) },
            modifier = Modifier.weight(1f)
          )
        } else {
          // Placeholder to add second car
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
              .weight(1f)
              .height(180.dp)
              .clip(RoundedCornerShape(16.dp))
              .clickable(onClick = onBrowseMore)
          ) {
            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Add 2nd Car",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "Tap to pick from inventory",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Comparison Metrics Table (only if both are present)
      if (car1 != null && car2 != null) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Text(
              text = "HEAD-TO-HEAD METRICS",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              letterSpacing = 1.sp
            )

            // Price metric
            ComparisonRow(
              title = "Listed Price",
              val1 = "$${String.format(Locale.US, "%,.0f", car1.price)}",
              val2 = "$${String.format(Locale.US, "%,.0f", car2.price)}",
              car1Wins = car1.price < car2.price,
              car2Wins = car2.price < car1.price
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // 0-60 mph (lower is better)
            ComparisonRow(
              title = "0-60 MPH Acceleration",
              val1 = "${car1.zeroToSixty}s",
              val2 = "${car2.zeroToSixty}s",
              car1Wins = car1.zeroToSixty < car2.zeroToSixty,
              car2Wins = car2.zeroToSixty < car1.zeroToSixty
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Horsepower (higher is better)
            ComparisonRow(
              title = "Horsepower",
              val1 = "${car1.horsepower} HP",
              val2 = "${car2.horsepower} HP",
              car1Wins = car1.horsepower > car2.horsepower,
              car2Wins = car2.horsepower > car1.horsepower
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Top speed
            ComparisonRow(
              title = "Top Speed",
              val1 = "${car1.topSpeed} MPH",
              val2 = "${car2.topSpeed} MPH",
              car1Wins = car1.topSpeed > car2.topSpeed,
              car2Wins = car2.topSpeed > car1.topSpeed
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Efficiency / Range
            ComparisonRow(
              title = "Fuel Economy / Range",
              val1 = car1.rangeOrMpg,
              val2 = car2.rangeOrMpg,
              car1Wins = false,
              car2Wins = false
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Drivetrain
            ComparisonRow(
              title = "Drivetrain",
              val1 = car1.drivetrain,
              val2 = car2.drivetrain,
              car1Wins = false,
              car2Wins = false
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Deal Savings
            ComparisonRow(
              title = "Discount / Deal Savings",
              val1 = if (car1.discountAmount > 0) "$${String.format(Locale.US, "%,.0f", car1.discountAmount)}" else "No Deal",
              val2 = if (car2.discountAmount > 0) "$${String.format(Locale.US, "%,.0f", car2.discountAmount)}" else "No Deal",
              car1Wins = car1.discountAmount > car2.discountAmount,
              car2Wins = car2.discountAmount > car1.discountAmount
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Monthly payment
            ComparisonRow(
              title = "Est. Monthly Payment",
              val1 = "$${car1.estimatedMonthlyPayment}/mo",
              val2 = "$${car2.estimatedMonthlyPayment}/mo",
              car1Wins = car1.estimatedMonthlyPayment < car2.estimatedMonthlyPayment,
              car2Wins = car2.estimatedMonthlyPayment < car1.estimatedMonthlyPayment
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun ComparisonVehicleHeader(
  car: Car,
  onRemove: () -> Unit,
  onCarClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onCarClick),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        ) {
          Text(
            text = car.brand,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }

        IconButton(
          onClick = onRemove,
          modifier = Modifier.size(24.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Remove from compare",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = car.model,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Text(
        text = "${car.year} • ${car.bodyType}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "$${String.format(Locale.US, "%,.0f", car.price)}",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Black,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Composable
private fun ComparisonRow(
  title: String,
  val1: String,
  val2: String,
  car1Wins: Boolean,
  car2Wins: Boolean
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center,
      modifier = Modifier.fillMaxWidth()
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Val 1
      Row(
        modifier = Modifier.weight(1f),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (car1Wins) {
          Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = "Winner",
            tint = DealGreen,
            modifier = Modifier
              .size(16.dp)
              .padding(end = 4.dp)
          )
        }
        Text(
          text = val1,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = if (car1Wins) FontWeight.ExtraBold else FontWeight.SemiBold,
          color = if (car1Wins) DealGreen else MaterialTheme.colorScheme.onSurface
        )
      }

      // Val 2
      Row(
        modifier = Modifier.weight(1f),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = val2,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = if (car2Wins) FontWeight.ExtraBold else FontWeight.SemiBold,
          color = if (car2Wins) DealGreen else MaterialTheme.colorScheme.onSurface
        )
        if (car2Wins) {
          Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = "Winner",
            tint = DealGreen,
            modifier = Modifier
              .size(16.dp)
              .padding(start = 4.dp)
          )
        }
      }
    }
  }
}
