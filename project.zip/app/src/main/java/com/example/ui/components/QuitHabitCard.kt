package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.data.HabitLogEntity
import com.example.ui.theme.CrimsonQuit
import com.example.ui.theme.CrimsonQuitLight
import com.example.ui.theme.EmeraldPrimary

@Composable
fun QuitHabitCard(
    habit: HabitEntity,
    log: HabitLogEntity?,
    onCheckCleanToday: () -> Unit,
    onRecordSlip: () -> Unit,
    onEditClick: () -> Unit,
    onTestNotification: () -> Unit,
    modifier: Modifier = Modifier,
    isReorderMode: Boolean = false,
    positionIndex: Int = 1,
    canMoveUp: Boolean = true,
    canMoveDown: Boolean = true,
    onMoveUp: () -> Unit = {},
    onMoveDown: () -> Unit = {}
) {
    val isCleanToday = log?.isCompleted ?: false
    var showSlipDialog by remember { mutableStateOf(false) }

    val cleanDurationMillis = (System.currentTimeMillis() - habit.quitCleanStartTimestamp).coerceAtLeast(0L)
    val totalHours = cleanDurationMillis / (1000 * 60 * 60)
    val daysClean = totalHours / 24
    val remainingHours = totalHours % 24

    val habitColor = parseColor(habit.colorHex)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        CrimsonQuit.copy(alpha = 0.5f),
                        EmeraldPrimary.copy(alpha = 0.5f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onEditClick)
            .testTag("quit_habit_card_${habit.id}"),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Shield icon, Quit Title, Clean badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CrimsonQuit.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Quit Shield",
                        tint = CrimsonQuit,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = habit.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = CrimsonQuit.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "QUIT HABIT",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrimsonQuit,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${getFrequencyLabel(habit)} target: 0 relapses",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (isReorderMode) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.padding(end = 2.dp)
                        ) {
                            Text(
                                text = "#$positionIndex",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        IconButton(
                            onClick = onMoveUp,
                            enabled = canMoveUp,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("move_up_habit_${habit.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Move Up",
                                tint = if (canMoveUp) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = onMoveDown,
                            enabled = canMoveDown,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("move_down_habit_${habit.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Move Down",
                                tint = if (canMoveDown) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                } else {
                    // Check Clean Today Checkbox
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCleanToday) EmeraldPrimary else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = 2.dp,
                                color = if (isCleanToday) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                                shape = CircleShape
                            )
                            .clickable(onClick = onCheckCleanToday)
                            .testTag("toggle_quit_clean_${habit.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCleanToday) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Clean today",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hero Clean Timer Box
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "CLEAN STREAK",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$daysClean days, $remainingHours hrs",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isCleanToday) "Clean Today Logged" else "Not checked yet",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isCleanToday) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${habit.quitTotalSlips} slips recorded",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action: Report Slip (Full-width)
            OutlinedButton(
                onClick = { showSlipDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("report_slip_button_${habit.id}"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonQuit.copy(alpha = 0.4f))
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = CrimsonQuit,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Report a Slip / Reset Streak",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CrimsonQuit
                )
            }

            // Reminder status row
            if (habit.reminderEnabled && habit.reminderHour != null && habit.reminderMinute != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Reminder active",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Daily reminder: ${formatTime(habit.reminderHour, habit.reminderMinute)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.clickable(onClick = onTestNotification)
                    ) {
                        Text(
                            text = "Test Reminder",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }

    // Compassionate Slip Confirmation Dialog
    if (showSlipDialog) {
        AlertDialog(
            onDismissRequest = { showSlipDialog = false },
            title = {
                Text("Reset Clean Timer?")
            },
            text = {
                Text(
                    "Slips happen — progress is never lost. What matters is standing back up right now. Ready to start your new clean streak?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRecordSlip()
                        showSlipDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonQuit)
                ) {
                    Text("Reset Streak & Restart")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSlipDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
