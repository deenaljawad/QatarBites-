package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CarRepository
import com.example.model.Car
import com.example.model.CarFilterState
import com.example.model.OfferInquiry
import com.example.model.SortOption
import com.example.model.TestDriveBooking
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppTab {
  BROWSE,
  DEALS,
  GARAGE,
  COMPARE
}

class CarViewModel(
  private val repository: CarRepository = CarRepository()
) : ViewModel() {

  private val _currentTab = MutableStateFlow(AppTab.BROWSE)
  val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

  private val _filters = MutableStateFlow(CarFilterState())
  val filters: StateFlow<CarFilterState> = _filters.asStateFlow()

  // Deal tab specific brand filter
  private val _dealsBrandFilter = MutableStateFlow("All")
  val dealsBrandFilter: StateFlow<String> = _dealsBrandFilter.asStateFlow()

  val allCars: List<Car> = repository.allCars
  val allBrands: List<String> = repository.allBrands
  val bodyTypes: List<String> = repository.bodyTypes
  val conditions: List<String> = repository.conditions
  val fuelTypes: List<String> = repository.fuelTypes

  val favoriteIds: StateFlow<Set<String>> = repository.favoriteIds
  val comparisonIds: StateFlow<Set<String>> = repository.comparisonIds
  val testDrives: StateFlow<List<TestDriveBooking>> = repository.testDrives
  val offers: StateFlow<List<OfferInquiry>> = repository.offers

  // Filtered cars for Browse tab
  val filteredCars: StateFlow<List<Car>> = _filters.combine(
    MutableStateFlow(allCars)
  ) { currentFilters, cars ->
    repository.filterCars(cars, currentFilters)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), allCars)

  // Filtered cars for Deals tab
  val dealsCars: StateFlow<List<Car>> = _dealsBrandFilter.combine(
    MutableStateFlow(allCars.filter { it.isHotDeal })
  ) { selectedBrand, dealCarsList ->
    if (selectedBrand == "All") {
      dealCarsList.sortedByDescending { it.discountAmount }
    } else {
      dealCarsList.filter { it.brand.equals(selectedBrand, ignoreCase = true) }
        .sortedByDescending { it.discountAmount }
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), allCars.filter { it.isHotDeal })

  // Saved / Garage cars
  val favoriteCars: StateFlow<List<Car>> = favoriteIds.combine(
    MutableStateFlow(allCars)
  ) { favIds, cars ->
    cars.filter { favIds.contains(it.id) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Cars selected for comparison
  val comparisonCars: StateFlow<List<Car>> = comparisonIds.combine(
    MutableStateFlow(allCars)
  ) { compIds, cars ->
    cars.filter { compIds.contains(it.id) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Detail view state
  private val _selectedCar = MutableStateFlow<Car?>(null)
  val selectedCar: StateFlow<Car?> = _selectedCar.asStateFlow()

  // Sheet & Dialog states
  private val _isFilterSheetOpen = MutableStateFlow(false)
  val isFilterSheetOpen: StateFlow<Boolean> = _isFilterSheetOpen.asStateFlow()

  private val _isTestDriveDialogOpen = MutableStateFlow(false)
  val isTestDriveDialogOpen: StateFlow<Boolean> = _isTestDriveDialogOpen.asStateFlow()

  private val _isMakeOfferDialogOpen = MutableStateFlow(false)
  val isMakeOfferDialogOpen: StateFlow<Boolean> = _isMakeOfferDialogOpen.asStateFlow()

  // Snackbars / Toast messages
  private val _snackbarMessage = MutableSharedFlow<String>()
  val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

  fun setTab(tab: AppTab) {
    _currentTab.value = tab
  }

  fun selectCar(car: Car?) {
    _selectedCar.value = car
  }

  fun openFilterSheet() {
    _isFilterSheetOpen.value = true
  }

  fun closeFilterSheet() {
    _isFilterSheetOpen.value = false
  }

  fun openTestDriveDialog(car: Car? = null) {
    if (car != null) _selectedCar.value = car
    _isTestDriveDialogOpen.value = true
  }

  fun closeTestDriveDialog() {
    _isTestDriveDialogOpen.value = false
  }

  fun openMakeOfferDialog(car: Car? = null) {
    if (car != null) _selectedCar.value = car
    _isMakeOfferDialogOpen.value = true
  }

  fun closeMakeOfferDialog() {
    _isMakeOfferDialogOpen.value = false
  }

  // Filter modifications
  fun selectSingleBrand(brand: String) {
    if (brand == "All") {
      _filters.value = _filters.value.copy(selectedBrands = emptySet())
    } else {
      _filters.value = _filters.value.copy(selectedBrands = setOf(brand))
    }
  }

  fun toggleBrand(brand: String) {
    val current = _filters.value.selectedBrands.toMutableSet()
    if (brand == "All") {
      current.clear()
    } else {
      if (current.contains(brand)) {
        current.remove(brand)
      } else {
        current.add(brand)
      }
    }
    _filters.value = _filters.value.copy(selectedBrands = current)
  }

  fun setDealsBrandFilter(brand: String) {
    _dealsBrandFilter.value = brand
  }

  fun toggleDealsOnly() {
    _filters.value = _filters.value.copy(onlyDeals = !_filters.value.onlyDeals)
  }

  fun updateSearchQuery(query: String) {
    _filters.value = _filters.value.copy(searchQuery = query)
  }

  fun setPriceRange(min: Float, max: Float) {
    _filters.value = _filters.value.copy(minPrice = min, maxPrice = max)
  }

  fun toggleBodyType(type: String) {
    val current = _filters.value.selectedBodyTypes.toMutableSet()
    if (type == "All") {
      current.clear()
    } else {
      if (current.contains(type)) current.remove(type) else current.add(type)
    }
    _filters.value = _filters.value.copy(selectedBodyTypes = current)
  }

  fun toggleCondition(condition: String) {
    val current = _filters.value.selectedConditions.toMutableSet()
    if (condition == "All") {
      current.clear()
    } else {
      if (current.contains(condition)) current.remove(condition) else current.add(condition)
    }
    _filters.value = _filters.value.copy(selectedConditions = current)
  }

  fun toggleFuelType(fuel: String) {
    val current = _filters.value.selectedFuelTypes.toMutableSet()
    if (fuel == "All") {
      current.clear()
    } else {
      if (current.contains(fuel)) current.remove(fuel) else current.add(fuel)
    }
    _filters.value = _filters.value.copy(selectedFuelTypes = current)
  }

  fun setSortOption(sort: SortOption) {
    _filters.value = _filters.value.copy(sortBy = sort)
  }

  fun resetFilters() {
    _filters.value = CarFilterState()
  }

  fun toggleFavorite(car: Car) {
    repository.toggleFavorite(car.id)
    val isFav = repository.favoriteIds.value.contains(car.id)
    viewModelScope.launch {
      _snackbarMessage.emit(
        if (isFav) "Added ${car.brand} ${car.model} to Garage" else "Removed from Garage"
      )
    }
  }

  fun toggleComparison(car: Car) {
    val added = repository.toggleComparison(car.id)
    viewModelScope.launch {
      if (added) {
        val total = repository.comparisonIds.value.size
        _snackbarMessage.emit("Added to comparison ($total of 2 selected)")
      } else {
        _snackbarMessage.emit("Removed from comparison")
      }
    }
  }

  fun removeComparison(carId: String) {
    repository.removeComparison(carId)
  }

  fun clearComparison() {
    repository.clearComparison()
  }

  fun submitTestDriveBooking(date: String, timeSlot: String, name: String, phone: String) {
    val car = _selectedCar.value ?: return
    val booking = TestDriveBooking(
      id = "td_" + System.currentTimeMillis(),
      carId = car.id,
      carTitle = "${car.year} ${car.brand} ${car.model}",
      date = date,
      timeSlot = timeSlot,
      customerName = name,
      customerPhone = phone
    )
    repository.bookTestDrive(booking)
    _isTestDriveDialogOpen.value = false
    viewModelScope.launch {
      _snackbarMessage.emit("Test drive scheduled for ${car.brand} ${car.model}!")
    }
  }

  fun submitOffer(offerAmount: Double, hasTradeIn: Boolean, message: String) {
    val car = _selectedCar.value ?: return
    val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
    val offer = OfferInquiry(
      id = "off_" + System.currentTimeMillis(),
      carId = car.id,
      carTitle = "${car.year} ${car.brand} ${car.model}",
      offerPrice = offerAmount,
      hasTradeIn = hasTradeIn,
      message = message,
      timestamp = dateStr
    )
    repository.submitOffer(offer)
    _isMakeOfferDialogOpen.value = false
    viewModelScope.launch {
      _snackbarMessage.emit("Offer of $${String.format(Locale.US, "%,.0f", offerAmount)} submitted to ${car.dealerName}!")
    }
  }
}
