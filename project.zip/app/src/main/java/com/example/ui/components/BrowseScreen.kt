package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.model.CarFilterState
import com.example.ui.theme.DealOrange

@Composable
fun BrowseScreen(
  cars: List<Car>,
  allCarsList: List<Car>,
  brands: List<String>,
  filterState: CarFilterState,
  favoriteIds: Set<String>,
  comparisonIds: Set<String>,
  onSearchChange: (String) -> Unit,
  onSelectBrand: (String) -> Unit,
  onToggleDealsOnly: () -> Unit,
  onOpenFilterSheet: () -> Unit,
  onResetFilters: () -> Unit,
  onCarClick: (Car) -> Unit,
  onFavoriteClick: (Car) -> Unit,
  onCompareClick: (Car) -> Unit,
  modifier: Modifier = Modifier
) {
  // Compute car counts by brand for chips
  val brandCounts = brands.associateWith { brand ->
    if (brand == "All") allCarsList.size
    else allCarsList.count { it.brand.equals(brand, ignoreCase = true) }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("browse_screen_list"),
    contentPadding = PaddingValues(bottom = 24.dp)
  ) {
    // Search Bar & Filter Button
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = filterState.searchQuery,
          onValueChange = onSearchChange,
          placeholder = {
            Text(
              text = "Search model, brand, or feature...",
              fontSize = 14.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          },
          trailingIcon = {
            if (filterState.searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchChange("") }) {
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = "Clear search",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
          ),
          modifier = Modifier
            .weight(1f)
            .testTag("browse_search_input")
        )

        // Filter button with badge
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = if (filterState.hasActiveFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (filterState.hasActiveFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
          ),
          modifier = Modifier
            .size(52.dp)
            .testTag("open_filters_sheet_button")
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenFilterSheet)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.Tune,
              contentDescription = "Open Filters",
              tint = if (filterState.hasActiveFilters) Color.White else MaterialTheme.colorScheme.onSurface
            )

            if (filterState.activeFilterCount > 0) {
              Box(
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .padding(6.dp)
                  .size(16.dp)
                  .clip(CircleShape)
                  .background(DealOrange),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "${filterState.activeFilterCount}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }
          }
        }
      }
    }

    // Horizontal Brand Filter Chips Row
    item {
      BrandFilterRow(
        brands = brands,
        selectedBrands = filterState.selectedBrands,
        onSelectBrand = onSelectBrand,
        brandCounts = brandCounts,
        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
      )
    }

    // Quick Quick-Filter Pills (Deals, Reset, etc.)
    item {
      val quickScrollState = rememberScrollState()
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(quickScrollState)
          .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Hot Deals Pill
        FilterChip(
          selected = filterState.onlyDeals,
          onClick = onToggleDealsOnly,
          label = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = if (filterState.onlyDeals) Color.White else DealOrange,
                modifier = Modifier.size(14.dp)
              )
              Text("Deals Only")
            }
          },
          modifier = Modifier.testTag("quick_deals_chip")
        )

        // Reset if filters active
        if (filterState.hasActiveFilters) {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .clickable(onClick = onResetFilters)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(14.dp)
              )
              Text(
                text = "Clear All Filters",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
              )
            }
          }
        }
      }
    }

    // Inventory Count & Sort Order summary
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "SHOWING ${cars.size} VEHICLES",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          letterSpacing = 1.sp
        )

        Text(
          text = filterState.sortBy.displayName,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onOpenFilterSheet)
            .padding(horizontal = 4.dp, vertical = 2.dp)
        )
      }
    }

    // Vehicle Cards List
    if (cars.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(40.dp)
            )
            Text(
              text = "No Vehicles Found",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "No cars matched your active brand or price filters. Try resetting filters or expanding your search criteria.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center
            )

            Button(
              onClick = onResetFilters,
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("Reset Filters")
            }
          }
        }
      }
    } else {
      items(cars, key = { it.id }) { car ->
        CarCard(
          car = car,
          isFavorite = favoriteIds.contains(car.id),
          isCompared = comparisonIds.contains(car.id),
          onCardClick = { onCarClick(car) },
          onFavoriteClick = { onFavoriteClick(car) },
          onCompareClick = { onCompareClick(car) },
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
      }
    }
  }
}
