package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.ui.theme.DealGreen
import com.example.ui.theme.DealOrange
import com.example.ui.theme.DealRed
import com.example.ui.theme.ElectricBlue
import java.util.Locale

@Composable
fun CarCard(
  car: Car,
  isFavorite: Boolean,
  isCompared: Boolean,
  onCardClick: () -> Unit,
  onFavoriteClick: () -> Unit,
  onCompareClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("car_card_${car.id}")
      .clip(RoundedCornerShape(18.dp))
      .clickable(onClick = onCardClick),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant
    ),
    border = androidx.compose.foundation.BorderStroke(
      width = if (car.isHotDeal) 1.5.dp else 1.dp,
      color = if (car.isHotDeal) DealOrange.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Top visual header with stylized automotive silhouette canvas & badges
      CarCardVisualHeader(
        car = car,
        isFavorite = isFavorite,
        isCompared = isCompared,
        onFavoriteClick = onFavoriteClick,
        onCompareClick = onCompareClick
      )

      // Content section
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Brand & Year / Model
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "${car.year} • ${car.brand.uppercase()}",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              letterSpacing = 1.sp
            )
            Text(
              text = car.model,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = car.trim,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          // Rating badge
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(14.dp)
              )
              Text(
                text = "${car.rating}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Key Specs Chips: 0-60, HP, Mileage, Fuel
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          SpecPill(
            label = "${car.zeroToSixty}s",
            sub = "0-60",
            modifier = Modifier.weight(1f)
          )
          SpecPill(
            label = "${car.horsepower} hp",
            sub = "Power",
            modifier = Modifier.weight(1f)
          )
          SpecPill(
            label = if (car.mileage == 0) "New" else "${String.format(Locale.US, "%,d", car.mileage)} mi",
            sub = "Odometer",
            modifier = Modifier.weight(1f)
          )
          SpecPill(
            label = car.drivetrain,
            sub = car.bodyType,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Spacer(modifier = Modifier.height(12.dp))

        // Price, Deal Savings & Monthly payment row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            if (car.originalPrice != null && car.originalPrice > car.price) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Text(
                  text = "$${String.format(Locale.US, "%,.0f", car.originalPrice)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textDecoration = TextDecoration.LineThrough
                )
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = DealGreen.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "SAVE $${String.format(Locale.US, "%,.0f", car.discountAmount)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = DealGreen,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
            }

            Text(
              text = "$${String.format(Locale.US, "%,.0f", car.price)}",
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = "Est. $${car.estimatedMonthlyPayment}/mo",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(12.dp)
              )
              Text(
                text = car.dealerLocation,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun CarCardVisualHeader(
  car: Car,
  isFavorite: Boolean,
  isCompared: Boolean,
  onFavoriteClick: () -> Unit,
  onCompareClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(130.dp)
      .background(
        Brush.horizontalGradient(
          colors = listOf(
            Color(car.gradientColors.getOrElse(0) { 0xFF1E293B }),
            Color(car.gradientColors.getOrElse(1) { 0xFF0F172A })
          )
        )
      )
  ) {
    // Canvas stylized sports car contour lines & atmospheric lighting
    Canvas(modifier = Modifier.matchParentSize()) {
      val w = size.width
      val h = size.height

      // Soft glow
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color.White.copy(alpha = 0.12f), Color.Transparent),
          center = Offset(w * 0.7f, h * 0.4f),
          radius = w * 0.5f
        )
      )

      // Speed contour curves
      val curvePath = Path().apply {
        moveTo(w * 0.1f, h * 0.75f)
        cubicTo(w * 0.35f, h * 0.70f, w * 0.45f, h * 0.30f, w * 0.65f, h * 0.32f)
        cubicTo(w * 0.85f, h * 0.34f, w * 0.95f, h * 0.60f, w * 1.05f, h * 0.65f)
      }
      drawPath(
        path = curvePath,
        color = Color.White.copy(alpha = 0.25f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
      )

      // Ground horizon line
      drawLine(
        color = Color.White.copy(alpha = 0.15f),
        start = Offset(0f, h * 0.85f),
        end = Offset(w, h * 0.85f),
        strokeWidth = 2.dp.toPx()
      )

      // Wheels hint
      drawCircle(
        color = Color.White.copy(alpha = 0.25f),
        center = Offset(w * 0.32f, h * 0.85f),
        radius = 16.dp.toPx(),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
      )
      drawCircle(
        color = Color.White.copy(alpha = 0.25f),
        center = Offset(w * 0.80f, h * 0.85f),
        radius = 16.dp.toPx(),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
      )
    }

    // Badges Row at Top
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top
    ) {
      // Condition or Deal Badge
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (car.isHotDeal && car.dealBadge != null) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = DealOrange,
            shadowElevation = 2.dp
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(13.dp)
              )
              Text(
                text = car.dealBadge,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color.Black.copy(alpha = 0.45f)
        ) {
          Text(
            text = car.condition,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.9f),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }

      // Quick Action Buttons (Compare & Bookmark)
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        // Compare toggle
        Surface(
          shape = CircleShape,
          color = if (isCompared) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.4f),
          modifier = Modifier
            .size(34.dp)
            .testTag("compare_btn_${car.id}")
            .clip(CircleShape)
            .clickable(onClick = onCompareClick)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (isCompared) Icons.Default.Check else Icons.Default.CompareArrows,
              contentDescription = "Compare car",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        // Favorite toggle
        val favTint by animateColorAsState(
          targetValue = if (isFavorite) DealRed else Color.White,
          label = "favTint"
        )
        Surface(
          shape = CircleShape,
          color = Color.Black.copy(alpha = 0.4f),
          modifier = Modifier
            .size(34.dp)
            .testTag("fav_btn_${car.id}")
            .clip(CircleShape)
            .clickable(onClick = onFavoriteClick)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Bookmark car",
              tint = favTint,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SpecPill(
  label: String,
  sub: String,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surface,
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
  ) {
    Column(
      modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Text(
        text = sub,
        style = MaterialTheme.typography.bodySmall,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1
      )
    }
  }
}
