package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.theme.RoseDanger

private val CATEGORIES = listOf("General", "Personal", "Work", "Finance", "Social")

@Composable
fun SaveCredentialDialog(
    initialPassword: String,
    onDismiss: () -> Unit,
    onSave: (label: String, password: String, username: String, category: String, notes: String) -> Unit
) {
    var label by remember { mutableStateOf("") }
    var password by remember { mutableStateOf(initialPassword) }
    var username by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Personal") }
    var notes by remember { mutableStateOf("") }
    var labelTouched by remember { mutableStateOf(false) }

    val isLabelValid = label.trim().isNotEmpty()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Save Credential to Vault",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "A label is required so you can easily identify and search for this credential later.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Mandatory Label Input
                OutlinedTextField(
                    value = label,
                    onValueChange = {
                        label = it
                        labelTouched = true
                    },
                    label = { Text("Label / Account Name *") },
                    placeholder = { Text("e.g., Netflix, Work Google, GitHub") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Label, contentDescription = null)
                    },
                    singleLine = true,
                    isError = labelTouched && !isLabelValid,
                    supportingText = {
                        if (labelTouched && !isLabelValid) {
                            Text(text = "Label cannot be empty", color = RoseDanger)
                        } else {
                            Text(text = "Required field")
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_label_input")
                )

                // Optional Username / Email
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username or Email (Optional)") },
                    placeholder = { Text("user@example.com") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_username_input")
                )

                // Category Chips
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CATEGORIES.forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            leadingIcon = if (selectedCategory == category) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = null
                                    )
                                }
                            } else null
                        )
                    }
                }

                // Password preview
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Key, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_password_input")
                )

                // Notes (Optional)
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    placeholder = { Text("e.g., Security questions, recovery codes") },
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    labelTouched = true
                    if (isLabelValid && password.isNotEmpty()) {
                        onSave(label.trim(), password, username.trim(), selectedCategory, notes.trim())
                    }
                },
                enabled = isLabelValid && password.isNotEmpty(),
                modifier = Modifier.testTag("save_dialog_confirm_button")
            ) {
                Text("Save Credential")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("save_dialog_cancel_button")
            ) {
                Text("Cancel")
            }
        }
    )
}
