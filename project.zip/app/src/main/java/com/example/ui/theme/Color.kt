package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Automotive Luxury Dark & Light Palette
val Slate950 = Color(0xFF090D16)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Dynamic Automotive Accents
val ElectricBlue = Color(0xFF2563EB)
val ElectricBlueLight = Color(0xFF60A5FA)
val CyanAccent = Color(0xFF06B6D4)

// Deal & Discount Highlights
val DealOrange = Color(0xFFF97316)
val DealRed = Color(0xFFEF4444)
val DealGreen = Color(0xFF10B981)
val DealGold = Color(0xFFF59E0B)

// Card & Background Tints
val DarkSurfaceCard = Color(0xFF161F30)
val DarkSurfaceElevated = Color(0xFF1E293B)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
