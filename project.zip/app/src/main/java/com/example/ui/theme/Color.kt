package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core Accents
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldLight = Color(0xFF34D399)
val EmeraldDark = Color(0xFF047857)

val AmberStreak = Color(0xFFF59E0B)
val AmberStreakLight = Color(0xFFFCD34D)

val CyanAccent = Color(0xFF06B6D4)
val VioletAccent = Color(0xFF8B5CF6)
val CrimsonQuit = Color(0xFFEF4444)
val CrimsonQuitLight = Color(0xFFF87171)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF131A29)
val DarkSurfaceVariant = Color(0xFF1E283D)
val DarkBorder = Color(0xFF28354F)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextSecondary = Color(0xFF9CA3AF)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Gamification Tiers
val BadgeBronze = Color(0xFFCD7F32)
val BadgeSilver = Color(0xFFC0C0C0)
val BadgeGold = Color(0xFFFFD700)
val BadgeDiamond = Color(0xFF67E8F9)
val BadgeMythic = Color(0xFFA855F7)
