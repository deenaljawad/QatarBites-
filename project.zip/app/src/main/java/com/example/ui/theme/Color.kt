package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cyan / Tech Blue
val CyberCyan = Color(0xFF0EA5E9)
val CyberCyanDark = Color(0xFF0284C7)
val CyberCyanLight = Color(0xFF38BDF8)

// Secondary Emerald / Security Shield
val SecurityTeal = Color(0xFF0D9488)
val SecurityTealLight = Color(0xFF2DD4BF)
val SecurityTealDark = Color(0xFF115E59)

// Accent & Status
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val DangerRedDark = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF10B981)

// Background & Surface
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
