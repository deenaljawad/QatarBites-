package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Qatar Maroon & Royal Gold Palette
val QatarMaroon = Color(0xFF8A1538)
val QatarMaroonDark = Color(0xFF560C22)
val QatarMaroonLight = Color(0xFFA62047)

val QatarGold = Color(0xFFD4AF37)
val QatarGoldLight = Color(0xFFF3E5AB)
val QatarGoldDark = Color(0xFFAA820A)

// Neutral & Backgrounds
val WarmSandLight = Color(0xFFFBF8F5)
val WarmSandSurface = Color(0xFFF3EDE6)
val TextDarkPrimary = Color(0xFF1E1719)
val TextDarkSecondary = Color(0xFF6B5E62)

// Dark Theme Colors
val DarkBackground = Color(0xFF120E10)
val DarkSurface = Color(0xFF1E171A)
val DarkSurfaceVariant = Color(0xFF2C2226)
val TextLightPrimary = Color(0xFFF8F4F5)
val TextLightSecondary = Color(0xFFB8ABB0)

// Status & Badge Colors
val LikeGreen = Color(0xFF22C55E)
val PassRed = Color(0xFFEF4444)
val SuperLikeBlue = Color(0xFF0EA5E9)
val StarGold = Color(0xFFFFB800)
