package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Culinary Palette for PantryCraft
val ForestGreen = Color(0xFF1E6B38)
val ForestGreenLight = Color(0xFF85D79B)
val ForestGreenDark = Color(0xFF0F4221)

val AmberAccent = Color(0xFFD97706)
val AmberAccentLight = Color(0xFFFBBF24)

val FreshTeal = Color(0xFF0D9488)
val FreshTealLight = Color(0xFF5EEAD4)

val WarmBgLight = Color(0xFFF8FAF7)
val WarmSurfaceLight = Color(0xFFFFFFFF)
val WarmSurfaceVariantLight = Color(0xFFEDF2EC)

val DarkBg = Color(0xFF121814)
val DarkSurface = Color(0xFF1A231C)
val DarkSurfaceVariant = Color(0xFF243027)

val TextPrimaryLight = Color(0xFF1B231D)
val TextSecondaryLight = Color(0xFF5A665D)

val TextPrimaryDark = Color(0xFFE8EFE9)
val TextSecondaryDark = Color(0xFFA5B2A8)
