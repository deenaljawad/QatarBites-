package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accents
val CyanAccent = Color(0xFF06B6D4)
val CyanAccentGlow = Color(0xFF22D3EE)
val ElectricIndigo = Color(0xFF6366F1)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseDanger = Color(0xFFF43F5E)

// Dark Palette
val DarkBg = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkBorder = Color(0xFF374151)
val DarkOnSurface = Color(0xFFF9FAFB)
val DarkOnSurfaceSubtle = Color(0xFF9CA3AF)

// Light Palette
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceElevated = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceSubtle = Color(0xFF64748B)

// Primary/Secondary tokens for M3 ColorScheme
val DarkPrimary = Color(0xFF22D3EE)
val DarkOnPrimary = Color(0xFF083344)
val DarkPrimaryContainer = Color(0xFF164E63)
val DarkOnPrimaryContainer = Color(0xFFCFFAFE)

val DarkSecondary = Color(0xFF818CF8)
val DarkOnSecondary = Color(0xFF1E1B4B)
val DarkSecondaryContainer = Color(0xFF312E81)
val DarkOnSecondaryContainer = Color(0xFFE0E7FF)

val LightPrimary = Color(0xFF0891B2)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFCFFAFE)
val LightOnPrimaryContainer = Color(0xFF164E63)

val LightSecondary = Color(0xFF4F46E5)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFE0E7FF)
val LightOnSecondaryContainer = Color(0xFF312E81)
