package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.data.HabitLogEntity
import com.example.data.HabitType
import com.example.data.UserStatsEntity
import com.example.model.GamificationManager
import com.example.ui.components.HabitCard
import com.example.ui.components.LevelProgressCard
import com.example.ui.components.QuitHabitCard
import com.example.ui.theme.EmeraldPrimary

enum class HabitFilter {
    ALL,
    START_ONLY,
    QUIT_ONLY,
    PENDING,
    COMPLETED
}

@Composable
fun TodayScreen(
    habits: List<HabitEntity>,
    todayLogs: Map<Long, HabitLogEntity>,
    userStats: UserStatsEntity?,
    levelInfo: GamificationManager.LevelInfo,
    onToggleHabit: (HabitEntity) -> Unit,
    onIncrementHabit: (HabitEntity, Double) -> Unit,
    onRecordSlip: (Long) -> Unit,
    onCheckCleanToday: (HabitEntity) -> Unit,
    onEditHabit: (HabitEntity) -> Unit,
    onAddNewHabit: () -> Unit,
    onViewBadges: () -> Unit,
    onTestNotification: (HabitEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeFilter by remember { mutableStateOf(HabitFilter.ALL) }

    val filteredHabits = remember(habits, todayLogs, activeFilter) {
        habits.filter { habit ->
            val isCompleted = todayLogs[habit.id]?.isCompleted ?: false
            when (activeFilter) {
                HabitFilter.ALL -> true
                HabitFilter.START_ONLY -> habit.type == HabitType.BUILD
                HabitFilter.QUIT_ONLY -> habit.type == HabitType.BREAK
                HabitFilter.PENDING -> !isCompleted
                HabitFilter.COMPLETED -> isCompleted
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("today_screen_list"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Level progress and gamification overview
            item {
                LevelProgressCard(
                    stats = userStats,
                    levelInfo = levelInfo,
                    onViewBadgesClick = onViewBadges
                )
            }

            // Filter Tabs
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChipButton(
                        label = "All (${habits.size})",
                        isSelected = activeFilter == HabitFilter.ALL,
                        onClick = { activeFilter = HabitFilter.ALL },
                        modifier = Modifier.weight(1f)
                    )

                    FilterChipButton(
                        label = "Start",
                        isSelected = activeFilter == HabitFilter.START_ONLY,
                        onClick = { activeFilter = HabitFilter.START_ONLY },
                        modifier = Modifier.weight(1f)
                    )

                    FilterChipButton(
                        label = "Quit",
                        isSelected = activeFilter == HabitFilter.QUIT_ONLY,
                        onClick = { activeFilter = HabitFilter.QUIT_ONLY },
                        modifier = Modifier.weight(1f)
                    )

                    FilterChipButton(
                        label = "Pending",
                        isSelected = activeFilter == HabitFilter.PENDING,
                        onClick = { activeFilter = HabitFilter.PENDING },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Habits List
            if (filteredHabits.isEmpty()) {
                item {
                    EmptyHabitsCard(
                        filter = activeFilter,
                        onAddNew = onAddNewHabit
                    )
                }
            } else {
                items(filteredHabits, key = { it.id }) { habit ->
                    val log = todayLogs[habit.id]
                    if (habit.type == HabitType.BUILD) {
                        HabitCard(
                            habit = habit,
                            log = log,
                            onToggleComplete = { onToggleHabit(habit) },
                            onIncrement = { delta -> onIncrementHabit(habit, delta) },
                            onEditClick = { onEditHabit(habit) },
                            onTestNotification = { onTestNotification(habit) }
                        )
                    } else {
                        QuitHabitCard(
                            habit = habit,
                            log = log,
                            onCheckCleanToday = { onCheckCleanToday(habit) },
                            onRecordSlip = { onRecordSlip(habit.id) },
                            onEditClick = { onEditHabit(habit) },
                            onTestNotification = { onTestNotification(habit) }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button to Add Habit
        FloatingActionButton(
            onClick = onAddNewHabit,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_habit_fab"),
            containerColor = EmeraldPrimary,
            contentColor = Color.Black
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Create Habit Quest"
            )
        }
    }
}

@Composable
private fun FilterChipButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.padding(vertical = 7.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun EmptyHabitsCard(
    filter: HabitFilter,
    onAddNew: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (filter == HabitFilter.ALL) "No Habits Yet!" else "No Habits in this filter",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Add your first habit to earn XP and level up!",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = EmeraldPrimary,
                modifier = Modifier.clickable(onClick = onAddNew)
            ) {
                Text(
                    text = "Create Habit Quest",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}
