package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Booking
import com.example.data.models.BookingStatus
import com.example.data.models.PaymentStatus
import com.example.data.models.ScamReport
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import com.example.data.models.UrgencyLevel
import com.example.ui.MainViewModel
import com.example.ui.components.StatusPill
import com.example.ui.components.UrgencyBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SecurityTeal
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val services by viewModel.services.collectAsState()
    val scamReports by viewModel.scamReports.collectAsState()

    var activeAdminTab by remember { mutableIntStateOf(0) } // 0: Bookings, 1: Services, 2: Scam Reports
    var bookingFilter by remember { mutableStateOf("ALL") }
    var showAddServiceDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val techniciansList = listOf(
        "Alex Rivera (Lead Cyber Analyst)",
        "Sarah Chen (Hardware Tech Lead)",
        "David Miller (Remote Support Genius)",
        "Rapid Emergency Security Unit",
        "Elena Rostova (Identity & Anti-Fraud)"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Admin Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TechHelp4U Admin Console",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Operational control, booking dispatch & catalog editor",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // KPI Summary Cards
        val totalRevenue = bookings.filter { it.paymentStatus == PaymentStatus.PAID }.sumOf { it.amountPaid }
        val activeBookingsCount = bookings.count { it.status != BookingStatus.COMPLETED && it.status != BookingStatus.CANCELLED }
        val scamAlertsCount = scamReports.size + bookings.count { it.category == ServiceCategory.SCAM_SPAM }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            KpiMetricCard(
                title = "Total Revenue",
                value = "$${String.format("%.0f", totalRevenue)}",
                subtitle = "Paid bookings",
                icon = Icons.Default.AttachMoney,
                color = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            KpiMetricCard(
                title = "Active Jobs",
                value = "$activeBookingsCount",
                subtitle = "In dispatch/queue",
                icon = Icons.Default.SupportAgent,
                color = CyberCyan,
                modifier = Modifier.weight(1f)
            )
            KpiMetricCard(
                title = "Scam Alerts",
                value = "$scamAlertsCount",
                subtitle = "High priority",
                icon = Icons.Default.Warning,
                color = DangerRed,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Admin Navigation Tabs
        ScrollableTabRow(
            selectedTabIndex = activeAdminTab,
            edgePadding = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = activeAdminTab == 0,
                onClick = { activeAdminTab = 0 },
                text = { Text("Bookings Queue (${bookings.size})", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = activeAdminTab == 1,
                onClick = { activeAdminTab = 1 },
                text = { Text("Service Catalog (${services.size})", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = activeAdminTab == 2,
                onClick = { activeAdminTab = 2 },
                text = { Text("Scam Incident Feed (${scamReports.size})", fontWeight = FontWeight.SemiBold) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activeAdminTab) {
            0 -> {
                // Bookings Management
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = bookingFilter == "ALL",
                        onClick = { bookingFilter = "ALL" },
                        label = { Text("All", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = bookingFilter == "CONFIRMED",
                        onClick = { bookingFilter = "CONFIRMED" },
                        label = { Text("Confirmed", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = bookingFilter == "IN_PROGRESS",
                        onClick = { bookingFilter = "IN_PROGRESS" },
                        label = { Text("In Progress", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = bookingFilter == "COMPLETED",
                        onClick = { bookingFilter = "COMPLETED" },
                        label = { Text("Completed", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val filteredBookings = when (bookingFilter) {
                    "CONFIRMED" -> bookings.filter { it.status == BookingStatus.CONFIRMED }
                    "IN_PROGRESS" -> bookings.filter { it.status == BookingStatus.IN_PROGRESS }
                    "COMPLETED" -> bookings.filter { it.status == BookingStatus.COMPLETED }
                    else -> bookings
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredBookings, key = { it.id }) { booking ->
                        AdminBookingCard(
                            booking = booking,
                            technicians = techniciansList,
                            onUpdateStatus = { newStatus ->
                                viewModel.updateBookingStatus(booking, newStatus)
                                Toast.makeText(context, "Status changed to ${newStatus.label}", Toast.LENGTH_SHORT).show()
                            },
                            onAssignTechnician = { tech ->
                                viewModel.updateBookingStatus(booking, booking.status, technician = tech)
                                Toast.makeText(context, "Assigned to $tech", Toast.LENGTH_SHORT).show()
                            },
                            onUpdateNotes = { notes ->
                                viewModel.updateBookingStatus(booking, booking.status, notes = notes)
                                Toast.makeText(context, "Notes saved", Toast.LENGTH_SHORT).show()
                            },
                            onTogglePayment = {
                                val newPayment = if (booking.paymentStatus == PaymentStatus.PAID) PaymentStatus.REFUNDED else PaymentStatus.PAID
                                viewModel.updatePaymentStatus(booking, newPayment)
                            },
                            onDelete = {
                                viewModel.deleteBooking(booking)
                                Toast.makeText(context, "Booking ${booking.id} deleted", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }

            1 -> {
                // Service Catalog Management
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Manage Available Tech Services",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = { showAddServiceDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("admin_add_service_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Service")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(services, key = { it.id }) { service ->
                        AdminServiceCard(
                            service = service,
                            onToggleAvailability = { viewModel.toggleServiceAvailability(service) },
                            onPriceChange = { newPrice -> viewModel.updateServicePrice(service, newPrice) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }

            2 -> {
                // Scam Incident Feed
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(scamReports, key = { it.id }) { report ->
                        AdminScamReportCard(report = report)
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }

    // Add Service Dialog
    if (showAddServiceDialog) {
        AdminAddServiceDialog(
            onDismiss = { showAddServiceDialog = false },
            onAdd = { newService ->
                viewModel.addNewService(newService)
                showAddServiceDialog = false
                Toast.makeText(context, "Service '${newService.title}' created!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f))
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AdminBookingCard(
    booking: Booking,
    technicians: List<String>,
    onUpdateStatus: (BookingStatus) -> Unit,
    onAssignTechnician: (String) -> Unit,
    onUpdateNotes: (String) -> Unit,
    onTogglePayment: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedTechMenu by remember { mutableStateOf(false) }
    var expandedStatusMenu by remember { mutableStateOf(false) }
    var notesText by remember { mutableStateOf(booking.adminNotes) }
    var showEditNotes by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = booking.id,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    UrgencyBadge(urgency = booking.urgencyLevel)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(status = booking.status)
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Text(
                text = booking.serviceTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Client: ${booking.customerName} • ${booking.customerPhone}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Mode/Address: ${booking.serviceModeDetail}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Issue: ${booking.issueDescription}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            // Admin Dispatch Actions
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Status Dropdown
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { expandedStatusMenu = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Status: ${booking.status.name}", fontSize = 11.sp, maxLines = 1)
                    }
                    DropdownMenu(
                        expanded = expandedStatusMenu,
                        onDismissRequest = { expandedStatusMenu = false }
                    ) {
                        BookingStatus.values().forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status.label) },
                                onClick = {
                                    onUpdateStatus(status)
                                    expandedStatusMenu = false
                                }
                            )
                        }
                    }
                }

                // Technician Dropdown
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { expandedTechMenu = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Assign Tech", fontSize = 11.sp, maxLines = 1)
                    }
                    DropdownMenu(
                        expanded = expandedTechMenu,
                        onDismissRequest = { expandedTechMenu = false }
                    ) {
                        technicians.forEach { tech ->
                            DropdownMenuItem(
                                text = { Text(tech) },
                                onClick = {
                                    onAssignTechnician(tech)
                                    expandedTechMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // Current assigned tech banner
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SecurityTeal.copy(alpha = 0.1f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "Tech: ${booking.assignedTechnician ?: "Unassigned"}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SecurityTeal
                )
                Text(
                    text = "${booking.paymentStatus.name} ($${String.format("%.2f", booking.amountPaid)})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (booking.paymentStatus == PaymentStatus.PAID) SuccessGreen else WarningAmber,
                    modifier = Modifier.clickable { onTogglePayment() }
                )
            }

            // Notes Section
            if (showEditNotes) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Technician Dispatch Notes") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            onUpdateNotes(notesText)
                            showEditNotes = false
                        }
                    ) {
                        Text("Save")
                    }
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Notes: ${booking.adminNotes.ifEmpty { "None" }}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showEditNotes = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit notes", modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminServiceCard(
    service: TechService,
    onToggleAvailability: () -> Unit,
    onPriceChange: (Double) -> Unit
) {
    var isEditingPrice by remember { mutableStateOf(false) }
    var priceText by remember { mutableStateOf(service.price.toString()) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = service.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = service.category.name,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )
                }
                Text(
                    text = service.tagline,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isEditingPrice) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.width(90.dp)
                        )
                        IconButton(onClick = {
                            val newPrice = priceText.toDoubleOrNull() ?: service.price
                            onPriceChange(newPrice)
                            isEditingPrice = false
                        }) {
                            Icon(Icons.Default.Check, contentDescription = "Save price")
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "$${String.format("%.2f", service.price)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp
                        )
                        IconButton(onClick = { isEditingPrice = true }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit price", modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (service.isAvailable) "Active" else "Hidden",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (service.isAvailable) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Switch(
                    checked = service.isAvailable,
                    onCheckedChange = { onToggleAvailability() }
                )
            }
        }
    }
}

@Composable
fun AdminScamReportCard(report: ScamReport) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = report.id,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = DangerRed
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(DangerRed.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = report.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DangerRed
                    )
                }
            }

            Text(
                text = report.scamType,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Reporter: ${report.reporterName} • ${report.contactPhone}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "Details: ${report.details}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (report.financialLossReported) {
                Text(
                    text = "⚠️ Financial Loss Reported: $${String.format("%.2f", report.lossAmount)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = DangerRed
                )
            }
        }
    }
}

@Composable
fun AdminAddServiceDialog(
    onDismiss: () -> Unit,
    onAdd: (TechService) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(ServiceCategory.VIRTUAL) }
    var tagline by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("49.00") }
    var durationText by remember { mutableStateOf("45") }
    var featuresText by remember { mutableStateOf("Fast diagnostic|Experienced certified tech|Warranty included") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Service to Catalog", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Service Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ServiceCategory.values().forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.name, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = tagline,
                    onValueChange = { tagline = it },
                    label = { Text("Tagline / Short Hook") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Full Description") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it },
                        label = { Text("Duration (mins)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = featuresText,
                    onValueChange = { featuresText = it },
                    label = { Text("Features (separated by |)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceText.toDoubleOrNull() ?: 49.00
                    val duration = durationText.toIntOrNull() ?: 45
                    val newService = TechService(
                        id = "custom_" + System.currentTimeMillis().toString().takeLast(6),
                        title = title.ifBlank { "Custom Tech Support" },
                        category = category,
                        tagline = tagline.ifBlank { "Specialized technician assistance" },
                        description = description.ifBlank { "Professional technical support session." },
                        price = price,
                        durationMinutes = duration,
                        isEmergency = false,
                        features = featuresText,
                        iconType = "remote"
                    )
                    onAdd(newService)
                }
            ) {
                Text("Add Service")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
