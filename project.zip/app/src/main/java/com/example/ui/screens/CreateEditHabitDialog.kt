package com.example.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.FrequencyType
import com.example.data.HabitEntity
import com.example.data.HabitType
import com.example.ui.components.formatTime
import com.example.ui.components.getHabitIcon
import com.example.ui.components.parseColor
import com.example.ui.theme.CrimsonQuit
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateEditHabitDialog(
    initialHabit: HabitEntity? = null,
    onSave: (HabitEntity) -> Unit,
    onDelete: ((HabitEntity) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initialHabit?.title ?: "") }
    var habitType by remember { mutableStateOf(initialHabit?.type ?: HabitType.BUILD) }
    var frequencyType by remember { mutableStateOf(initialHabit?.frequencyType ?: FrequencyType.DAILY) }

    // Target days of week (1=Mon ... 7=Sun)
    var selectedDays by remember {
        mutableStateOf(initialHabit?.targetDaysOfWeek ?: listOf(1, 2, 3, 4, 5, 6, 7))
    }

    // Number & Unit (e.g. 1 time, 4 meters, 5 km, 9 grams)
    var targetNumberText by remember {
        mutableStateOf(
            if (initialHabit != null) {
                if (initialHabit.targetValue % 1.0 == 0.0) "${initialHabit.targetValue.toInt()}" else "${initialHabit.targetValue}"
            } else "1"
        )
    }
    var unitText by remember { mutableStateOf(initialHabit?.unit ?: "times") }

    // Reminders
    var reminderEnabled by remember { mutableStateOf(initialHabit?.reminderEnabled ?: false) }
    var reminderHour by remember { mutableIntStateOf(initialHabit?.reminderHour ?: 8) }
    var reminderMinute by remember { mutableIntStateOf(initialHabit?.reminderMinute ?: 0) }

    var selectedColorHex by remember { mutableStateOf(initialHabit?.colorHex ?: if (habitType == HabitType.BUILD) "#10B981" else "#EF4444") }
    var selectedIconName by remember { mutableStateOf(initialHabit?.iconName ?: if (habitType == HabitType.BUILD) "fitness" else "quit") }

    val colorOptions = listOf(
        "#10B981", // Emerald
        "#0EA5E9", // Sky Blue
        "#8B5CF6", // Violet
        "#F59E0B", // Amber
        "#EF4444", // Crimson
        "#06B6D4", // Cyan
        "#EC4899"  // Pink
    )

    val iconOptions = listOf(
        "fitness",
        "run",
        "water",
        "book",
        "meditation"
    )

    val unitSuggestions = listOf("times", "km", "meters", "grams", "glasses", "mins", "pages", "hours")

    val quickHabitSuggestions = if (habitType == HabitType.BUILD) {
        listOf("Go to the Gym", "Drink Water", "Morning Run", "Read Book", "Meditate", "Cold Shower")
    } else {
        listOf("Quit Smoking", "Stop Biting Nails", "No Social Media", "No Junk Food", "Stop Doomscrolling")
    }

    val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(24.dp))
                .testTag("create_edit_habit_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (initialHabit == null) "New Habit Quest" else "Edit Habit",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Selector: Start Habit (Build) vs Quit Habit (Break)
                Text(
                    text = "HABIT TYPE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (habitType == HabitType.BUILD) 2.dp else 1.dp,
                                color = if (habitType == HabitType.BUILD) EmeraldPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                habitType = HabitType.BUILD
                                if (selectedColorHex == "#EF4444") selectedColorHex = "#10B981"
                                if (unitText == "day clean") unitText = "times"
                            }
                            .testTag("type_start_button"),
                        color = if (habitType == HabitType.BUILD) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Start a Habit",
                                fontWeight = FontWeight.Bold,
                                color = if (habitType == HabitType.BUILD) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Build positive routines",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (habitType == HabitType.BREAK) 2.dp else 1.dp,
                                color = if (habitType == HabitType.BREAK) CrimsonQuit else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                habitType = HabitType.BREAK
                                selectedColorHex = "#EF4444"
                                unitText = "day clean"
                            }
                            .testTag("type_quit_button"),
                        color = if (habitType == HabitType.BREAK) CrimsonQuit.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Quit a Habit",
                                fontWeight = FontWeight.Bold,
                                color = if (habitType == HabitType.BREAK) CrimsonQuit else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Overcome unwanted urges",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Name TextField
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Habit Name (e.g. Go to the gym)") },
                    placeholder = { Text("What habit do you want to master?") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("habit_name_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick suggestions
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickHabitSuggestions.forEach { suggestion ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { title = suggestion }
                        ) {
                            Text(
                                text = "+ $suggestion",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Frequency Selector
                Text(
                    text = "HOW OFTEN?",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        FrequencyType.DAILY to "Daily",
                        FrequencyType.SPECIFIC_DAYS to "Specific Days",
                        FrequencyType.WEEKLY to "Weekly",
                        FrequencyType.MONTHLY to "Monthly"
                    ).forEach { (freq, label) ->
                        val isSelected = frequencyType == freq
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) borderBorder(MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { frequencyType = freq }
                                .testTag("freq_${freq.name}")
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // If specific days: show Mon-Sun chips
                if (frequencyType == FrequencyType.SPECIFIC_DAYS) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Select days of the week:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        for (i in 1..7) {
                            val isDaySelected = selectedDays.contains(i)
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isDaySelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable {
                                        selectedDays = if (isDaySelected) {
                                            selectedDays.filter { it != i }
                                        } else {
                                            (selectedDays + i).sorted()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = dayNames[i - 1],
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDaySelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Target Number & Custom Unit
                Text(
                    text = "TARGET GOAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = targetNumberText,
                        onValueChange = { targetNumberText = it },
                        label = { Text("Number") },
                        placeholder = { Text("1, 4, 5, 9") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("target_number_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = unitText,
                        onValueChange = { unitText = it },
                        label = { Text("Unit") },
                        placeholder = { Text("km, meters, grams, times") },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("unit_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Unit suggestions chips
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    unitSuggestions.forEach { u ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { unitText = u }
                        ) {
                            Text(
                                text = u,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Daily Reminder Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Daily Reminder Notification",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "Get a motivating push to stay consistent",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = reminderEnabled,
                                onCheckedChange = { reminderEnabled = it },
                                modifier = Modifier.testTag("reminder_switch"),
                                colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                            )
                        }

                        if (reminderEnabled) {
                            Spacer(modifier = Modifier.height(12.dp))

                            val openTimePickerDialog = {
                                TimePickerDialog(
                                    context,
                                    { _, selectedHour, selectedMinute ->
                                        reminderHour = selectedHour
                                        reminderMinute = selectedMinute
                                    },
                                    reminderHour,
                                    reminderMinute,
                                    false
                                ).show()
                            }

                            // Scheduled Time Display & Clock Dialog Trigger
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = borderBorder(MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { openTimePickerDialog() }
                                    .testTag("scheduled_time_display")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(EmeraldPrimary.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AccessTime,
                                                contentDescription = null,
                                                tint = EmeraldPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Notification Time",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = formatTime(reminderHour, reminderMinute),
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 18.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = openTimePickerDialog,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("open_clock_picker_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Pick Time", fontSize = 12.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Inline Any Time Fine-Tuning (Hour, Minute, AM/PM)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "ADJUST TO ANY TIME",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    val isPm = reminderHour >= 12
                                    val hour12 = if (reminderHour % 12 == 0) 12 else reminderHour % 12

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        // Hour Stepper (1 to 12)
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconButton(
                                                onClick = {
                                                    reminderHour = (reminderHour + 1) % 24
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("hour_up_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.KeyboardArrowUp,
                                                    contentDescription = "Hour Up"
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.padding(horizontal = 4.dp)
                                            ) {
                                                Text(
                                                    text = String.format("%02d", hour12),
                                                    fontSize = 20.sp,
                                                    fontWeight = FontWeight.Black,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    reminderHour = if (reminderHour - 1 < 0) 23 else reminderHour - 1
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("hour_down_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.KeyboardArrowDown,
                                                    contentDescription = "Hour Down"
                                                )
                                            }
                                            Text(
                                                text = "Hour",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Text(
                                            text = ":",
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)
                                        )

                                        // Minute Stepper (0 to 59)
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconButton(
                                                onClick = {
                                                    reminderMinute = (reminderMinute + 1) % 60
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("minute_up_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.KeyboardArrowUp,
                                                    contentDescription = "Minute Up"
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.padding(horizontal = 4.dp)
                                            ) {
                                                Text(
                                                    text = String.format("%02d", reminderMinute),
                                                    fontSize = 20.sp,
                                                    fontWeight = FontWeight.Black,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    reminderMinute = if (reminderMinute - 1 < 0) 59 else reminderMinute - 1
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("minute_down_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.KeyboardArrowDown,
                                                    contentDescription = "Minute Down"
                                                )
                                            }
                                            Text(
                                                text = "Minute",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        // AM / PM Toggle
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (!isPm) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier
                                                    .clickable {
                                                        if (isPm) {
                                                            reminderHour = (reminderHour - 12).coerceAtLeast(0)
                                                        }
                                                    }
                                                    .testTag("am_selector_button")
                                            ) {
                                                Text(
                                                    text = "AM",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (!isPm) Color.Black else MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isPm) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier
                                                    .clickable {
                                                        if (!isPm) {
                                                            reminderHour = (reminderHour + 12).coerceAtMost(23)
                                                        }
                                                    }
                                                    .testTag("pm_selector_button")
                                            ) {
                                                Text(
                                                    text = "PM",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isPm) Color.Black else MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Quick minute adjustments
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf(
                                            ":00" to { reminderMinute = 0 },
                                            ":15" to { reminderMinute = 15 },
                                            ":30" to { reminderMinute = 30 },
                                            ":45" to { reminderMinute = 45 },
                                            "+5m" to { reminderMinute = (reminderMinute + 5) % 60 },
                                            "-5m" to { reminderMinute = if (reminderMinute - 5 < 0) 55 else reminderMinute - 5 }
                                        ).forEach { (label, action) ->
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable(onClick = action)
                                            ) {
                                                Text(
                                                    text = label,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    modifier = Modifier.padding(vertical = 4.dp),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Color accent picker
                Text(
                    text = "THEME COLOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    colorOptions.forEach { hex ->
                        val color = parseColor(hex)
                        val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColorHex = hex }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons: Save & Delete
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (initialHabit != null && onDelete != null) {
                        OutlinedButton(
                            onClick = {
                                onDelete(initialHabit)
                                onDismiss()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("delete_habit_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = CrimsonQuit,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val targetVal = targetNumberText.toDoubleOrNull()?.coerceAtLeast(0.1) ?: 1.0
                                val habitToSave = (initialHabit ?: HabitEntity(
                                    title = title.trim(),
                                    type = habitType,
                                    frequencyType = frequencyType
                                )).copy(
                                    title = title.trim(),
                                    type = habitType,
                                    frequencyType = frequencyType,
                                    targetDaysOfWeek = if (frequencyType == FrequencyType.SPECIFIC_DAYS) {
                                        if (selectedDays.isEmpty()) listOf(1, 2, 3, 4, 5, 6, 7) else selectedDays
                                    } else listOf(1, 2, 3, 4, 5, 6, 7),
                                    targetValue = targetVal,
                                    unit = if (unitText.isBlank()) "times" else unitText.trim(),
                                    reminderEnabled = reminderEnabled,
                                    reminderHour = if (reminderEnabled) reminderHour else null,
                                    reminderMinute = if (reminderEnabled) reminderMinute else null,
                                    colorHex = selectedColorHex,
                                    iconName = selectedIconName
                                )
                                onSave(habitToSave)
                                onDismiss()
                            }
                        },
                        modifier = Modifier
                            .weight(3f)
                            .testTag("save_habit_button"),
                        enabled = title.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (initialHabit == null) "Create Quest (+50 XP)" else "Save Changes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

private fun borderBorder(color: Color) = androidx.compose.foundation.BorderStroke(1.5.dp, color)
