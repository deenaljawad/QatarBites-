package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.ui.theme.DealGreen
import com.example.ui.theme.DealOrange
import com.example.ui.theme.DealRed
import java.util.Locale

@Composable
fun DealsScreen(
  dealCars: List<Car>,
  brands: List<String>,
  selectedBrand: String,
  favoriteIds: Set<String>,
  comparisonIds: Set<String>,
  onSelectBrand: (String) -> Unit,
  onCarClick: (Car) -> Unit,
  onFavoriteClick: (Car) -> Unit,
  onCompareClick: (Car) -> Unit,
  modifier: Modifier = Modifier
) {
  val totalSavings = dealCars.sumOf { it.discountAmount }
  val maxDiscount = dealCars.maxOfOrNull { it.discountAmount } ?: 0.0

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("deals_screen_list"),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
  ) {
    // Top Hero Showcase Banner
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        DealBannerCard(
          dealsCount = dealCars.size,
          onExploreDealsClick = { /* already on deals tab */ }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Deal Statistics Bar
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            DealStatItem(
              icon = Icons.Default.Savings,
              tint = DealGreen,
              value = "$${String.format(Locale.US, "%,.0f", totalSavings)}",
              label = "Total Pool Savings"
            )

            Box(
              modifier = Modifier
                .size(width = 1.dp, height = 36.dp)
                .background(MaterialTheme.colorScheme.outlineVariant)
            )

            DealStatItem(
              icon = Icons.Default.LocalFireDepartment,
              tint = DealOrange,
              value = "$${String.format(Locale.US, "%,.0f", maxDiscount)}",
              label = "Max Single Discount"
            )

            Box(
              modifier = Modifier
                .size(width = 1.dp, height = 36.dp)
                .background(MaterialTheme.colorScheme.outlineVariant)
            )

            DealStatItem(
              icon = Icons.Default.Percent,
              tint = MaterialTheme.colorScheme.primary,
              value = "${dealCars.size} Models",
              label = "Marked Down"
            )
          }
        }
      }
    }

    // Brand filter header for deals
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 10.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "FILTER DEALS BY BRAND",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 1.sp
          )
          Text(
            text = "${dealCars.size} Active Deals",
            style = MaterialTheme.typography.labelSmall,
            color = DealOrange,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        BrandFilterRow(
          brands = brands,
          selectedBrands = if (selectedBrand == "All") emptySet() else setOf(selectedBrand),
          onSelectBrand = onSelectBrand
        )
      }
    }

    // List of Deal Cars
    if (dealCars.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(36.dp)
            )
            Text(
              text = "No Deals Found for $selectedBrand",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Check back soon or select another brand to view active markdowns.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(dealCars, key = { it.id }) { car ->
        CarCard(
          car = car,
          isFavorite = favoriteIds.contains(car.id),
          isCompared = comparisonIds.contains(car.id),
          onCardClick = { onCarClick(car) },
          onFavoriteClick = { onFavoriteClick(car) },
          onCompareClick = { onCompareClick(car) },
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
      }
    }
  }
}

@Composable
private fun DealStatItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  value: String,
  label: String
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      fontSize = 10.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}
