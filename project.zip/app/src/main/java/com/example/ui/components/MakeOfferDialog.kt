package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import java.util.Locale

@Composable
fun MakeOfferDialog(
  car: Car,
  onDismiss: () -> Unit,
  onSubmitOffer: (amount: Double, hasTradeIn: Boolean, message: String) -> Unit
) {
  // Suggest offer between 85% and 100% of price
  val minOffer = (car.price * 0.85).toFloat()
  val maxOffer = car.price.toFloat()
  var offerSlider by remember { mutableFloatStateOf(car.price.toFloat() * 0.94f) }
  var hasTradeIn by remember { mutableStateOf(false) }
  var note by remember { mutableStateOf("Ready to close deal this week upon inspection.") }

  AlertDialog(
    onDismissRequest = onDismiss,
    shape = RoundedCornerShape(20.dp),
    containerColor = MaterialTheme.colorScheme.surface,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.LocalOffer,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.tertiary
        )
        Text(
          text = "Make an Offer",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = "${car.year} ${car.brand} ${car.model}",
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
        Text(
          text = "Listed Price: $${String.format(Locale.US, "%,.0f", car.price)}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Your Offer:",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = "$${String.format(Locale.US, "%,.0f", offerSlider.toDouble())}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
          )
        }

        Slider(
          value = offerSlider,
          onValueChange = { offerSlider = it },
          valueRange = minOffer..maxOffer,
          steps = 20,
          colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary),
          modifier = Modifier.testTag("offer_price_slider")
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "$${String.format(Locale.US, "%,.0f", minOffer.toDouble())}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "$${String.format(Locale.US, "%,.0f", maxOffer.toDouble())}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "I have a trade-in vehicle",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = "Appraise current vehicle value",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Switch(
            checked = hasTradeIn,
            onCheckedChange = { hasTradeIn = it },
            modifier = Modifier.testTag("trade_in_switch")
          )
        }

        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("Note to Dealer") },
          maxLines = 2,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("offer_message_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSubmitOffer(offerSlider.toDouble(), hasTradeIn, note)
        },
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.testTag("submit_offer_button")
      ) {
        Text("Submit Offer")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
