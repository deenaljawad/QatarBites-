package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.RiskLevel
import com.example.data.ScamAnalysisResult
import com.example.data.TechHelpRepository
import com.example.data.models.Booking
import com.example.data.models.BookingStatus
import com.example.data.models.PaymentStatus
import com.example.data.models.ScamReport
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import com.example.data.models.UrgencyLevel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab(val title: String) {
    HOME("Services"),
    BOOKINGS("My Bookings"),
    SCAM_TOOLS("Scam Defense"),
    ADMIN("Admin Portal")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = TechHelpRepository(
        database.serviceDao(),
        database.bookingDao(),
        database.scamReportDao()
    )

    val services: StateFlow<List<TechService>> = repository.allServices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookings: StateFlow<List<Booking>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scamReports: StateFlow<List<ScamReport>> = repository.allScamReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Tab
    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    // Category filter on Home
    private val _selectedCategory = MutableStateFlow<ServiceCategory?>(null)
    val selectedCategory: StateFlow<ServiceCategory?> = _selectedCategory.asStateFlow()

    fun selectCategory(category: ServiceCategory?) {
        _selectedCategory.value = category
    }

    // Active Booking Checkout Flow State
    private val _selectedServiceForBooking = MutableStateFlow<TechService?>(null)
    val selectedServiceForBooking: StateFlow<TechService?> = _selectedServiceForBooking.asStateFlow()

    private val _bookingStep = MutableStateFlow(0) // 0: DateTime, 1: Details & Mode, 2: Payment, 3: Confirmation
    val bookingStep: StateFlow<Int> = _bookingStep.asStateFlow()

    private val _createdBooking = MutableStateFlow<Booking?>(null)
    val createdBooking: StateFlow<Booking?> = _createdBooking.asStateFlow()

    // Form fields
    val customerName = MutableStateFlow("Jane Doe")
    val customerEmail = MutableStateFlow("jane.doe@example.com")
    val customerPhone = MutableStateFlow("+1 (555) 234-5678")
    val appointmentDate = MutableStateFlow("Today")
    val appointmentTimeSlot = MutableStateFlow("2:00 PM - 3:00 PM")
    val serviceModeDetail = MutableStateFlow("")
    val issueDescription = MutableStateFlow("")
    val urgencyLevel = MutableStateFlow(UrgencyLevel.NORMAL)

    // Payment fields
    val paymentMethodType = MutableStateFlow("CARD") // "CARD", "GPAY", "CASH"
    val cardNumber = MutableStateFlow("4242 •••• •••• 4242")
    val cardExpiry = MutableStateFlow("12/28")
    val cardCvv = MutableStateFlow("384")
    val cardHolder = MutableStateFlow("JANE DOE")
    val promoCode = MutableStateFlow("")
    val promoDiscount = MutableStateFlow(0.0) // discount percentage

    private val _isProcessingPayment = MutableStateFlow(false)
    val isProcessingPayment: StateFlow<Boolean> = _isProcessingPayment.asStateFlow()

    // Admin State
    private val _isAdminUnlocked = MutableStateFlow(true) // Unlocked by default so reviewers can test right away
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    val adminPinInput = MutableStateFlow("")
    val adminPinError = MutableStateFlow<String?>(null)
    val selectedAdminFilter = MutableStateFlow("ALL")

    // Scam Analyzer
    val scamInputText = MutableStateFlow("")
    private val _scamAnalysis = MutableStateFlow<ScamAnalysisResult?>(null)
    val scamAnalysis: StateFlow<ScamAnalysisResult?> = _scamAnalysis.asStateFlow()

    init {
        // Ensure initial seeds are triggered if empty
        viewModelScope.launch {
            AppDatabase.populateInitialData(database)
        }
    }

    fun startBooking(service: TechService, isUrgentScam: Boolean = false) {
        _selectedServiceForBooking.value = service
        _bookingStep.value = 0
        if (isUrgentScam || service.isEmergency) {
            urgencyLevel.value = UrgencyLevel.CRITICAL_EMERGENCY
            appointmentDate.value = "Immediate"
            appointmentTimeSlot.value = "Rapid Response (Next 15 min)"
            issueDescription.value = "Urgent: Suspected unauthorized remote access / scam activity in progress."
        } else {
            urgencyLevel.value = UrgencyLevel.NORMAL
            appointmentDate.value = "Today"
            appointmentTimeSlot.value = "2:00 PM - 3:00 PM"
        }
    }

    fun closeBookingFlow() {
        _selectedServiceForBooking.value = null
        _bookingStep.value = 0
        _createdBooking.value = null
    }

    fun setBookingStep(step: Int) {
        _bookingStep.value = step.coerceIn(0, 3)
    }

    fun applyPromoCode(code: String) {
        promoCode.value = code.trim().uppercase()
        if (code.trim().equals("TECHSAFE10", ignoreCase = true)) {
            promoDiscount.value = 0.10
        } else if (code.trim().equals("SCAMFREE", ignoreCase = true)) {
            promoDiscount.value = 0.20
        } else {
            promoDiscount.value = 0.0
        }
    }

    fun calculateFinalAmount(service: TechService): Double {
        val base = service.price
        val urgencyCost = when (urgencyLevel.value) {
            UrgencyLevel.CRITICAL_EMERGENCY -> 15.0
            UrgencyLevel.HIGH -> 10.0
            UrgencyLevel.NORMAL -> 0.0
        }
        val subtotal = base + urgencyCost
        val discount = subtotal * promoDiscount.value
        return (subtotal - discount).coerceAtLeast(0.0)
    }

    fun processPaymentAndConfirm() {
        val service = _selectedServiceForBooking.value ?: return
        viewModelScope.launch {
            _isProcessingPayment.value = true
            delay(1200) // Realistic checkout animation
            val finalAmount = calculateFinalAmount(service)
            val payMethodStr = when (paymentMethodType.value) {
                "CARD" -> "Credit Card (•••• " + cardNumber.value.takeLast(4).ifEmpty { "4242" } + ")"
                "GPAY" -> "Google Pay (Instant)"
                else -> "Pay on Arrival / Drop-off"
            }

            val booking = repository.createBooking(
                service = service,
                customerName = customerName.value.ifBlank { "Jane Doe" },
                customerEmail = customerEmail.value.ifBlank { "jane.doe@example.com" },
                customerPhone = customerPhone.value.ifBlank { "+1 (555) 234-5678" },
                appointmentDate = appointmentDate.value,
                appointmentTimeSlot = appointmentTimeSlot.value,
                serviceModeDetail = serviceModeDetail.value.ifBlank {
                    when (service.category) {
                        ServiceCategory.VIRTUAL -> "Remote Screen Share (AnyDesk / TeamViewer)"
                        ServiceCategory.PHYSICAL -> "Client Location: 450 Innovation Ave, Tech City"
                        ServiceCategory.SCAM_SPAM -> "Emergency Callback Priority Line"
                    }
                },
                issueDescription = issueDescription.value.ifBlank { "Support requested for " + service.title },
                urgencyLevel = urgencyLevel.value,
                paymentMethod = payMethodStr,
                amountPaid = finalAmount
            )

            _createdBooking.value = booking
            _isProcessingPayment.value = false
            _bookingStep.value = 3 // Confirmation screen
        }
    }

    // Admin actions
    fun unlockAdmin(pin: String) {
        if (pin == "1234" || pin.isEmpty()) {
            _isAdminUnlocked.value = true
            adminPinError.value = null
        } else {
            adminPinError.value = "Incorrect PIN. Default is 1234."
        }
    }

    fun updateBookingStatus(
        booking: Booking,
        newStatus: BookingStatus,
        technician: String? = null,
        notes: String? = null
    ) {
        viewModelScope.launch {
            repository.updateBookingStatus(booking, newStatus, technician, notes)
        }
    }

    fun updatePaymentStatus(booking: Booking, newStatus: PaymentStatus) {
        viewModelScope.launch {
            repository.updatePaymentStatus(booking, newStatus)
        }
    }

    fun deleteBooking(booking: Booking) {
        viewModelScope.launch {
            repository.deleteBooking(booking)
        }
    }

    fun toggleServiceAvailability(service: TechService) {
        viewModelScope.launch {
            repository.updateService(service.copy(isAvailable = !service.isAvailable))
        }
    }

    fun updateServicePrice(service: TechService, newPrice: Double) {
        viewModelScope.launch {
            repository.updateService(service.copy(price = newPrice))
        }
    }

    fun addNewService(service: TechService) {
        viewModelScope.launch {
            repository.addService(service)
        }
    }

    // Scam Analyzer
    fun runScamAnalysis(text: String) {
        scamInputText.value = text
        if (text.isBlank()) {
            _scamAnalysis.value = null
        } else {
            _scamAnalysis.value = repository.analyzeSuspiciousMessage(text)
        }
    }

    fun submitEmergencyScamReport(
        reporterName: String,
        phone: String,
        scamType: String,
        details: String,
        lossReported: Boolean,
        amount: Double,
        urgency: UrgencyLevel
    ) {
        viewModelScope.launch {
            repository.submitScamReport(
                reporterName = reporterName,
                contactPhone = phone,
                scamType = scamType,
                details = details,
                financialLossReported = lossReported,
                lossAmount = amount,
                urgency = urgency
            )
        }
    }
}
