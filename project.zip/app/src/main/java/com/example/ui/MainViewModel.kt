package com.example.ui

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FilterSettings
import com.example.data.model.Restaurant
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.RestaurantRepository
import com.example.location.LocationHelper
import com.example.location.QatarPresetLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val userPreferences: UserPreferences = UserPreferences(),
    val filterSettings: FilterSettings = FilterSettings(),
    val userLocation: Location? = null,
    val selectedPresetLocation: QatarPresetLocation? = null,
    val deckRestaurants: List<Restaurant> = emptyList(),
    val likedRestaurants: List<Restaurant> = emptyList(),
    val matchedRestaurant: Restaurant? = null,
    val detailRestaurant: Restaurant? = null,
    val lastSwipedRestaurant: Restaurant? = null,
    val lastSwipeWasLike: Boolean = false,
    val isLoadingLocation: Boolean = false,
    val locationErrorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RestaurantRepository()
    private val preferencesRepository = UserPreferencesRepository(application)
    private val locationHelper = LocationHelper(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        // Observe preferences
        viewModelScope.launch {
            preferencesRepository.userPreferencesFlow.collectLatest { prefs ->
                _uiState.update { it.copy(userPreferences = prefs) }
                if (prefs.useLocationForNearby && _uiState.value.userLocation == null && _uiState.value.selectedPresetLocation == null) {
                    refreshLocation()
                }
                recalculateDeck()
            }
        }
    }

    fun refreshLocation() {
        if (!locationHelper.hasLocationPermission()) {
            _uiState.update {
                it.copy(
                    locationErrorMessage = "Location permission not granted. Please allow access in settings or pick a Qatar preset."
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingLocation = true, locationErrorMessage = null) }
            val loc = locationHelper.getCurrentLocation()
            if (loc != null) {
                _uiState.update {
                    it.copy(
                        userLocation = loc,
                        selectedPresetLocation = null,
                        isLoadingLocation = false
                    )
                }
            } else {
                // If emulator has no fix yet, default to Doha Corniche for smooth experience
                val fallbackPreset = LocationHelper.QATAR_PRESETS[0]
                val fallbackLoc = Location("QatarFallback").apply {
                    latitude = fallbackPreset.latitude
                    longitude = fallbackPreset.longitude
                }
                _uiState.update {
                    it.copy(
                        userLocation = fallbackLoc,
                        selectedPresetLocation = fallbackPreset,
                        isLoadingLocation = false,
                        locationErrorMessage = null
                    )
                }
            }
            recalculateDeck()
        }
    }

    fun selectPresetLocation(preset: QatarPresetLocation) {
        val loc = Location("Preset").apply {
            latitude = preset.latitude
            longitude = preset.longitude
        }
        _uiState.update {
            it.copy(
                userLocation = loc,
                selectedPresetLocation = preset,
                locationErrorMessage = null
            )
        }
        recalculateDeck()
    }

    fun setLocationFeatureEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setUseLocation(enabled)
            if (enabled) {
                _uiState.update {
                    it.copy(
                        filterSettings = it.filterSettings.copy(sortByDistance = true)
                    )
                }
                refreshLocation()
            } else {
                _uiState.update {
                    it.copy(
                        userLocation = null,
                        selectedPresetLocation = null,
                        filterSettings = it.filterSettings.copy(sortByDistance = false)
                    )
                }
                recalculateDeck()
            }
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun updateFilterArea(area: String) {
        _uiState.update {
            it.copy(filterSettings = it.filterSettings.copy(selectedArea = area))
        }
        recalculateDeck()
    }

    fun updateFilterCuisine(cuisine: String) {
        _uiState.update {
            it.copy(filterSettings = it.filterSettings.copy(selectedCuisine = cuisine))
        }
        recalculateDeck()
    }

    fun updateMinRating(minRating: Double) {
        _uiState.update {
            it.copy(filterSettings = it.filterSettings.copy(minRating = minRating))
        }
        recalculateDeck()
    }

    fun toggleSortByDistance(sort: Boolean) {
        _uiState.update {
            it.copy(filterSettings = it.filterSettings.copy(sortByDistance = sort))
        }
        recalculateDeck()
    }

    fun swipeRight(restaurant: Restaurant) {
        viewModelScope.launch {
            preferencesRepository.saveSwipe(restaurant.id, isLike = true, isSuperLike = false)
            _uiState.update {
                it.copy(
                    lastSwipedRestaurant = restaurant,
                    lastSwipeWasLike = true,
                    matchedRestaurant = restaurant // Trigger match celebration!
                )
            }
            recalculateDeck()
        }
    }

    fun swipeLeft(restaurant: Restaurant) {
        viewModelScope.launch {
            preferencesRepository.saveSwipe(restaurant.id, isLike = false, isSuperLike = false)
            _uiState.update {
                it.copy(
                    lastSwipedRestaurant = restaurant,
                    lastSwipeWasLike = false
                )
            }
            recalculateDeck()
        }
    }

    fun superLike(restaurant: Restaurant) {
        viewModelScope.launch {
            preferencesRepository.saveSwipe(restaurant.id, isLike = true, isSuperLike = true)
            _uiState.update {
                it.copy(
                    lastSwipedRestaurant = restaurant,
                    lastSwipeWasLike = true,
                    matchedRestaurant = restaurant
                )
            }
            recalculateDeck()
        }
    }

    fun undoLastSwipe() {
        val last = _uiState.value.lastSwipedRestaurant ?: return
        viewModelScope.launch {
            preferencesRepository.removeLike(last.id)
            _uiState.update {
                it.copy(
                    lastSwipedRestaurant = null
                )
            }
            recalculateDeck()
        }
    }

    fun removeLikedRestaurant(restaurantId: String) {
        viewModelScope.launch {
            preferencesRepository.removeLike(restaurantId)
            recalculateDeck()
        }
    }

    fun resetDeck() {
        viewModelScope.launch {
            preferencesRepository.resetDeckHistory()
            recalculateDeck()
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            preferencesRepository.clearAllHistory()
            recalculateDeck()
        }
    }

    fun dismissMatchDialog() {
        _uiState.update { it.copy(matchedRestaurant = null) }
    }

    fun openRestaurantDetails(restaurant: Restaurant) {
        _uiState.update { it.copy(detailRestaurant = restaurant) }
    }

    fun dismissRestaurantDetails() {
        _uiState.update { it.copy(detailRestaurant = null) }
    }

    fun getAvailableAreas(): List<String> = repository.getAvailableAreas()
    fun getAvailableCuisines(): List<String> = repository.getAvailableCuisines()

    private fun recalculateDeck() {
        val state = _uiState.value
        val allFiltered = repository.getFilteredRestaurants(
            state.filterSettings,
            state.userLocation
        )

        val swipedIds = state.userPreferences.likedIds + state.userPreferences.passedIds
        val deck = allFiltered.filter { it.id !in swipedIds }

        val likedList = allFiltered.filter { it.id in state.userPreferences.likedIds }

        _uiState.update {
            it.copy(
                deckRestaurants = deck,
                likedRestaurants = likedList
            )
        }
    }
}
