package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.MealPlannerAiService
import com.example.ai.WeeklyMealPlan
import com.example.data.model.DietaryProfile
import com.example.data.model.Recipe
import com.example.data.repository.RecipeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AiGenerationState {
    data object Idle : AiGenerationState
    data class Generating(val progressMessage: String) : AiGenerationState
    data class RecipeReady(val recipe: Recipe, val isSaved: Boolean = false) : AiGenerationState
    data class WeeklyPlanReady(val plan: WeeklyMealPlan) : AiGenerationState
    data class Error(val message: String) : AiGenerationState
}

class MealPlannerViewModel(
    private val aiService: MealPlannerAiService,
    private val recipeRepository: RecipeRepository
) : ViewModel() {

    private val _generationState = MutableStateFlow<AiGenerationState>(AiGenerationState.Idle)
    val generationState: StateFlow<AiGenerationState> = _generationState.asStateFlow()

    private val _selectedMealType = MutableStateFlow("Dinner")
    val selectedMealType = _selectedMealType.asStateFlow()

    private val _strictPantryOnly = MutableStateFlow(true)
    val strictPantryOnly = _strictPantryOnly.asStateFlow()

    private val _targetTime = MutableStateFlow("Under 30 mins")
    val targetTime = _targetTime.asStateFlow()

    private val _cravingsNote = MutableStateFlow("")
    val cravingsNote = _cravingsNote.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage = _toastMessage.asStateFlow()

    fun setMealType(mealType: String) {
        _selectedMealType.value = mealType
    }

    fun setStrictPantryOnly(strict: Boolean) {
        _strictPantryOnly.value = strict
    }

    fun setTargetTime(time: String) {
        _targetTime.value = time
    }

    fun setCravingsNote(note: String) {
        _cravingsNote.value = note
    }

    fun generateRecipe(
        pantryItems: List<String>,
        dietaryProfile: DietaryProfile?
    ) {
        viewModelScope.launch {
            _generationState.value = AiGenerationState.Generating(
                if (_strictPantryOnly.value) {
                    "Analyzing your ${pantryItems.size} pantry ingredients for a strictly matching meal..."
                } else {
                    "Consulting AI Chef for creative gourmet inspiration..."
                }
            )

            try {
                val recipe = aiService.generateRecipe(
                    pantryItems = pantryItems,
                    dietaryProfile = dietaryProfile,
                    mealType = _selectedMealType.value,
                    targetPrepTime = _targetTime.value,
                    cravingsNote = _cravingsNote.value,
                    strictPantryOnly = _strictPantryOnly.value
                )
                _generationState.value = AiGenerationState.RecipeReady(recipe)
            } catch (e: Exception) {
                _generationState.value = AiGenerationState.Error(
                    e.localizedMessage ?: "Failed to generate recipe. Please try again."
                )
            }
        }
    }

    fun generateWeeklyPlan(
        pantryItems: List<String>,
        dietaryProfile: DietaryProfile?
    ) {
        viewModelScope.launch {
            _generationState.value = AiGenerationState.Generating(
                "Designing a balanced 7-day pantry-optimized meal schedule..."
            )

            try {
                val plan = aiService.generateWeeklyMealPlan(
                    pantryItems = pantryItems,
                    dietaryProfile = dietaryProfile,
                    daysCount = 7
                )
                _generationState.value = AiGenerationState.WeeklyPlanReady(plan)
            } catch (e: Exception) {
                _generationState.value = AiGenerationState.Error(
                    e.localizedMessage ?: "Failed to generate weekly plan."
                )
            }
        }
    }

    fun saveCurrentRecipe(recipe: Recipe) {
        viewModelScope.launch {
            try {
                val id = recipeRepository.saveRecipe(recipe)
                if (id.isNotBlank()) {
                    _generationState.value = AiGenerationState.RecipeReady(recipe.copy(id = id), isSaved = true)
                    _toastMessage.value = "Recipe '${recipe.title}' saved to your collection!"
                }
            } catch (e: Exception) {
                _toastMessage.value = "Failed to save recipe: ${e.message}"
            }
        }
    }

    fun clearState() {
        _generationState.value = AiGenerationState.Idle
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
