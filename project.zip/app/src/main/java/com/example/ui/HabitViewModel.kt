package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.GamificationEventResult
import com.example.data.HabitEntity
import com.example.data.HabitLogEntity
import com.example.data.HabitRepository
import com.example.data.UserStatsEntity
import com.example.model.GamificationManager
import com.example.notification.NotificationHelper
import com.example.notification.ReminderScheduler
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HabitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HabitRepository
    private val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    val habits: StateFlow<List<HabitEntity>>
    val userStats: StateFlow<UserStatsEntity?>
    val levelInfo: StateFlow<GamificationManager.LevelInfo>

    private val _todayDateString = MutableStateFlow(sdf.format(Date()))
    val todayDateString: StateFlow<String> = _todayDateString.asStateFlow()

    private val _selectedDateString = MutableStateFlow(sdf.format(Date()))
    val selectedDateString: StateFlow<String> = _selectedDateString.asStateFlow()

    private val _selectedYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _todayLogs = MutableStateFlow<Map<Long, HabitLogEntity>>(emptyMap())
    val todayLogs: StateFlow<Map<Long, HabitLogEntity>> = _todayLogs.asStateFlow()

    private val _selectedDateLogs = MutableStateFlow<Map<Long, HabitLogEntity>>(emptyMap())
    val selectedDateLogs: StateFlow<Map<Long, HabitLogEntity>> = _selectedDateLogs.asStateFlow()

    private val _yearLogs = MutableStateFlow<List<HabitLogEntity>>(emptyList())
    val yearLogs: StateFlow<List<HabitLogEntity>> = _yearLogs.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _celebrationEvent = MutableStateFlow<GamificationEventResult?>(null)
    val celebrationEvent: StateFlow<GamificationEventResult?> = _celebrationEvent.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = HabitRepository(db.habitDao())

        NotificationHelper.createNotificationChannel(application)

        habits = repository.allHabits.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        userStats = repository.userStats.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            null
        )

        levelInfo = userStats.map { stats ->
            GamificationManager.getLevelInfo(stats?.xp ?: 0)
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            GamificationManager.getLevelInfo(0)
        )

        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
            loadTodayLogs()
            loadYearLogs(_selectedYear.value)
        }
    }

    private fun loadTodayLogs() {
        val today = _todayDateString.value
        viewModelScope.launch {
            repository.getLogsForDate(today).collect { logs ->
                _todayLogs.value = logs.associateBy { it.habitId }
            }
        }
    }

    fun setSelectedDate(dateString: String) {
        _selectedDateString.value = dateString
        viewModelScope.launch {
            repository.getLogsForDate(dateString).collect { logs ->
                _selectedDateLogs.value = logs.associateBy { it.habitId }
            }
        }
    }

    fun setSelectedYear(year: Int) {
        _selectedYear.value = year
        loadYearLogs(year)
    }

    private fun loadYearLogs(year: Int) {
        viewModelScope.launch {
            repository.getLogsForYear(year.toString()).collect { logs ->
                _yearLogs.value = logs
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun toggleHabit(habit: HabitEntity, date: String = _todayDateString.value) {
        viewModelScope.launch {
            val result = repository.toggleHabitCompletion(habit, date)
            if (result.leveledUp || result.newlyUnlockedBadges.isNotEmpty()) {
                _celebrationEvent.value = result
            }
        }
    }

    fun incrementHabit(habit: HabitEntity, delta: Double, date: String = _todayDateString.value) {
        viewModelScope.launch {
            val result = repository.incrementHabitProgress(habit, date, delta)
            if (result.leveledUp || result.newlyUnlockedBadges.isNotEmpty()) {
                _celebrationEvent.value = result
            }
        }
    }

    fun resistCraving(habit: HabitEntity) {
        viewModelScope.launch {
            val result = repository.resistCraving(habit)
            if (result.leveledUp || result.newlyUnlockedBadges.isNotEmpty()) {
                _celebrationEvent.value = result
            }
        }
    }

    fun recordQuitSlip(habitId: Long) {
        viewModelScope.launch {
            repository.recordQuitSlip(habitId)
        }
    }

    fun checkCleanDay(habit: HabitEntity, date: String = _todayDateString.value) {
        viewModelScope.launch {
            val result = repository.checkCleanDay(habit, date)
            if (result.leveledUp || result.newlyUnlockedBadges.isNotEmpty()) {
                _celebrationEvent.value = result
            }
        }
    }

    fun saveHabit(habit: HabitEntity) {
        viewModelScope.launch {
            if (habit.id == 0L) {
                val newId = repository.insertHabit(habit)
                val insertedHabit = habit.copy(id = newId)
                if (insertedHabit.reminderEnabled) {
                    ReminderScheduler.scheduleHabitReminder(getApplication(), insertedHabit)
                }
            } else {
                repository.updateHabit(habit)
                if (habit.reminderEnabled) {
                    ReminderScheduler.scheduleHabitReminder(getApplication(), habit)
                } else {
                    ReminderScheduler.cancelHabitReminder(getApplication(), habit.id)
                }
            }
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch {
            ReminderScheduler.cancelHabitReminder(getApplication(), habit.id)
            repository.deleteHabit(habit)
        }
    }

    fun triggerTestReminder(habit: HabitEntity) {
        val targetStr = if (habit.targetValue % 1.0 == 0.0) {
            "${habit.targetValue.toInt()} ${habit.unit}"
        } else {
            "${habit.targetValue} ${habit.unit}"
        }
        NotificationHelper.showReminderNotification(
            context = getApplication(),
            notificationId = habit.id.toInt(),
            habitTitle = habit.title,
            habitTarget = targetStr
        )
    }

    fun dismissCelebration() {
        _celebrationEvent.value = null
    }
}
