package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.data.HabitLogEntity
import com.example.ui.components.formatGoalString
import com.example.ui.components.getHabitIcon
import com.example.ui.components.parseColor
import com.example.ui.theme.AmberStreak
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarYearScreen(
    year: Int,
    yearLogs: List<HabitLogEntity>,
    habits: List<HabitEntity>,
    selectedDate: String,
    onSelectDate: (String) -> Unit,
    onYearChange: (Int) -> Unit,
    onToggleHabitOnDate: (HabitEntity, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMonthIndex by remember {
        val cal = Calendar.getInstance()
        mutableIntStateOf(cal.get(Calendar.MONTH)) // 0 to 11
    }

    val monthNames = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    // Group logs by date
    val completedLogsByDate = remember(yearLogs) {
        yearLogs.filter { it.isCompleted }.groupBy { it.dateString }
    }

    val totalYearCompletions = remember(yearLogs) {
        yearLogs.count { it.isCompleted }
    }

    val uniqueActiveDays = remember(completedLogsByDate) {
        completedLogsByDate.keys.size
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("calendar_year_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Year Navigation Header & Quick Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { onYearChange(year - 1) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Previous Year"
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "$year Journey",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(onClick = { onYearChange(year + 1) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Next Year"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Year Stats Strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        YearMetricCard(
                            title = "Total Check-offs",
                            value = "$totalYearCompletions",
                            icon = Icons.Default.Check,
                            tint = EmeraldPrimary,
                            modifier = Modifier.weight(1f)
                        )

                        YearMetricCard(
                            title = "Active Days",
                            value = "$uniqueActiveDays",
                            icon = Icons.Default.LocalFireDepartment,
                            tint = AmberStreak,
                            modifier = Modifier.weight(1f)
                        )

                        YearMetricCard(
                            title = "Consistency",
                            value = "${(uniqueActiveDays * 100 / 365).coerceAtLeast(1)}%",
                            icon = Icons.Default.Star,
                            tint = EmeraldLight,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Year Activity Heatmap Intensity Legend
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVITY HEATMAP",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Less",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    HeatmapLegendBox(Color.Transparent, border = true)
                    HeatmapLegendBox(EmeraldPrimary.copy(alpha = 0.35f))
                    HeatmapLegendBox(EmeraldPrimary.copy(alpha = 0.7f))
                    HeatmapLegendBox(EmeraldPrimary)
                    HeatmapLegendBox(AmberStreak)
                    Text(
                        text = "More",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Month Selector Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedMonthIndex,
                edgePadding = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                monthNames.forEachIndexed { index, name ->
                    Tab(
                        selected = selectedMonthIndex == index,
                        onClick = { selectedMonthIndex = index },
                        text = {
                            Text(
                                text = name.take(3),
                                fontWeight = if (selectedMonthIndex == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }
        }

        // Interactive Month Calendar Grid
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "${monthNames[selectedMonthIndex]} $year",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Days of week header
                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("M", "T", "W", "T", "F", "S", "S").forEach { dayLabel ->
                            Text(
                                text = dayLabel,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Month Calendar Matrix
                    MonthDaysMatrix(
                        year = year,
                        month = selectedMonthIndex,
                        completedLogsByDate = completedLogsByDate,
                        selectedDate = selectedDate,
                        onSelectDate = onSelectDate
                    )
                }
            }
        }

        // Selected Date Details & Inspection Panel
        item {
            SelectedDatePanel(
                dateString = selectedDate,
                habits = habits,
                logsForYear = yearLogs,
                onToggleHabit = onToggleHabitOnDate
            )
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun MonthDaysMatrix(
    year: Int,
    month: Int,
    completedLogsByDate: Map<String, List<HabitLogEntity>>,
    selectedDate: String,
    onSelectDate: (String) -> Unit
) {
    val cal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month)
        set(Calendar.DAY_OF_MONTH, 1)
    }

    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    // In Java Calendar, Sunday=1, Monday=2 ... Saturday=7
    val firstDayOfWeekJava = cal.get(Calendar.DAY_OF_WEEK)
    // Convert to Monday=0 ... Sunday=6
    val leadingEmptyDays = (firstDayOfWeekJava + 5) % 7

    val totalCells = leadingEmptyDays + daysInMonth
    val totalRows = (totalCells + 6) / 7

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (row in 0 until totalRows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (col in 0 until 7) {
                    val cellIndex = row * 7 + col
                    val dayOfMonth = cellIndex - leadingEmptyDays + 1

                    if (cellIndex < leadingEmptyDays || dayOfMonth > daysInMonth) {
                        Spacer(modifier = Modifier.weight(1f))
                    } else {
                        val dateStr = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth)
                        val completionsCount = completedLogsByDate[dateStr]?.size ?: 0
                        val isSelected = dateStr == selectedDate

                        // Heatmap color calculation
                        val heatColor = when {
                            completionsCount >= 5 -> AmberStreak
                            completionsCount >= 3 -> EmeraldPrimary
                            completionsCount >= 2 -> EmeraldPrimary.copy(alpha = 0.65f)
                            completionsCount >= 1 -> EmeraldPrimary.copy(alpha = 0.35f)
                            else -> MaterialTheme.colorScheme.surface
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(heatColor)
                                .border(
                                    width = if (isSelected) 2.dp else 0.5.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectDate(dateStr) }
                                .testTag("calendar_day_$dateStr"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$dayOfMonth",
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected || completionsCount > 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (completionsCount >= 2) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                                if (completionsCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .clip(CircleShape)
                                            .background(if (completionsCount >= 2) Color.Black else EmeraldPrimary)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectedDatePanel(
    dateString: String,
    habits: List<HabitEntity>,
    logsForYear: List<HabitLogEntity>,
    onToggleHabit: (HabitEntity, String) -> Unit
) {
    val dayLogs = remember(logsForYear, dateString) {
        logsForYear.filter { it.dateString == dateString }.associateBy { it.habitId }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "DAY DETAILS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = dateString,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val completedCount = dayLogs.values.count { it.isCompleted }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EmeraldPrimary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "$completedCount / ${habits.size} Finished",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (habits.isEmpty()) {
                Text(
                    text = "No habits tracked yet. Create one to start logging!",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                habits.forEach { habit ->
                    val isDone = dayLogs[habit.id]?.isCompleted ?: false
                    val habitColor = parseColor(habit.colorHex)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onToggleHabit(habit, dateString) },
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = getHabitIcon(habit.iconName),
                                contentDescription = null,
                                tint = habitColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = habit.title,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = formatGoalString(habit.targetValue, habit.unit),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isDone) EmeraldPrimary else Color.Transparent
                                    )
                                    .border(
                                        width = 1.5.dp,
                                        color = if (isDone) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Done",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YearMetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = title,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HeatmapLegendBox(color: Color, border: Boolean = false) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(color)
            .then(
                if (border) Modifier.border(
                    0.5.dp,
                    MaterialTheme.colorScheme.outline,
                    RoundedCornerShape(2.dp)
                ) else Modifier
            )
    )
}
