package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Car
import com.example.model.OfferInquiry
import com.example.model.TestDriveBooking
import com.example.ui.theme.DealGreen
import com.example.ui.theme.DealOrange
import java.util.Locale

@Composable
fun GarageScreen(
  favoriteCars: List<Car>,
  testDrives: List<TestDriveBooking>,
  offers: List<OfferInquiry>,
  comparisonIds: Set<String>,
  onCarClick: (Car) -> Unit,
  onFavoriteClick: (Car) -> Unit,
  onCompareClick: (Car) -> Unit,
  onBrowseClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Saved Cars, 1: Test Drives, 2: My Offers

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("garage_screen_list"),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        Text(
          text = "My AutoVault Garage",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "Saved vehicles, appointments, and negotiated offers",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Segmented filter chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            label = { Text("Saved (${favoriteCars.size})") },
            modifier = Modifier.weight(1f)
          )
          FilterChip(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            label = { Text("Test Drives (${testDrives.size})") },
            modifier = Modifier.weight(1f)
          )
          FilterChip(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            label = { Text("Offers (${offers.size})") },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    when (selectedTab) {
      0 -> {
        // Saved Vehicles
        if (favoriteCars.isEmpty()) {
          item {
            EmptyGarageState(
              title = "Your Garage is Empty",
              message = "Tap the bookmark icon on any vehicle listing to save it here for fast access and price change monitoring.",
              onBrowse = onBrowseClick
            )
          }
        } else {
          items(favoriteCars, key = { it.id }) { car ->
            CarCard(
              car = car,
              isFavorite = true,
              isCompared = comparisonIds.contains(car.id),
              onCardClick = { onCarClick(car) },
              onFavoriteClick = { onFavoriteClick(car) },
              onCompareClick = { onCompareClick(car) },
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
          }
        }
      }

      1 -> {
        // Test Drives List
        if (testDrives.isEmpty()) {
          item {
            EmptyGarageState(
              title = "No Scheduled Test Drives",
              message = "Find your dream vehicle and tap 'Book Test Drive' to schedule a VIP showroom or home appointment.",
              onBrowse = onBrowseClick
            )
          }
        } else {
          items(testDrives, key = { it.id }) { booking ->
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DealGreen.copy(alpha = 0.15f)
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                      Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = DealGreen,
                        modifier = Modifier.size(14.dp)
                      )
                      Text(
                        text = booking.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DealGreen
                      )
                    }
                  }

                  Text(
                    text = "${booking.date} • ${booking.timeSlot}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                  )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                  text = booking.carTitle,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                  text = "Booked for: ${booking.customerName} (${booking.customerPhone})",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      2 -> {
        // Offers List
        if (offers.isEmpty()) {
          item {
            EmptyGarageState(
              title = "No Active Offers",
              message = "Negotiate directly with verified dealerships by tapping 'Make an Offer' on any car listing.",
              onBrowse = onBrowseClick
            )
          }
        } else {
          items(offers, key = { it.id }) { offer ->
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                  ) {
                    Text(
                      text = "PENDING REVIEW",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }

                  Text(
                    text = offer.timestamp,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                  text = offer.carTitle,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = "Your Offer: $${String.format(Locale.US, "%,.0f", offer.offerPrice)}",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Black,
                  color = MaterialTheme.colorScheme.primary
                )

                if (offer.hasTradeIn) {
                  Text(
                    text = "Includes trade-in appraisal evaluation",
                    style = MaterialTheme.typography.bodySmall,
                    color = DealOrange
                  )
                }

                if (offer.message.isNotBlank()) {
                  Text(
                    text = "\"${offer.message}\"",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyGarageState(
  title: String,
  message: String,
  onBrowse: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    modifier = Modifier
      .fillMaxWidth()
      .padding(16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
        modifier = Modifier.size(56.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.DirectionsCar,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp)
          )
        }
      }

      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      Button(
        onClick = onBrowse,
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("Explore Cars")
      }
    }
  }
}
