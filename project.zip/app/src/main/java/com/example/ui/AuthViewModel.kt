package com.example.ui

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.auth.userProfileChangeRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val TAG = "AuthViewModel"

sealed interface AuthUiState {
    data object Idle : AuthUiState
    data object Loading : AuthUiState
    data class Authenticated(val user: FirebaseUser) : AuthUiState
    data class Error(val message: String) : AuthUiState
}

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = Firebase.auth

    private val _uiState = MutableStateFlow<AuthUiState>(
        auth.currentUser?.let { AuthUiState.Authenticated(it) } ?: AuthUiState.Idle
    )
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _infoMessage = MutableStateFlow<String?>(null)
    val infoMessage: StateFlow<String?> = _infoMessage.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            _uiState.value = if (user != null) {
                AuthUiState.Authenticated(user)
            } else {
                AuthUiState.Idle
            }
        }
    }

    fun signInWithEmailAndPassword(email: String, password: String) {
        val trimmedEmail = email.trim()
        if (trimmedEmail.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter both email and password.")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            try {
                val result = auth.signInWithEmailAndPassword(trimmedEmail, password).await()
                val user = result.user
                if (user != null) {
                    _uiState.value = AuthUiState.Authenticated(user)
                } else {
                    _uiState.value = AuthUiState.Error("Sign in failed. No user record returned.")
                }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                Log.w(TAG, "Invalid credentials: ${e.message}")
                _uiState.value = AuthUiState.Error("Invalid email or password. Please verify your credentials.")
            } catch (e: FirebaseAuthInvalidUserException) {
                Log.w(TAG, "User not found: ${e.message}")
                _uiState.value = AuthUiState.Error("No account found with this email. Please switch to Create Account.")
            } catch (e: FirebaseAuthException) {
                Log.e(TAG, "Firebase auth error (${e.errorCode}): ${e.message}", e)
                val msg = when (e.errorCode) {
                    "ERROR_OPERATION_NOT_ALLOWED" -> "Email/Password sign-in is not enabled in Firebase Console. Please enable it under Authentication > Sign-in method."
                    else -> e.localizedMessage ?: "Sign-in failed. Please try again."
                }
                _uiState.value = AuthUiState.Error(msg)
            } catch (e: Exception) {
                Log.e(TAG, "Sign in exception: ${e.message}", e)
                _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Sign in failed.")
            }
        }
    }

    fun signUpWithEmailAndPassword(email: String, password: String, displayName: String? = null) {
        val trimmedEmail = email.trim()
        val trimmedName = displayName?.trim().orEmpty()
        if (trimmedEmail.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter an email and password.")
            return
        }
        if (password.length < 6) {
            _uiState.value = AuthUiState.Error("Password must be at least 6 characters.")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            try {
                val result = auth.createUserWithEmailAndPassword(trimmedEmail, password).await()
                val user = result.user
                if (user != null) {
                    if (trimmedName.isNotBlank()) {
                        try {
                            val profileUpdates = userProfileChangeRequest {
                                this.displayName = trimmedName
                            }
                            user.updateProfile(profileUpdates).await()
                        } catch (pe: Exception) {
                            Log.w(TAG, "Failed to set display name: ${pe.message}")
                        }
                    }
                    _uiState.value = AuthUiState.Authenticated(user)
                } else {
                    _uiState.value = AuthUiState.Error("Account creation failed. Please try again.")
                }
            } catch (e: FirebaseAuthUserCollisionException) {
                Log.w(TAG, "User collision: ${e.message}")
                _uiState.value = AuthUiState.Error("An account already exists with this email. Please sign in instead.")
            } catch (e: FirebaseAuthWeakPasswordException) {
                Log.w(TAG, "Weak password: ${e.message}")
                _uiState.value = AuthUiState.Error("Password is too weak. Please use at least 6 characters.")
            } catch (e: FirebaseAuthException) {
                Log.e(TAG, "Firebase auth creation error (${e.errorCode}): ${e.message}", e)
                val msg = when (e.errorCode) {
                    "ERROR_OPERATION_NOT_ALLOWED" -> "Email/Password sign-in is not enabled in Firebase Console. Please enable it under Authentication > Sign-in method."
                    else -> e.localizedMessage ?: "Sign up failed. Please try again."
                }
                _uiState.value = AuthUiState.Error(msg)
            } catch (e: Exception) {
                Log.e(TAG, "Sign up exception: ${e.message}", e)
                _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Sign up failed.")
            }
        }
    }

    fun sendPasswordReset(email: String) {
        val trimmedEmail = email.trim()
        if (trimmedEmail.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter your email to receive a password reset link.")
            return
        }
        viewModelScope.launch {
            try {
                auth.sendPasswordResetEmail(trimmedEmail).await()
                _infoMessage.value = "Password reset email sent to $trimmedEmail"
            } catch (e: Exception) {
                _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Failed to send reset email.")
            }
        }
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error) {
            _uiState.value = AuthUiState.Idle
        }
    }

    fun clearInfoMessage() {
        _infoMessage.value = null
    }

    fun signOut(context: Context? = null) {
        auth.signOut()
        _uiState.value = AuthUiState.Idle
    }
}
