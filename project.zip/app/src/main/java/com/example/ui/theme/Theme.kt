package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = QatarMaroonLight,
    onPrimary = Color.White,
    primaryContainer = QatarMaroonDark,
    onPrimaryContainer = QatarGoldLight,
    secondary = QatarGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF3E3113),
    onSecondaryContainer = QatarGoldLight,
    background = DarkBackground,
    onBackground = TextLightPrimary,
    surface = DarkSurface,
    onSurface = TextLightPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextLightSecondary,
    outline = Color(0xFF55444A)
)

private val LightColorScheme = lightColorScheme(
    primary = QatarMaroon,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E2),
    onPrimaryContainer = QatarMaroonDark,
    secondary = QatarGoldDark,
    onSecondary = Color.White,
    secondaryContainer = QatarGoldLight,
    onSecondaryContainer = Color(0xFF261A00),
    background = WarmSandLight,
    onBackground = TextDarkPrimary,
    surface = Color.White,
    onSurface = TextDarkPrimary,
    surfaceVariant = WarmSandSurface,
    onSurfaceVariant = TextDarkSecondary,
    outline = Color(0xFFD3C5C8)
)

@Composable
fun QatarBitesTheme(
    themeMode: String = "system", // "system", "dark", "light"
    dynamicColor: Boolean = false, // Keep authentic Qatar branding by default
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
