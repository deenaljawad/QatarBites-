package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Restaurant
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.components.SwipeCard
import com.example.ui.theme.LikeGreen
import com.example.ui.theme.PassRed
import com.example.ui.theme.QatarGold
import com.example.ui.theme.QatarMaroon
import com.example.ui.theme.SuperLikeBlue

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DiscoverScreen(
    viewModel: MainViewModel,
    uiState: MainUiState,
    onNavigateToMatches: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showFilterSheet by remember { mutableStateOf(false) }

    val openGoogleMaps: (Restaurant) -> Unit = { restaurant ->
        val gmmIntentUri = Uri.parse("geo:${restaurant.latitude},${restaurant.longitude}?q=${Uri.encode("${restaurant.name}, ${restaurant.area}, Doha")}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
        }
        if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
        } else {
            val webUri = Uri.parse(restaurant.googleMapsUrl)
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Restaurant,
                        contentDescription = null,
                        tint = QatarMaroon,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "QatarBites",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Subtitle indicating active location status
                val locationText = when {
                    uiState.selectedPresetLocation != null -> "📍 Near ${uiState.selectedPresetLocation.name}"
                    uiState.userLocation != null -> "📍 Nearest Qatar Dining"
                    else -> "Explore Qatar's Top-Rated"
                }
                Text(
                    text = locationText,
                    style = MaterialTheme.typography.bodySmall,
                    color = QatarGold,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Filter action button
            IconButton(
                onClick = { showFilterSheet = true },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .testTag("open_filters_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "Filters",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Location Info / Error banner if user turned on location but permission is needed
        AnimatedVisibility(visible = uiState.locationErrorMessage != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = uiState.locationErrorMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Swipe Deck Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            val restaurants = uiState.deckRestaurants

            if (restaurants.isEmpty()) {
                // Empty Deck State
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(24.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(QatarGold.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restaurant,
                                contentDescription = null,
                                tint = QatarGold,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "You've Swiped All Spots!",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "You've reviewed the top restaurants in this category. Reshuffle to swipe again or explore your saved favorites.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { viewModel.resetDeck() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("reshuffle_deck_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = QatarMaroon,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reshuffle Deck")
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = onNavigateToMatches,
                            modifier = Modifier.testTag("view_saved_matches_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = LikeGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "View Saved Restaurants (${uiState.likedRestaurants.size})",
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            } else {
                // Render top 2 cards for depth performance
                val visibleCards = restaurants.take(2).reversed()
                visibleCards.forEachIndexed { index, restaurant ->
                    val isTopCard = (index == visibleCards.lastIndex)
                    val scale = if (isTopCard) 1f else 0.94f
                    val offsetY = if (isTopCard) 0.dp else 12.dp

                    SwipeCard(
                        restaurant = restaurant,
                        isTopCard = isTopCard,
                        modifier = Modifier
                            .fillMaxSize()
                            .scale(scale)
                            .padding(top = offsetY),
                        onSwipeRight = { viewModel.swipeRight(it) },
                        onSwipeLeft = { viewModel.swipeLeft(it) },
                        onSuperLike = { viewModel.superLike(it) },
                        onInfoClick = { viewModel.openRestaurantDetails(it) },
                        onOpenMaps = openGoogleMaps
                    )
                }
            }
        }

        // Bottom Tinder Action Buttons
        if (uiState.deckRestaurants.isNotEmpty()) {
            val topRestaurant = uiState.deckRestaurants.first()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Undo Button
                IconButton(
                    onClick = { viewModel.undoLastSwipe() },
                    enabled = uiState.lastSwipedRestaurant != null,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("deck_undo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = "Undo Last Swipe",
                        tint = if (uiState.lastSwipedRestaurant != null) QatarGold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 2. Pass / Nope Button (Cross)
                FloatingActionButton(
                    onClick = { viewModel.swipeLeft(topRestaurant) },
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PassRed,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .size(62.dp)
                        .testTag("deck_pass_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Pass Restaurant",
                        modifier = Modifier.size(32.dp)
                    )
                }

                // 3. Super Like Button (Star)
                FloatingActionButton(
                    onClick = { viewModel.superLike(topRestaurant) },
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = SuperLikeBlue,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("deck_super_like_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Super Like",
                        modifier = Modifier.size(26.dp)
                    )
                }

                // 4. Like / Save Button (Heart)
                FloatingActionButton(
                    onClick = { viewModel.swipeRight(topRestaurant) },
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = LikeGreen,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .size(62.dp)
                        .testTag("deck_like_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Like Restaurant",
                        modifier = Modifier.size(32.dp)
                    )
                }

                // 5. Details Info Button
                IconButton(
                    onClick = { viewModel.openRestaurantDetails(topRestaurant) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("deck_details_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "View Details",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }

    // Filter Bottom Sheet
    if (showFilterSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Filter Qatar Dining",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = {
                        viewModel.updateFilterArea("All Qatar")
                        viewModel.updateFilterCuisine("All")
                        viewModel.updateMinRating(4.5)
                        viewModel.toggleSortByDistance(false)
                        showFilterSheet = false
                    }) {
                        Text("Reset All")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Area Filter
                Text(
                    text = "Area / Destination",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.getAvailableAreas().forEach { area ->
                        val isSelected = uiState.filterSettings.selectedArea == area
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateFilterArea(area) },
                            label = { Text(area) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = QatarMaroon,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Cuisine Filter
                Text(
                    text = "Cuisine Style",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.getAvailableCuisines().forEach { cuisine ->
                        val isSelected = uiState.filterSettings.selectedCuisine == cuisine
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateFilterCuisine(cuisine) },
                            label = { Text(cuisine) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = QatarMaroon,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Minimum Rating Filter
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Minimum Rating",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${String.format("%.1f", uiState.filterSettings.minRating)}★ or higher",
                        color = QatarGold,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = uiState.filterSettings.minRating.toFloat(),
                    onValueChange = { viewModel.updateMinRating(it.toDouble()) },
                    valueRange = 4.5f..4.9f,
                    steps = 3,
                    colors = SliderDefaults.colors(
                        thumbColor = QatarMaroon,
                        activeTrackColor = QatarMaroon
                    )
                )

                // Sort by distance toggle
                if (uiState.userLocation != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Sort by Nearest First",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Recommends closest restaurants in Qatar",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        androidx.compose.material3.Switch(
                            checked = uiState.filterSettings.sortByDistance,
                            onCheckedChange = { viewModel.toggleSortByDistance(it) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QatarMaroon,
                        contentColor = Color.White
                    )
                ) {
                    Text("Apply & Done")
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
