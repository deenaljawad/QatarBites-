package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RiskLevel
import com.example.data.models.ServiceCategory
import com.example.data.models.UrgencyLevel
import com.example.ui.MainViewModel
import com.example.ui.components.EmergencySosBanner
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerRedDark
import com.example.ui.theme.SecurityTeal
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun ScamDefenseScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scamInput by viewModel.scamInputText.collectAsState()
    val scamAnalysis by viewModel.scamAnalysis.collectAsState()
    val services by viewModel.services.collectAsState()

    var showReportDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            EmergencySosBanner(
                onEmergencyClick = {
                    val emergencyService = services.firstOrNull { it.isEmergency }
                        ?: services.firstOrNull { it.category == ServiceCategory.SCAM_SPAM }
                    if (emergencyService != null) {
                        viewModel.startBooking(emergencyService, isUrgentScam = true)
                    }
                }
            )
        }

        // Title Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Scam & Spam Defense Center",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time threat detection, live scam audit, and rapid lockout rescue",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showReportDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("report_scam_button")
                ) {
                    Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Report Scam", fontSize = 12.sp)
                }
            }
        }

        // Interactive Phishing & Scam Analyzer Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("scam_analyzer_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberCyan.copy(alpha = 0.15f))
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Phishing & Fake Message Analyzer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Paste suspicious text, fake invoices, or links below",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = scamInput,
                        onValueChange = { viewModel.runScamAnalysis(it) },
                        placeholder = { Text("Paste suspicious email text, SMS alert, or message here...") },
                        minLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("scam_text_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset buttons
                    Text(
                        text = "Quick Test Samples:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        PresetChip(
                            label = "Geek Squad Refund",
                            onClick = {
                                viewModel.runScamAnalysis(
                                    "Your Geek Squad auto-renewal for $499.00 has succeeded. If you did not authorize this, call immediately at 1-800-XXX-XXXX to get your refund. You will need to install AnyDesk for verification."
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                        PresetChip(
                            label = "Gift Card Threat",
                            onClick = {
                                viewModel.runScamAnalysis(
                                    "URGENT: Legal arrest warrant issued. Pay $800 penalty immediately using Target or Apple Gift cards to clear your SSN."
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Analysis Results
                    AnimatedVisibility(visible = scamAnalysis != null) {
                        scamAnalysis?.let { result ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Result Banner
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(result.riskLevel.colorHex).copy(alpha = 0.15f))
                                        .border(1.dp, Color(result.riskLevel.colorHex), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = when (result.riskLevel) {
                                                        RiskLevel.DANGEROUS -> Icons.Default.Dangerous
                                                        RiskLevel.SUSPICIOUS -> Icons.Default.Warning
                                                        RiskLevel.SAFE -> Icons.Default.VerifiedUser
                                                    },
                                                    contentDescription = null,
                                                    tint = Color(result.riskLevel.colorHex),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = result.adviceHeadline,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = Color(result.riskLevel.colorHex)
                                                )
                                            }
                                            Text(
                                                text = "${result.riskScore}/100",
                                                fontWeight = FontWeight.Black,
                                                fontSize = 13.sp,
                                                color = Color(result.riskLevel.colorHex)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = { result.riskScore / 100f },
                                            color = Color(result.riskLevel.colorHex),
                                            trackColor = Color(result.riskLevel.colorHex).copy(alpha = 0.2f),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                // Red Flags
                                Text(
                                    text = "Red Flags Detected:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    result.matchedRedFlags.forEach { flag ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = Color(result.riskLevel.colorHex),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(text = flag, fontSize = 12.sp)
                                        }
                                    }
                                }

                                // Action Checklist
                                Text(
                                    text = "Immediate Safety Actions:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    result.recommendedActions.forEach { action ->
                                        Row(verticalAlignment = Alignment.Top) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = SuccessGreen,
                                                modifier = Modifier
                                                    .size(16.dp)
                                                    .padding(top = 2.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(text = action, fontSize = 12.sp)
                                        }
                                    }
                                }

                                if (result.riskLevel == RiskLevel.DANGEROUS) {
                                    Button(
                                        onClick = {
                                            val emergencyService = services.firstOrNull { it.isEmergency }
                                                ?: services.firstOrNull { it.category == ServiceCategory.SCAM_SPAM }
                                            if (emergencyService != null) {
                                                viewModel.startBooking(emergencyService, isUrgentScam = true)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 6.dp)
                                            .testTag("book_emergency_from_analyzer")
                                    ) {
                                        Text("Dispatch Emergency Scam Lockdown ($59)", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Emergency Step-by-Step Defense Protocol
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "5-Step Scam Emergency Lockdown",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    LockdownStepItem(
                        number = "1",
                        title = "Disconnect Internet Immediately",
                        description = "Turn off Wi-Fi or unplug ethernet cable. This instantly severs the scammer's remote connection to your device."
                    )
                    LockdownStepItem(
                        number = "2",
                        title = "Do NOT Turn Off Computer Yet",
                        description = "Keep machine powered on but offline so malicious processes can be quarantined and digital forensic evidence preserved."
                    )
                    LockdownStepItem(
                        number = "3",
                        title = "Call Bank On Separate Phone",
                        description = "Dial the verified number on the back of your debit/credit card. Request immediate fraud freeze on all transactions."
                    )
                    LockdownStepItem(
                        number = "4",
                        title = "Change Primary Passwords",
                        description = "From a different clean device (like your phone), change passwords for email, banking, and Apple/Google accounts."
                    )
                    LockdownStepItem(
                        number = "5",
                        title = "File Official FTC / IC3 Report",
                        description = "Report incident to ReportFraud.ftc.gov and IC3.gov. TechHelp4U provides certified evidence logs."
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Incident Report Dialog
    if (showReportDialog) {
        ReportIncidentDialog(
            onDismiss = { showReportDialog = false },
            onSubmit = { name, phone, type, details, lossReported, amount ->
                viewModel.submitEmergencyScamReport(
                    reporterName = name,
                    phone = phone,
                    scamType = type,
                    details = details,
                    lossReported = lossReported,
                    amount = amount,
                    urgency = UrgencyLevel.HIGH
                )
                showReportDialog = false
                Toast.makeText(context, "Incident logged. Our security lead will contact you.", Toast.LENGTH_LONG).show()
            }
        )
    }
}

@Composable
fun PresetChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun LockdownStepItem(
    number: String,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(DangerRed.copy(alpha = 0.15f))
        ) {
            Text(
                text = number,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = DangerRed
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ReportIncidentDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, phone: String, type: String, details: String, lossReported: Boolean, amount: Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Tech Support Remote Lockout") }
    var details by remember { mutableStateOf("") }
    var lossReported by remember { mutableStateOf(false) }
    var lossAmount by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Log Scam / Fraud Incident",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Your Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = type,
                    onValueChange = { type = it },
                    label = { Text("Scam Category / Impersonation") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("What happened? (Any details)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = lossReported, onCheckedChange = { lossReported = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Money was lost or sent", fontSize = 12.sp)
                }
                if (lossReported) {
                    OutlinedTextField(
                        value = lossAmount,
                        onValueChange = { lossAmount = it },
                        label = { Text("Approximate Amount ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = lossAmount.toDoubleOrNull() ?: 0.0
                    onSubmit(name.ifBlank { "Anonymous Victim" }, phone.ifBlank { "N/A" }, type, details, lossReported, amount)
                },
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
            ) {
                Text("Submit Incident Report")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
