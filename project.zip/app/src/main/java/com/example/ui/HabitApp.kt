package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.HabitEntity
import com.example.notification.NotificationHelper
import com.example.ui.components.CelebrationDialog
import com.example.ui.screens.BadgesScreen
import com.example.ui.screens.CalendarYearScreen
import com.example.ui.screens.CreateEditHabitDialog
import com.example.ui.screens.TodayScreen
import com.example.ui.theme.AmberStreak
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.HabitCraftTheme
import com.example.ui.theme.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HabitApp(viewModel: HabitViewModel) {
    val context = LocalContext.current

    val habits by viewModel.habits.collectAsState()
    val todayLogs by viewModel.todayLogs.collectAsState()
    val yearLogs by viewModel.yearLogs.collectAsState()
    val userStats by viewModel.userStats.collectAsState()
    val levelInfo by viewModel.levelInfo.collectAsState()
    val selectedYear by viewModel.selectedYear.collectAsState()
    val selectedDate by viewModel.selectedDateString.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val celebrationEvent by viewModel.celebrationEvent.collectAsState()

    var currentTab by remember { mutableIntStateOf(0) } // 0: Habits, 1: Calendar, 2: Badges
    var editingHabit by remember { mutableStateOf<HabitEntity?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var showThemeMenu by remember { mutableStateOf(false) }

    // Request POST_NOTIFICATIONS permission for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Habit reminders enabled!", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    HabitCraftTheme(themeMode = themeMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(EmeraldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MilitaryTech,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "HabitCraft",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = "Level ${levelInfo.currentLevel} • ${levelInfo.rankTitle}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AmberStreak
                                )
                            }
                        }
                    },
                    actions = {
                        // Quick Notification Test action
                        IconButton(
                            onClick = {
                                NotificationHelper.showReminderNotification(
                                    context = context,
                                    notificationId = 999,
                                    habitTitle = "Consistency Quest",
                                    habitTarget = "Daily habit check-in"
                                )
                                Toast.makeText(context, "Reminder notification sent!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("notification_test_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Test Notification"
                            )
                        }

                        // Theme Mode Selector
                        Box {
                            IconButton(
                                onClick = { showThemeMenu = true },
                                modifier = Modifier.testTag("theme_toggle_button")
                            ) {
                                Icon(
                                    imageVector = when (themeMode) {
                                        ThemeMode.DARK -> Icons.Default.DarkMode
                                        ThemeMode.LIGHT -> Icons.Default.LightMode
                                        ThemeMode.SYSTEM -> Icons.Default.SettingsBrightness
                                    },
                                    contentDescription = "Toggle Theme"
                                )
                            }

                            DropdownMenu(
                                expanded = showThemeMenu,
                                onDismissRequest = { showThemeMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Dark Theme") },
                                    leadingIcon = { Icon(Icons.Default.DarkMode, null) },
                                    onClick = {
                                        viewModel.setThemeMode(ThemeMode.DARK)
                                        showThemeMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Light Theme") },
                                    leadingIcon = { Icon(Icons.Default.LightMode, null) },
                                    onClick = {
                                        viewModel.setThemeMode(ThemeMode.LIGHT)
                                        showThemeMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("System Theme") },
                                    leadingIcon = { Icon(Icons.Default.SettingsBrightness, null) },
                                    onClick = {
                                        viewModel.setThemeMode(ThemeMode.SYSTEM)
                                        showThemeMenu = false
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Habits"
                            )
                        },
                        label = { Text("Habits") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_habits_tab")
                    )

                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "Year Calendar"
                            )
                        },
                        label = { Text("Calendar") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_calendar_tab")
                    )

                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Badges & XP"
                            )
                        },
                        label = { Text("Badges") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberStreak,
                            selectedTextColor = AmberStreak,
                            indicatorColor = AmberStreak.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_badges_tab")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    0 -> TodayScreen(
                        habits = habits,
                        todayLogs = todayLogs,
                        userStats = userStats,
                        levelInfo = levelInfo,
                        onToggleHabit = { habit -> viewModel.toggleHabit(habit) },
                        onIncrementHabit = { habit, delta -> viewModel.incrementHabit(habit, delta) },
                        onRecordSlip = { habitId -> viewModel.recordQuitSlip(habitId) },
                        onCheckCleanToday = { habit -> viewModel.checkCleanDay(habit) },
                        onEditHabit = { habit -> editingHabit = habit },
                        onAddNewHabit = { showCreateDialog = true },
                        onViewBadges = { currentTab = 2 },
                        onTestNotification = { habit -> viewModel.triggerTestReminder(habit) }
                    )

                    1 -> CalendarYearScreen(
                        year = selectedYear,
                        yearLogs = yearLogs,
                        habits = habits,
                        selectedDate = selectedDate,
                        onSelectDate = { dateStr -> viewModel.setSelectedDate(dateStr) },
                        onYearChange = { newYear -> viewModel.setSelectedYear(newYear) },
                        onToggleHabitOnDate = { habit, dateStr -> viewModel.toggleHabit(habit, dateStr) }
                    )

                    2 -> BadgesScreen(
                        userStats = userStats,
                        levelInfo = levelInfo
                    )
                }
            }
        }

        // Create New Habit Dialog
        if (showCreateDialog) {
            CreateEditHabitDialog(
                initialHabit = null,
                onSave = { newHabit ->
                    viewModel.saveHabit(newHabit)
                    showCreateDialog = false
                    Toast.makeText(context, "Quest created: ${newHabit.title}", Toast.LENGTH_SHORT).show()
                },
                onDismiss = { showCreateDialog = false }
            )
        }

        // Edit Existing Habit Dialog
        if (editingHabit != null) {
            CreateEditHabitDialog(
                initialHabit = editingHabit,
                onSave = { updatedHabit ->
                    viewModel.saveHabit(updatedHabit)
                    editingHabit = null
                    Toast.makeText(context, "Updated: ${updatedHabit.title}", Toast.LENGTH_SHORT).show()
                },
                onDelete = { habitToDelete ->
                    viewModel.deleteHabit(habitToDelete)
                    editingHabit = null
                    Toast.makeText(context, "Habit removed", Toast.LENGTH_SHORT).show()
                },
                onDismiss = { editingHabit = null }
            )
        }

        // Level Up & Badges Celebration Dialog
        celebrationEvent?.let { event ->
            CelebrationDialog(
                event = event,
                onDismiss = { viewModel.dismissCelebration() }
            )
        }
    }
}
