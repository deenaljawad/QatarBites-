package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DealOrange
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800

data class BrandBadge(
  val name: String,
  val symbol: String,
  val primaryColor: Color,
  val accentColor: Color
)

val BRAND_BADGES = mapOf(
  "All" to BrandBadge("All", "ALL", Color(0xFF38BDF8), Color(0xFF0284C7)),
  "Porsche" to BrandBadge("Porsche", "P", Color(0xFFD97706), Color(0xFFB45309)),
  "BMW" to BrandBadge("BMW", "M", Color(0xFF2563EB), Color(0xFF1D4ED8)),
  "Mercedes-Benz" to BrandBadge("Mercedes-Benz", "MB", Color(0xFF94A3B8), Color(0xFF64748B)),
  "Tesla" to BrandBadge("Tesla", "T", Color(0xFFEF4444), Color(0xFFB91C1C)),
  "Audi" to BrandBadge("Audi", "RS", Color(0xFFDC2626), Color(0xFF991B1B)),
  "Ford" to BrandBadge("Ford", "GT", Color(0xFF0284C7), Color(0xFF0369A1)),
  "Ferrari" to BrandBadge("Ferrari", "SF", Color(0xFFEF4444), Color(0xFF7F1D1D)),
  "Toyota" to BrandBadge("Toyota", "GR", Color(0xFFDC2626), Color(0xFF1E293B)),
  "Chevrolet" to BrandBadge("Chevrolet", "Z", Color(0xFFEAB308), Color(0xFFCA8A04))
)

@Composable
fun BrandFilterRow(
  brands: List<String>,
  selectedBrands: Set<String>,
  onSelectBrand: (String) -> Unit,
  brandCounts: Map<String, Int> = emptyMap(),
  modifier: Modifier = Modifier
) {
  val scrollState = rememberScrollState()

  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(scrollState)
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      brands.forEach { brand ->
        val isSelected = if (brand == "All") {
          selectedBrands.isEmpty() || selectedBrands.contains("All")
        } else {
          selectedBrands.contains(brand)
        }

        val badge = BRAND_BADGES[brand] ?: BrandBadge(brand, brand.take(2).uppercase(), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
        val count = brandCounts[brand]

        BrandChipItem(
          brandName = brand,
          badge = badge,
          isSelected = isSelected,
          carCount = count,
          onClick = { onSelectBrand(brand) }
        )
      }
    }
  }
}

@Composable
private fun BrandChipItem(
  brandName: String,
  badge: BrandBadge,
  isSelected: Boolean,
  carCount: Int?,
  onClick: () -> Unit
) {
  val backgroundColor = if (isSelected) {
    MaterialTheme.colorScheme.primaryContainer
  } else {
    MaterialTheme.colorScheme.surfaceVariant
  }

  val borderColor = if (isSelected) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.outlineVariant
  }

  val textColor = if (isSelected) {
    MaterialTheme.colorScheme.onPrimaryContainer
  } else {
    MaterialTheme.colorScheme.onSurface
  }

  Surface(
    modifier = Modifier
      .testTag("brand_chip_${brandName.lowercase().replace(" ", "_")}")
      .clip(RoundedCornerShape(20.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(20.dp),
    color = backgroundColor,
    border = androidx.compose.foundation.BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
    tonalElevation = if (isSelected) 4.dp else 0.dp
  ) {
    Row(
      modifier = Modifier
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Mini badge icon
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(
            Brush.linearGradient(
              listOf(badge.primaryColor, badge.accentColor)
            )
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = badge.symbol,
          fontSize = if (badge.symbol.length > 2) 9.sp else 10.sp,
          fontWeight = FontWeight.Black,
          color = Color.White
        )
      }

      Text(
        text = brandName,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = textColor
      )

      if (carCount != null && carCount > 0) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
              if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
              else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
            )
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "$carCount",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
