package com.example.data

import com.example.data.models.Booking
import com.example.data.models.BookingStatus
import com.example.data.models.PaymentStatus
import com.example.data.models.ScamReport
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import com.example.data.models.UrgencyLevel
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class ScamAnalysisResult(
    val riskScore: Int, // 0 to 100
    val riskLevel: RiskLevel,
    val matchedRedFlags: List<String>,
    val recommendedActions: List<String>,
    val adviceHeadline: String
)

enum class RiskLevel(val label: String, val colorHex: Long) {
    SAFE("Low Risk / Likely Safe", 0xFF10B981),
    SUSPICIOUS("Suspicious (Exercise Caution)", 0xFFF59E0B),
    DANGEROUS("High Risk / Scam Detected", 0xFFEF4444)
}

class TechHelpRepository(
    private val serviceDao: ServiceDao,
    private val bookingDao: BookingDao,
    private val scamReportDao: ScamReportDao
) {
    val allServices: Flow<List<TechService>> = serviceDao.getAllServices()
    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookings()
    val allScamReports: Flow<List<ScamReport>> = scamReportDao.getAllReports()

    fun getServicesByCategory(category: ServiceCategory): Flow<List<TechService>> =
        serviceDao.getServicesByCategory(category)

    fun getBookingById(id: String): Flow<Booking?> = bookingDao.getBookingById(id)

    suspend fun getServiceById(id: String): TechService? = serviceDao.getServiceById(id)

    suspend fun createBooking(
        service: TechService,
        customerName: String,
        customerEmail: String,
        customerPhone: String,
        appointmentDate: String,
        appointmentTimeSlot: String,
        serviceModeDetail: String,
        issueDescription: String,
        urgencyLevel: UrgencyLevel,
        paymentMethod: String,
        amountPaid: Double,
        transactionId: String = "TXN-" + UUID.randomUUID().toString().take(8).uppercase()
    ): Booking {
        val bookingId = "TH-" + (10000..99999).random()
        val booking = Booking(
            id = bookingId,
            serviceId = service.id,
            serviceTitle = service.title,
            category = service.category,
            customerName = customerName,
            customerEmail = customerEmail,
            customerPhone = customerPhone,
            appointmentDate = appointmentDate,
            appointmentTimeSlot = appointmentTimeSlot,
            serviceModeDetail = serviceModeDetail,
            issueDescription = issueDescription,
            urgencyLevel = urgencyLevel,
            assignedTechnician = if (urgencyLevel == UrgencyLevel.CRITICAL_EMERGENCY) "Rapid Dispatch Unit" else "Pending Assignment",
            status = BookingStatus.CONFIRMED,
            paymentStatus = PaymentStatus.PAID,
            paymentMethod = paymentMethod,
            amountPaid = amountPaid,
            transactionId = transactionId,
            createdAtTimestamp = System.currentTimeMillis(),
            adminNotes = "Booking initiated via app. Awaiting technician kickoff."
        )
        bookingDao.insertBooking(booking)
        return booking
    }

    suspend fun updateBooking(booking: Booking) {
        bookingDao.updateBooking(booking)
    }

    suspend fun updateBookingStatus(
        booking: Booking,
        newStatus: BookingStatus,
        technician: String? = null,
        notes: String? = null
    ) {
        val updated = booking.copy(
            status = newStatus,
            assignedTechnician = technician ?: booking.assignedTechnician,
            adminNotes = notes ?: booking.adminNotes
        )
        bookingDao.updateBooking(updated)
    }

    suspend fun updatePaymentStatus(booking: Booking, paymentStatus: PaymentStatus) {
        val updated = booking.copy(paymentStatus = paymentStatus)
        bookingDao.updateBooking(updated)
    }

    suspend fun deleteBooking(booking: Booking) {
        bookingDao.deleteBooking(booking)
    }

    suspend fun updateService(service: TechService) {
        serviceDao.updateService(service)
    }

    suspend fun addService(service: TechService) {
        serviceDao.insertService(service)
    }

    suspend fun deleteService(service: TechService) {
        serviceDao.deleteService(service)
    }

    suspend fun submitScamReport(
        reporterName: String,
        contactPhone: String,
        scamType: String,
        details: String,
        financialLossReported: Boolean,
        lossAmount: Double,
        urgency: UrgencyLevel
    ): ScamReport {
        val report = ScamReport(
            id = "SR-" + (100..999).random(),
            reporterName = reporterName,
            contactPhone = contactPhone,
            scamType = scamType,
            details = details,
            financialLossReported = financialLossReported,
            lossAmount = lossAmount,
            urgency = urgency,
            status = "Under Emergency Review",
            timestamp = System.currentTimeMillis()
        )
        scamReportDao.insertReport(report)
        return report
    }

    fun analyzeSuspiciousMessage(input: String): ScamAnalysisResult {
        val lower = input.lowercase()
        val flags = mutableListOf<String>()
        var score = 0

        // Red flag rules
        if (lower.contains("anydesk") || lower.contains("teamviewer") || lower.contains("ultraviewer") || lower.contains("quick assist") || lower.contains("remote control")) {
            flags.add("Requests unauthorized remote desktop software (Critical indicator)")
            score += 40
        }
        if (lower.contains("gift card") || lower.contains("target card") || lower.contains("apple card") || lower.contains("bitcoin") || lower.contains("crypto kiosk")) {
            flags.add("Demands payment via untraceable Gift Cards or Crypto (100% Scam indicator)")
            score += 45
        }
        if (lower.contains("urgent") || lower.contains("immediately") || lower.contains("within 24 hours") || lower.contains("arrest warrant") || lower.contains("police") || lower.contains("law enforcement")) {
            flags.add("High-pressure psychological intimidation and fake urgency")
            score += 25
        }
        if (lower.contains("refund") && (lower.contains("overpaid") || lower.contains("fill out form") || lower.contains("geeksquad") || lower.contains("norton") || lower.contains("mcafee"))) {
            flags.add("Classic Tech Support / Overpayment Refund Trap")
            score += 35
        }
        if (lower.contains("bank") && (lower.contains("fraud") || lower.contains("account suspended") || lower.contains("verify login") || lower.contains("one-time code") || lower.contains("otp"))) {
            flags.add("Phishing attempt seeking 2FA / Bank login credentials")
            score += 30
        }
        if (lower.contains("bit.ly") || lower.contains("tinyurl") || lower.contains("t.co") || lower.contains("is.gd") || lower.contains(".xyz") || lower.contains(".top")) {
            flags.add("Obfuscated or suspicious shortened redirect link")
            score += 20
        }
        if (lower.contains("win") || lower.contains("winner") || lower.contains("lottery") || lower.contains("claim your prize")) {
            flags.add("Unsolicited prize / sweepstakes bait")
            score += 25
        }

        val clampedScore = score.coerceIn(0, 100)
        val level = when {
            clampedScore >= 60 -> RiskLevel.DANGEROUS
            clampedScore >= 25 -> RiskLevel.SUSPICIOUS
            else -> RiskLevel.SAFE
        }

        val actions = when (level) {
            RiskLevel.DANGEROUS -> listOf(
                "DO NOT install any software requested by the caller or sender.",
                "DO NOT give out one-time SMS passcodes, passwords, or SSN.",
                "Disconnect your device from Wi-Fi immediately if remote access was granted.",
                "Call your bank's official number on the back of your card if money was sent.",
                "Book an Emergency Lockdown session in TechHelp4U right now."
            )
            RiskLevel.SUSPICIOUS -> listOf(
                "Verify the sender's authentic email address or phone number directly.",
                "Never click links inside unverified SMS or email notifications.",
                "Check your genuine banking app or account portal without using provided links."
            )
            RiskLevel.SAFE -> listOf(
                "No glaring scam keywords detected, but remain cautious with personal info.",
                "Verify sender authenticity before clicking unknown attachments."
            )
        }

        val headline = when (level) {
            RiskLevel.DANGEROUS -> "⚠️ CRITICAL SCAM RISK: DO NOT ENGAGE OR PAY"
            RiskLevel.SUSPICIOUS -> "⚡ SUSPICIOUS ACTIVITY DETECTED"
            RiskLevel.SAFE -> "✅ NO HIGH-RISK SCAM INDICATORS DETECTED"
        }

        return ScamAnalysisResult(
            riskScore = clampedScore,
            riskLevel = level,
            matchedRedFlags = flags.ifEmpty { listOf("No critical scam keywords found in the sample text.") },
            recommendedActions = actions,
            adviceHeadline = headline
        )
    }
}
