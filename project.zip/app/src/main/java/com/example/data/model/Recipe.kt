package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Recipe(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val mealType: String = "Dinner",
    val prepTime: Int = 15,
    val cookTime: Int = 25,
    val servings: Int = 2,
    val calories: Int = 450,
    val protein: Int = 30,
    val carbs: Int = 40,
    val fat: Int = 15,
    val ingredients: List<String> = emptyList(),
    val instructions: List<String> = emptyList(),
    val matchingPantryIngredients: List<String> = emptyList(),
    val missingIngredients: List<String> = emptyList(),
    @get:PropertyName("isFavorite") @set:PropertyName("isFavorite") var isFavorite: Boolean = false,
    val plannedDate: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
