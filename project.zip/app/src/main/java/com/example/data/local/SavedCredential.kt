package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_credentials")
data class SavedCredential(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val label: String,
    val password: String,
    val username: String = "",
    val category: String = "General", // General, Personal, Work, Finance, Social
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
