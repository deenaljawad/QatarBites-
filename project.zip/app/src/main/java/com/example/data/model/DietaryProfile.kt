package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class DietaryProfile(
    val diets: List<String> = emptyList(),
    val allergies: List<String> = emptyList(),
    val dislikes: List<String> = emptyList(),
    val calorieTarget: Int = 2000,
    val servingsPreference: Int = 2,
    val cookingTimePreference: String = "Under 30 mins",
    @ServerTimestamp val updatedAt: Timestamp? = null
)
