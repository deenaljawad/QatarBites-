package com.example.data.repository

import android.location.Location
import com.example.data.model.FilterSettings
import com.example.data.model.Restaurant

class RestaurantRepository {

    private val allRestaurants: List<Restaurant> = listOf(
        Restaurant(
            id = "smat_katara",
            name = "SMAT Restaurant",
            arabicName = "مطعم سمات",
            tagline = "Elevated Qatari & Khaleeji Fine Dining",
            cuisine = "Qatari & Khaleeji",
            area = "Katara Cultural Village",
            rating = 4.8,
            reviewCount = 2140,
            priceLevel = "$$$",
            averageSpendQar = "190 - 320 QAR",
            latitude = 25.3582,
            longitude = 51.5285,
            address = "Building 41, Katara Cultural Village, Doha, Qatar",
            phoneNumber = "+974 4410 0800",
            openingHours = "12:30 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1544025162-d76694265947?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Majboos Rubiyan", "Lamb Shoulder Machboos", "Regag with Zaatar & Cheese", "Umm Ali Cheesecake"),
            highlights = listOf("Sea View", "Traditional Qatari Spices", "Outdoor Terrace", "Katara Promenade"),
            description = "SMAT, meaning dining table in Khaleeji dialect, pays homage to Qatar's rich culinary roots while modernizing traditional flavors with royal presentation and beachfront atmosphere."
        ),
        Restaurant(
            id = "jiwan_nmoq",
            name = "Jiwan Restaurant",
            arabicName = "مطعم جِوان",
            tagline = "By Michelin Star Alain Ducasse at National Museum",
            cuisine = "Contemporary Qatari",
            area = "Corniche & NMoQ",
            rating = 4.9,
            reviewCount = 1890,
            priceLevel = "$$$$",
            averageSpendQar = "280 - 450 QAR",
            latitude = 25.2867,
            longitude = 51.5487,
            address = "4th Floor, National Museum of Qatar, Museum Park St, Doha",
            phoneNumber = "+974 4452 5725",
            openingHours = "1:00 PM - 10:00 PM",
            imageUrl = "https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Camel Meat Stew with Truffles", "Madrooba with Roasted Seeds", "Cardamom Infused Dates", "Saffron Halwa Tart"),
            highlights = listOf("Desert Rose Architecture", "Panoramic Corniche Terrace", "Ducasse Paris Concept", "Sunset Golden Hour"),
            description = "Perched on the top floor of the iconic National Museum of Qatar, Jiwan offers an evocative culinary voyage across Qatar's desert and maritime history."
        ),
        Restaurant(
            id = "parisa_souq",
            name = "Parisa Souq Waqif",
            arabicName = "مطعم باريسا سوق واقف",
            tagline = "A Fairytale Persian Mirror Palace",
            cuisine = "Persian & Iranian",
            area = "Souq Waqif",
            rating = 4.8,
            reviewCount = 3450,
            priceLevel = "$$$",
            averageSpendQar = "170 - 290 QAR",
            latitude = 25.2872,
            longitude = 51.5330,
            address = "Al Ahmed Street, Souq Waqif, Doha, Qatar",
            phoneNumber = "+974 4441 1494",
            openingHours = "1:00 PM - 11:00 PM",
            imageUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Chelo Kebab Koobideh", "Zereshk Polo Ba Morgh", "Ghormeh Sabzi", "Persian Saffron Ice Cream with Pistachio"),
            highlights = listOf("Thousands of Hand-Cut Mirrors", "Souq Waqif Alleyways", "Royal Handcrafted Murals", "VIP Majlis"),
            description = "Step into a breathtaking Persian palace inside vibrant Souq Waqif adorned with thousands of hand-cut mirrors, crystal chandeliers, and mouthwatering grilled kebabs."
        ),
        Restaurant(
            id = "nobu_doha",
            name = "Nobu Doha",
            arabicName = "نوبو الدوحة",
            tagline = "The World's Largest Nobu on the Arabian Gulf",
            cuisine = "Japanese & Nikkei",
            area = "West Bay",
            rating = 4.8,
            reviewCount = 2870,
            priceLevel = "$$$$",
            averageSpendQar = "350 - 600 QAR",
            latitude = 25.3217,
            longitude = 51.5348,
            address = "Four Seasons Hotel Doha, The Corniche, Doha, Qatar",
            phoneNumber = "+974 4494 8500",
            openingHours = "6:00 PM - 12:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Black Cod with Miso", "Yellowtail Jalapeño", "Wagyu Beef Flambé", "Crispy Rice with Spicy Tuna"),
            highlights = listOf("Oyster Shell Shaped Island", "360 Rooftop Lounge", "Chef Nobu Matsuhisa", "Unmatched Arabian Sea View"),
            description = "Designed by David Rockwell, this multi-tier circular architectural marvel stands on its own private pier in the Arabian Gulf, delivering legendary Japanese-Peruvian cuisine."
        ),
        Restaurant(
            id = "damasca_one",
            name = "Damasca One",
            arabicName = "دماسكا ون سوق واقف",
            tagline = "Heart of Syrian & Levantine Hospitality",
            cuisine = "Levantine & Syrian",
            area = "Souq Waqif",
            rating = 4.7,
            reviewCount = 4120,
            priceLevel = "$$",
            averageSpendQar = "120 - 220 QAR",
            latitude = 25.2875,
            longitude = 51.5325,
            address = "Souq Waqif Main Square, Doha, Qatar",
            phoneNumber = "+974 4475 9088",
            openingHours = "8:00 AM - 12:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Shami Mixed Grill", "Aleppo Cherry Kebab", "Fresh Baked Fatteh", "Kunafa Nabulsieh"),
            highlights = listOf("Souq People Watching", "Live Arabic Music", "Shisha Terrace", "Family Friendly"),
            description = "Located right on the main walkway of Souq Waqif, Damasca One serves authentic Levantine feasts with Syrian warmth, sizzled grilled platters, and lively evening ambiance."
        ),
        Restaurant(
            id = "yasmine_palace",
            name = "Yasmine Palace",
            arabicName = "قصر الياسمين اللؤلؤة",
            tagline = "Luxurious Multi-Themed Andalusian Dining",
            cuisine = "Middle Eastern & Andalusian",
            area = "The Pearl-Qatar",
            rating = 4.8,
            reviewCount = 3100,
            priceLevel = "$$$",
            averageSpendQar = "180 - 300 QAR",
            latitude = 25.3695,
            longitude = 51.5467,
            address = "Porto Arabia, Marina Boardwalk, Parcel 18, The Pearl, Doha",
            phoneNumber = "+974 4411 1502",
            openingHours = "9:00 AM - 1:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Andalusian Mixed Grill", "Lamb Mansaf", "Sayadieh Fish", "Warm Baklava with Maras Ice Cream"),
            highlights = listOf("Porto Arabia Marina View", "Andalusian Architecture", "Indoor Fountains", "Royal Courtyard"),
            description = "A monumental dining complex at The Pearl celebrating Andalusian, Qatari, and Levantine heritage with majestic arched columns, fountains, and waterfront boardwalk seating."
        ),
        Restaurant(
            id = "zuma_lusail",
            name = "Zuma Doha",
            arabicName = "زوما لوسيل",
            tagline = "Sophisticated Contemporary Izakaya",
            cuisine = "Japanese",
            area = "Lusail & Al Maha Island",
            rating = 4.9,
            reviewCount = 1620,
            priceLevel = "$$$$",
            averageSpendQar = "380 - 650 QAR",
            latitude = 25.4220,
            longitude = 51.5240,
            address = "Al Maha Island, Marina District, Lusail, Qatar",
            phoneNumber = "+974 4497 1234",
            openingHours = "12:30 PM - 1:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Robata Grilled Lamb Cutlets", "Spicy Beef Tenderloin", "Chilean Sea Bass", "Deluxe Sashimi Platter"),
            highlights = listOf("Al Maha Island Marina", "Robata Grill Showcase", "DJ Beats", "Celebrity Dining Spot"),
            description = "Located on luxurious Al Maha Island in Lusail, Zuma brings its world-acclaimed izakaya concept with robata grills, pristine sashimi, and unmatched marina sunset views."
        ),
        Restaurant(
            id = "lpm_lusail",
            name = "LPM Restaurant & Bar",
            arabicName = "مطعم إل بي إم لوسيل",
            tagline = "French Mediterranean Elegance",
            cuisine = "French Mediterranean",
            area = "Lusail & Al Maha Island",
            rating = 4.8,
            reviewCount = 1430,
            priceLevel = "$$$$",
            averageSpendQar = "320 - 550 QAR",
            latitude = 25.4215,
            longitude = 51.5234,
            address = "Al Maha Island, Lusail Marina, Doha, Qatar",
            phoneNumber = "+974 4420 3333",
            openingHours = "12:00 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1502301103665-0b95cc738daf?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Burrata with Sweet Cherry Tomatoes", "Warm Prawns with Olive Oil", "Marinated Baby Chicken", "Vanilla Crème Brûlée"),
            highlights = listOf("Riviera Vibe", "Fine Art Gallery", "Seafront Patio", "Al Maha Island Boardwalk"),
            description = "Bringing the Belle Époque magic of the French Riviera to Lusail, LPM serves fresh Mediterranean dishes celebrated for simple, high-grade olive oils and ingredients."
        ),
        Restaurant(
            id = "saasna_msheireb",
            name = "Saasna",
            arabicName = "مطعم ساسنا مشيرب",
            tagline = "Modern Qatari Kitchen & Heritage",
            cuisine = "Qatari & Khaleeji",
            area = "Msheireb Downtown",
            rating = 4.8,
            reviewCount = 1290,
            priceLevel = "$$$",
            averageSpendQar = "160 - 270 QAR",
            latitude = 25.2880,
            longitude = 51.5272,
            address = "Barahat Msheireb, Sikkat Wadi Msheireb, Downtown Doha",
            phoneNumber = "+974 5519 7131",
            openingHours = "1:00 PM - 11:00 PM",
            imageUrl = "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Qatari Chicken Biryani", "Simmered Harees with Ghee", "Saffron Fish Saloona", "Luqaimat with Date Syrup"),
            highlights = listOf("Barahat Msheireb Retractable Roof", "Smart Sustainable City", "Contemporary Majlis", "Pedestrian Walkway"),
            description = "Chef-curated pure Qatari cuisine nestled in the heart of Msheireb Downtown, where modern minimalist aesthetics meet centuries-old desert culinary hospitality."
        ),
        Restaurant(
            id = "morimoto_doha",
            name = "Morimoto Doha",
            arabicName = "موريموتو مونريان",
            tagline = "Iron Chef Masaharu Morimoto's Masterpiece",
            cuisine = "Japanese & Sushi",
            area = "West Bay",
            rating = 4.8,
            reviewCount = 1950,
            priceLevel = "$$$$",
            averageSpendQar = "320 - 580 QAR",
            latitude = 25.3789,
            longitude = 51.5273,
            address = "Mondrian Doha, West Bay Lagoon, Doha, Qatar",
            phoneNumber = "+974 4045 5999",
            openingHours = "6:00 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("A5 Miyazaki Wagyu Sukiyaki", "Tuna Pizza with Anchovy Aioli", "Chef Morimoto Omakase", "Matcha Fondant"),
            highlights = listOf("Dramatic Rose-Gold Columns", "Hiroshi Senju Art", "Omakase Sushi Counter", "Mondrian Luxury"),
            description = "The first restaurant in the Middle East by acclaimed Iron Chef Morimoto. Enjoy breathtaking rose-gold interiors, hand-painted Japanese artwork, and pristine cuts of wagyu and sashimi."
        ),
        Restaurant(
            id = "hakkasan_doha",
            name = "Hakkasan Doha",
            arabicName = "هاكاسان الدوحة",
            tagline = "World Class Cantonese & Dim Sum",
            cuisine = "Cantonese & Asian",
            area = "West Bay",
            rating = 4.7,
            reviewCount = 2300,
            priceLevel = "$$$$",
            averageSpendQar = "300 - 520 QAR",
            latitude = 25.3533,
            longitude = 51.5303,
            address = "The St. Regis Doha, Al Gassar Resort, West Bay, Doha",
            phoneNumber = "+974 4446 0170",
            openingHours = "6:00 PM - 12:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Crispy Duck with Royal Beluga Caviar", "Hakkasan Signature Dim Sum Trio", "Stir-fry Black Pepper Beef", "Jasmine Smoked Wagyu Ribs"),
            highlights = listOf("St. Regis Gardens", "Lush Ling Ling Lounge", "Intricate Wood Lattice", "Outdoor Terrace"),
            description = "Nestled within the gardens of The St. Regis Doha, Hakkasan combines Michelin-caliber Cantonese cooking with dramatic modern lighting and world-class service."
        ),
        Restaurant(
            id = "bayt_el_talleh",
            name = "Bayt El Talleh",
            arabicName = "بيت التلة كتارا",
            tagline = "Authentic Levantine Atop Katara Hills",
            cuisine = "Levantine & Lebanese",
            area = "Katara Cultural Village",
            rating = 4.8,
            reviewCount = 2780,
            priceLevel = "$$$",
            averageSpendQar = "160 - 280 QAR",
            latitude = 25.3621,
            longitude = 51.5240,
            address = "Katara South Hills, Katara, Doha, Qatar",
            phoneNumber = "+974 4408 1777",
            openingHours = "9:00 AM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1544025162-d76694265947?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Levantine Breakfast Set", "Slow Cooked Lamb with Rice", "Katara Mixed Mashawi", "Osmalieh with Fresh Ashta"),
            highlights = listOf("Katara Hills Skyline View", "Country House Architecture", "Outdoor Hillside Garden", "Cozy Fireplaces"),
            description = "Nestled at the summit of Katara South Hills, this picturesque stone manor overlooks the Doha skyline and lush greenery, serving home-style Levantine comfort delicacies."
        ),
        Restaurant(
            id = "al_nahham_banana",
            name = "Al Nahham",
            arabicName = "مطعم النّهام جزيرة البنانا",
            tagline = "Overwater Arabian Gulf Seafood Dining",
            cuisine = "Arabian Seafood",
            area = "Banana Island & Corniche",
            rating = 4.9,
            reviewCount = 1750,
            priceLevel = "$$$$",
            averageSpendQar = "320 - 580 QAR",
            latitude = 25.2974,
            longitude = 51.6420,
            address = "Banana Island Resort Doha by Anantara (Access via Luxury Ferry from Shyoukh Terminal)",
            phoneNumber = "+974 4040 5075",
            openingHours = "1:00 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Fresh Gulf Lobster Thermidor", "Tiger Prawns with Harissa", "Hamour Sayadieh", "Middle Eastern Cold Mezze Platter"),
            highlights = listOf("Overwater Balcony over the Sea", "Luxury Catamaran Ferry Arrival", "Breathtaking Doha Skyline View", "Glass Bottom Seating"),
            description = "Reached via a VIP luxury catamaran ferry from Corniche terminal, Al Nahham juts out over turquoise Arabian waters on Banana Island, offering royal seafood dinners beneath starlit skies."
        ),
        Restaurant(
            id = "toro_toro_pearl",
            name = "Toro Toro Doha",
            arabicName = "تورو تورو اللؤلؤة",
            tagline = "Pan-Latin Rodizio by Chef Richard Sandoval",
            cuisine = "Pan-Latin & Steakhouse",
            area = "The Pearl-Qatar",
            rating = 4.7,
            reviewCount = 2650,
            priceLevel = "$$$$",
            averageSpendQar = "260 - 480 QAR",
            latitude = 25.3746,
            longitude = 51.5543,
            address = "Marsa Malaz Kempinski, Costa Malaz Bay, The Pearl, Doha",
            phoneNumber = "+974 4035 5101",
            openingHours = "6:00 PM - 1:00 AM",
            imageUrl = "https://images.unsplash.com/photo-1544025162-d76694265947?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Churrasco Brazilian Skewers", "Guacamole with Crispy Plantains", "Picanha Steak", "Dulce de Leche Fondant"),
            highlights = listOf("Kempinski Private Island", "Marina Views", "Churrascaria Carver Table Service", "Vibrant Latin Atmosphere"),
            description = "Located inside the glamorous Marsa Malaz Kempinski palace on its private island in The Pearl, Toro Toro celebrates lively Latin American rodizio churrasco feasts."
        ),
        Restaurant(
            id = "cut_wolfgang_puck",
            name = "CUT by Wolfgang Puck",
            arabicName = "كت باي ولفجانج بوك",
            tagline = "Beverly Hills Glamour & USDA Prime Cuts",
            cuisine = "American Steakhouse",
            area = "West Bay",
            rating = 4.7,
            reviewCount = 1820,
            priceLevel = "$$$$",
            averageSpendQar = "340 - 620 QAR",
            latitude = 25.3787,
            longitude = 51.5275,
            address = "Mondrian Doha, West Bay Lagoon, Doha, Qatar",
            phoneNumber = "+974 4045 5999",
            openingHours = "12:00 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1558030006-450675393462?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Australian Wagyu Tomahawk", "USDA Prime Bone-in Ribeye", "Maryland Crab Cakes", "Warm Chocolate Soufflé"),
            highlights = listOf("Celebrity Chef Wolfgang Puck", "Mondrian Grand Staircase", "Courtyard Brunch", "Fine Wine Cellar"),
            description = "Wolfgang Puck brings his Beverly Hills legend to Doha. CUT delivers flawless prime cuts of beef, masterfully seared over white oak and charcoal."
        ),
        Restaurant(
            id = "paper_moon_doha",
            name = "Paper Moon Doha",
            arabicName = "بيبر مون الدوحة",
            tagline = "Authentic Milanese Sophistication",
            cuisine = "Italian",
            area = "Corniche & Downtown",
            rating = 4.7,
            reviewCount = 2080,
            priceLevel = "$$$",
            averageSpendQar = "170 - 290 QAR",
            latitude = 25.2758,
            longitude = 51.5412,
            address = "Jaidah Square, Al Matar Street, Umm Ghuwailina, Doha",
            phoneNumber = "+974 4016 6000",
            openingHours = "12:00 PM - 11:30 PM",
            imageUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=900&auto=format&fit=crop&q=80",
            signatureDishes = listOf("Pappardelle al Telefono", "Pizza Paper Moon with Bresaola", "Ossobuco alla Milanese with Saffron Risotto", "Classic Tiramisu"),
            highlights = listOf("Wood-fired Pizza Oven", "Milano Chic Dining", "Spacious Garden Terrace", "Business Lunch Hotspot"),
            description = "An institution of Milan dining since 1977, Paper Moon Doha serves handcrafted pastas, artisan thin-crust pizzas, and genuine Italian warmth in sleek contemporary surroundings."
        )
    )

    fun getAllRestaurants(): List<Restaurant> = allRestaurants

    fun getRestaurantById(id: String): Restaurant? = allRestaurants.find { it.id == id }

    fun getFilteredRestaurants(
        filterSettings: FilterSettings,
        userLocation: Location?
    ): List<Restaurant> {
        val filtered = allRestaurants.filter { restaurant ->
            val matchesArea = filterSettings.selectedArea == "All Qatar" ||
                    restaurant.area.contains(filterSettings.selectedArea, ignoreCase = true)

            val matchesCuisine = filterSettings.selectedCuisine == "All" ||
                    restaurant.cuisine.contains(filterSettings.selectedCuisine, ignoreCase = true)

            val matchesRating = restaurant.rating >= filterSettings.minRating

            matchesArea && matchesCuisine && matchesRating
        }.map { restaurant ->
            if (userLocation != null) {
                val results = FloatArray(1)
                Location.distanceBetween(
                    userLocation.latitude,
                    userLocation.longitude,
                    restaurant.latitude,
                    restaurant.longitude,
                    results
                )
                val distanceInKm = results[0] / 1000.0
                restaurant.copy(distanceKm = String.format("%.1f", distanceInKm).toDoubleOrNull() ?: (results[0] / 1000.0))
            } else {
                restaurant
            }
        }

        return if (filterSettings.sortByDistance && userLocation != null) {
            filtered.sortedBy { it.distanceKm ?: Double.MAX_VALUE }
        } else {
            filtered.sortedByDescending { it.rating }
        }
    }

    fun getAvailableAreas(): List<String> = listOf(
        "All Qatar",
        "Souq Waqif",
        "The Pearl-Qatar",
        "Katara Cultural Village",
        "Lusail & Al Maha Island",
        "West Bay",
        "Msheireb Downtown"
    )

    fun getAvailableCuisines(): List<String> = listOf(
        "All",
        "Qatari & Khaleeji",
        "Persian & Iranian",
        "Levantine",
        "Japanese",
        "Seafood",
        "Steakhouse",
        "French Mediterranean",
        "Italian"
    )
}
