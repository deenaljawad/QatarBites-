package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: HabitType,
    val frequencyType: FrequencyType,
    val targetDaysOfWeek: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7), // 1=Mon .. 7=Sun
    val targetValue: Double = 1.0,
    val unit: String = "times",
    val reminderHour: Int? = null, // 0-23
    val reminderMinute: Int? = null, // 0-59
    val reminderEnabled: Boolean = false,
    val colorHex: String = "#10B981",
    val iconName: String = "fitness",
    val createdAt: Long = System.currentTimeMillis(),
    val archived: Boolean = false,
    val quitCleanStartTimestamp: Long = System.currentTimeMillis(), // For BREAK habits: start of clean timer
    val quitTotalSlips: Int = 0
)

@Entity(
    tableName = "habit_logs",
    indices = [androidx.room.Index(value = ["habitId", "dateString"], unique = true)]
)
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val habitId: Long,
    val dateString: String, // Format: "yyyy-MM-dd"
    val value: Double,
    val isCompleted: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey
    val id: Int = 1,
    val xp: Int = 0,
    val level: Int = 1,
    val unlockedBadgeIds: List<String> = emptyList(),
    val lastActiveDate: String = "",
    val cravingsResistedCount: Int = 0,
    val totalCompletions: Int = 0,
    val longestStreakAllTime: Int = 0
)
