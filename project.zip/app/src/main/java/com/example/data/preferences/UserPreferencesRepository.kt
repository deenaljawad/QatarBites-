package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "qatar_bites_prefs")

data class UserPreferences(
    val themeMode: String = "system", // "system", "dark", "light"
    val useLocationForNearby: Boolean = false,
    val likedIds: Set<String> = emptySet(),
    val passedIds: Set<String> = emptySet(),
    val superLikedIds: Set<String> = emptySet()
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val USE_LOCATION = booleanPreferencesKey("use_location_nearby")
        val LIKED_IDS = stringSetPreferencesKey("liked_restaurant_ids")
        val PASSED_IDS = stringSetPreferencesKey("passed_restaurant_ids")
        val SUPER_LIKED_IDS = stringSetPreferencesKey("super_liked_restaurant_ids")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        UserPreferences(
            themeMode = preferences[Keys.THEME_MODE] ?: "system",
            useLocationForNearby = preferences[Keys.USE_LOCATION] ?: false,
            likedIds = preferences[Keys.LIKED_IDS] ?: emptySet(),
            passedIds = preferences[Keys.PASSED_IDS] ?: emptySet(),
            superLikedIds = preferences[Keys.SUPER_LIKED_IDS] ?: emptySet()
        )
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.THEME_MODE] = mode
        }
    }

    suspend fun setUseLocation(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[Keys.USE_LOCATION] = enabled
        }
    }

    suspend fun saveSwipe(restaurantId: String, isLike: Boolean, isSuperLike: Boolean = false) {
        context.dataStore.edit { preferences ->
            val currentLikes = preferences[Keys.LIKED_IDS]?.toMutableSet() ?: mutableSetOf()
            val currentPasses = preferences[Keys.PASSED_IDS]?.toMutableSet() ?: mutableSetOf()
            val currentSuperLikes = preferences[Keys.SUPER_LIKED_IDS]?.toMutableSet() ?: mutableSetOf()

            if (isSuperLike) {
                currentSuperLikes.add(restaurantId)
                currentLikes.add(restaurantId)
                currentPasses.remove(restaurantId)
            } else if (isLike) {
                currentLikes.add(restaurantId)
                currentPasses.remove(restaurantId)
            } else {
                currentPasses.add(restaurantId)
                currentLikes.remove(restaurantId)
                currentSuperLikes.remove(restaurantId)
            }

            preferences[Keys.LIKED_IDS] = currentLikes
            preferences[Keys.PASSED_IDS] = currentPasses
            preferences[Keys.SUPER_LIKED_IDS] = currentSuperLikes
        }
    }

    suspend fun removeLike(restaurantId: String) {
        context.dataStore.edit { preferences ->
            val currentLikes = preferences[Keys.LIKED_IDS]?.toMutableSet() ?: mutableSetOf()
            val currentSuperLikes = preferences[Keys.SUPER_LIKED_IDS]?.toMutableSet() ?: mutableSetOf()
            currentLikes.remove(restaurantId)
            currentSuperLikes.remove(restaurantId)
            preferences[Keys.LIKED_IDS] = currentLikes
            preferences[Keys.SUPER_LIKED_IDS] = currentSuperLikes
        }
    }

    suspend fun resetDeckHistory() {
        context.dataStore.edit { preferences ->
            preferences[Keys.PASSED_IDS] = emptySet()
            // Keep likes or clear? We clear passed so they can swipe again
        }
    }

    suspend fun clearAllHistory() {
        context.dataStore.edit { preferences ->
            preferences[Keys.LIKED_IDS] = emptySet()
            preferences[Keys.PASSED_IDS] = emptySet()
            preferences[Keys.SUPER_LIKED_IDS] = emptySet()
        }
    }
}
