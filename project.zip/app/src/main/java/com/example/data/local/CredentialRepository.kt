package com.example.data.local

import kotlinx.coroutines.flow.Flow

class CredentialRepository(private val dao: CredentialDao) {

    fun getAllCredentials(): Flow<List<SavedCredential>> = dao.getAllCredentials()

    fun searchCredentials(query: String): Flow<List<SavedCredential>> =
        if (query.isBlank()) dao.getAllCredentials() else dao.searchCredentials(query.trim())

    suspend fun getCredentialById(id: Long): SavedCredential? = dao.getCredentialById(id)

    suspend fun saveCredential(credential: SavedCredential): Long = dao.insert(credential)

    suspend fun updateCredential(credential: SavedCredential) = dao.update(credential)

    suspend fun deleteCredential(credential: SavedCredential) = dao.delete(credential)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()
}
