package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.DietaryProfile
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class DietaryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    fun observeDietaryProfile(): Flow<DietaryProfile?> = flow {
        val uid = requireUserId()
        val path = "users/$uid/profile/dietary"
        emitAll(
            db.collection("users").document(uid).collection("profile").document("dietary")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) snapshot.toObject(DietaryProfile::class.java) else null
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                    throw error
                }
        )
    }

    suspend fun saveDietaryProfile(profile: DietaryProfile) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("profile").document("dietary")
        val data = hashMapOf<String, Any>(
            "diets" to profile.diets,
            "allergies" to profile.allergies,
            "dislikes" to profile.dislikes,
            "calorieTarget" to profile.calorieTarget,
            "servingsPreference" to profile.servingsPreference,
            "cookingTimePreference" to profile.cookingTimePreference,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(data).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }
}
