package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Recipe
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class RecipeRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    fun observeRecipes(): Flow<List<Recipe>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/recipes"
        emitAll(
            db.collection("users").document(uid).collection("recipes")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Recipe::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun saveRecipe(recipe: Recipe): String {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("recipes")
        val data = hashMapOf<String, Any>(
            "title" to recipe.title.trim(),
            "description" to recipe.description.trim(),
            "mealType" to recipe.mealType.trim(),
            "prepTime" to recipe.prepTime,
            "cookTime" to recipe.cookTime,
            "servings" to recipe.servings,
            "calories" to recipe.calories,
            "protein" to recipe.protein,
            "carbs" to recipe.carbs,
            "fat" to recipe.fat,
            "ingredients" to recipe.ingredients,
            "instructions" to recipe.instructions,
            "matchingPantryIngredients" to recipe.matchingPantryIngredients,
            "missingIngredients" to recipe.missingIngredients,
            "isFavorite" to recipe.isFavorite,
            "plannedDate" to recipe.plannedDate,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            val docRef = colRef.add(data).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, colRef.path)
            throw e
        }
    }

    suspend fun toggleFavorite(recipe: Recipe) {
        val uid = requireUserId()
        require(recipe.id.isNotBlank()) { "Recipe ID must not be blank for update" }
        requireNotNull(recipe.createdAt) { "Recipe createdAt must not be null for update" }
        val docRef = db.collection("users").document(uid).collection("recipes").document(recipe.id)
        try {
            val updated = recipe.copy(isFavorite = !recipe.isFavorite, updatedAt = null)
            docRef.set(updated).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updatePlannedDate(recipe: Recipe, plannedDate: String) {
        val uid = requireUserId()
        require(recipe.id.isNotBlank()) { "Recipe ID must not be blank for update" }
        requireNotNull(recipe.createdAt) { "Recipe createdAt must not be null for update" }
        val docRef = db.collection("users").document(uid).collection("recipes").document(recipe.id)
        try {
            val updated = recipe.copy(plannedDate = plannedDate, updatedAt = null)
            docRef.set(updated).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteRecipe(recipeId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("recipes").document(recipeId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }
}
