package com.example.data

enum class HabitType {
    BUILD, // Start / Build a positive habit
    BREAK  // Quit / Break an unwanted habit
}

enum class FrequencyType {
    DAILY,
    WEEKLY,
    MONTHLY,
    SPECIFIC_DAYS
}
