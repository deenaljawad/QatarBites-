package com.example.data.model

data class Restaurant(
    val id: String,
    val name: String,
    val arabicName: String,
    val tagline: String,
    val cuisine: String,
    val area: String,
    val rating: Double,
    val reviewCount: Int,
    val priceLevel: String, // "$$", "$$$", "$$$$"
    val averageSpendQar: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val phoneNumber: String,
    val openingHours: String,
    val imageUrl: String,
    val signatureDishes: List<String>,
    val highlights: List<String>,
    val description: String,
    val distanceKm: Double? = null // calculated when location is active
) {
    val googleMapsUrl: String
        get() = "https://www.google.com/maps/search/?api=1&query=${android.net.Uri.encode("$name $area Doha Qatar")}"

    val googleMapsNavigationUrl: String
        get() = "google.navigation:q=$latitude,$longitude"
}

data class FilterSettings(
    val selectedArea: String = "All Qatar",
    val selectedCuisine: String = "All",
    val minRating: Double = 4.5,
    val sortByDistance: Boolean = false
)
