package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CredentialDao {

    @Query("SELECT * FROM saved_credentials ORDER BY updatedAt DESC")
    fun getAllCredentials(): Flow<List<SavedCredential>>

    @Query("""
        SELECT * FROM saved_credentials 
        WHERE label LIKE '%' || :query || '%' 
           OR username LIKE '%' || :query || '%' 
           OR category LIKE '%' || :query || '%'
           OR notes LIKE '%' || :query || '%'
        ORDER BY updatedAt DESC
    """)
    fun searchCredentials(query: String): Flow<List<SavedCredential>>

    @Query("SELECT * FROM saved_credentials WHERE id = :id LIMIT 1")
    suspend fun getCredentialById(id: Long): SavedCredential?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(credential: SavedCredential): Long

    @Update
    suspend fun update(credential: SavedCredential)

    @Delete
    suspend fun delete(credential: SavedCredential)

    @Query("DELETE FROM saved_credentials WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM saved_credentials")
    suspend fun deleteAll()
}
