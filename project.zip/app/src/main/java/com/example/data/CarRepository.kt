package com.example.data

import com.example.model.Car
import com.example.model.CarFilterState
import com.example.model.OfferInquiry
import com.example.model.SortOption
import com.example.model.TestDriveBooking
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CarRepository {

  private val _favoriteIds = MutableStateFlow<Set<String>>(setOf("car_2", "car_5"))
  val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

  private val _comparisonIds = MutableStateFlow<Set<String>>(setOf("car_1", "car_3"))
  val comparisonIds: StateFlow<Set<String>> = _comparisonIds.asStateFlow()

  private val _testDrives = MutableStateFlow<List<TestDriveBooking>>(emptyList())
  val testDrives: StateFlow<List<TestDriveBooking>> = _testDrives.asStateFlow()

  private val _offers = MutableStateFlow<List<OfferInquiry>>(emptyList())
  val offers: StateFlow<List<OfferInquiry>> = _offers.asStateFlow()

  val allCars: List<Car> = listOf(
    Car(
      id = "car_1",
      brand = "Porsche",
      model = "911 Carrera S",
      year = 2024,
      trim = "Sport Chrono Package",
      price = 131200.0,
      originalPrice = 144500.0,
      isHotDeal = true,
      dealBadge = "Save $13,300 • Dealer Demo",
      bodyType = "Coupe",
      condition = "Certified Pre-Owned",
      mileage = 1840,
      fuelType = "Twin-Turbo Flat-6",
      transmission = "8-Speed Porsche Doppelkupplung (PDK)",
      drivetrain = "RWD",
      horsepower = 443,
      zeroToSixty = 3.3,
      topSpeed = 191,
      rangeOrMpg = "20 MPG combined",
      exteriorColor = "Chalk Grey",
      interiorColor = "Bordeaux Red / Black Leather",
      rating = 4.9,
      reviewCount = 42,
      dealerName = "Porsche Center Beverly Hills",
      dealerLocation = "Beverly Hills, CA",
      dealerPhone = "(310) 555-0199",
      features = listOf(
        "Sport Chrono Package with Mode Switch",
        "PASM Sport Suspension (-10 mm)",
        "Burmester 3D High-End Surround Sound",
        "Sport Exhaust System with Silver Tailpipes",
        "14-Way Power Sport Seats with Memory",
        "Lane Change Assist & Surround View"
      ),
      description = "Pristine 2024 911 Carrera S with the coveted Sport Chrono package and bespoke Chalk exterior over Bordeaux Red leather interior. Zero track use, dealer serviced, comprehensive Porsche Approved Certified warranty through 2030.",
      gradientColors = listOf(0xFF2D3748, 0xFF1A202C)
    ),
    Car(
      id = "car_2",
      brand = "BMW",
      model = "M4 Competition xDrive",
      year = 2024,
      trim = "Coupe M Carbon Edition",
      price = 83900.0,
      originalPrice = 93400.0,
      isHotDeal = true,
      dealBadge = "Deal: $9,500 Off MSRP",
      bodyType = "Coupe",
      condition = "Brand New",
      mileage = 15,
      fuelType = "3.0L BMW M TwinPower Turbo",
      transmission = "8-Speed M Steptronic with Drivelogic",
      drivetrain = "AWD",
      horsepower = 503,
      zeroToSixty = 3.4,
      topSpeed = 180,
      rangeOrMpg = "19 MPG combined",
      exteriorColor = "Frozen Portimao Blue Metallic",
      interiorColor = "Kyalami Orange / Black Extended Merino",
      rating = 4.8,
      reviewCount = 57,
      dealerName = "BMW of Manhattan Luxury Studio",
      dealerLocation = "New York, NY",
      dealerPhone = "(212) 555-0144",
      features = listOf(
        "M Carbon Bucket Seats",
        "M Carbon Exterior Package & Diffuser",
        "Curved Display with iDrive 8.5",
        "Harman Kardon Surround Sound System",
        "Icon Adaptive LED Headlights with Laserlight",
        "M Drive Professional with Track Mode"
      ),
      description = "Brand new 2024 BMW M4 Competition Coupe in striking Frozen Portimao Blue. Featuring M xDrive intelligent all-wheel drive, M carbon ceramic brakes prep, and full M carbon styling. Manufacturer incentive applied.",
      gradientColors = listOf(0xFF1E3A8A, 0xFF0F172A)
    ),
    Car(
      id = "car_3",
      brand = "Tesla",
      model = "Model S Plaid",
      year = 2024,
      trim = "Tri-Motor AWD Track Package",
      price = 84990.0,
      originalPrice = 94990.0,
      isHotDeal = true,
      dealBadge = "Flash Deal: $10,000 Price Drop",
      bodyType = "Electric",
      condition = "Brand New",
      mileage = 8,
      fuelType = "Electric",
      transmission = "Direct Drive Single-Speed",
      drivetrain = "Tri-Motor e-AWD",
      horsepower = 1020,
      zeroToSixty = 1.99,
      topSpeed = 200,
      rangeOrMpg = "359 mi range",
      exteriorColor = "Solid Black Metallic",
      interiorColor = "All-White Premium Interior with Carbon",
      rating = 4.9,
      reviewCount = 89,
      dealerName = "Tesla Fremont Direct Experience",
      dealerLocation = "Fremont, CA",
      dealerPhone = "(888) 555-0182",
      features = listOf(
        "Full Self-Driving Capability Package",
        "Tri-Motor 1020 HP Torque Vectoring",
        "Yoke Steering Wheel & Center 17-inch Tilt Display",
        "22-Speaker 960W Audio with Active Noise Reduction",
        "Rear Passenger 8-inch Gaming Display",
        "Carbon-Fiber Spoilers and 21-inch Arachnid Wheels"
      ),
      description = "The quickest accelerating production car in the world. 0-60 in under 2.0 seconds with tri-motor torque vectoring. Includes Full Self-Driving hardware 4.0, zero emissions, and complimentary Supercharging bundle.",
      gradientColors = listOf(0xFFB91C1C, 0xFF450A0A)
    ),
    Car(
      id = "car_4",
      brand = "Mercedes-Benz",
      model = "AMG G 63",
      year = 2023,
      trim = "MANUFAKTUR Edition",
      price = 189500.0,
      originalPrice = null,
      isHotDeal = false,
      dealBadge = null,
      bodyType = "SUV",
      condition = "Certified Pre-Owned",
      mileage = 4320,
      fuelType = "Handcrafted AMG 4.0L V8 Biturbo",
      transmission = "AMG SPEEDSHIFT TCT 9-Speed",
      drivetrain = "AWD (3 Differential Locks)",
      horsepower = 577,
      zeroToSixty = 4.5,
      topSpeed = 149,
      rangeOrMpg = "14 MPG combined",
      exteriorColor = "Night Black Magno (Matte)",
      interiorColor = "Bengal Red / Black Exclusive Nappa",
      rating = 4.9,
      reviewCount = 31,
      dealerName = "Mercedes-Benz of Miami",
      dealerLocation = "Miami, FL",
      dealerPhone = "(305) 555-0168",
      features = listOf(
        "AMG Night Package Magno",
        "Exclusive Interior Package Plus",
        "22-inch AMG Forged Matte Black Wheels",
        "Burmester Surround Sound System",
        "Triple 100% Differential Locks",
        "AMG Performance Exhaust with Dual Side Pipes"
      ),
      description = "The pinnacle of off-road luxury and brute performance. Handcrafted AMG V8 with throaty side-exit exhausts, finished in factory matte Night Black Magno. Flawless condition, verified service history.",
      gradientColors = listOf(0xFF334155, 0xFF0F172A)
    ),
    Car(
      id = "car_5",
      brand = "Audi",
      model = "RS 6 Avant",
      year = 2024,
      trim = "Performance Edition",
      price = 119800.0,
      originalPrice = 129000.0,
      isHotDeal = true,
      dealBadge = "Manager Special: Save $9,200",
      bodyType = "Sedan",
      condition = "Brand New",
      mileage = 22,
      fuelType = "4.0L Twin-Turbo V8 + Mild Hybrid",
      transmission = "8-Speed Tiptronic Automatic",
      drivetrain = "quattro AWD with Sport Differential",
      horsepower = 621,
      zeroToSixty = 3.3,
      topSpeed = 190,
      rangeOrMpg = "17 MPG combined",
      exteriorColor = "Nardo Gray",
      interiorColor = "Valcona Leather with Mercato Blue Stitching",
      rating = 5.0,
      reviewCount = 48,
      dealerName = "Audi Scottsdale Flagship",
      dealerLocation = "Scottsdale, AZ",
      dealerPhone = "(480) 555-0125",
      features = listOf(
        "RS Dynamic Package Plus with Ceramic Brakes",
        "Bang & Olufsen Advanced 3D Sound (1,820W)",
        "Carbon Optic Exterior Trim Package",
        "HD Matrix LED Headlights with Audi Laser Light",
        "Dynamic All-Wheel Steering",
        "Sport Exhaust with Black Oval Tips"
      ),
      description = "The ultimate supercar wagon. The RS 6 Avant Performance increases horsepower to 621 hp with larger turbos and lighter insulation. Unmatched versatility combined with supercar acceleration.",
      gradientColors = listOf(0xFF475569, 0xFF1E293B)
    ),
    Car(
      id = "car_6",
      brand = "Ford",
      model = "Mustang Dark Horse",
      year = 2024,
      trim = "Handling Package 700A",
      price = 61990.0,
      originalPrice = 67500.0,
      isHotDeal = true,
      dealBadge = "Summer Deal: $5,510 Rebate",
      bodyType = "Coupe",
      condition = "Brand New",
      mileage = 12,
      fuelType = "5.0L Gen-4 Coyote V8",
      transmission = "TREMEC 6-Speed Manual with Rev Matching",
      drivetrain = "RWD",
      horsepower = 500,
      zeroToSixty = 3.7,
      topSpeed = 168,
      rangeOrMpg = "17 MPG combined",
      exteriorColor = "Blue Ember Metallic",
      interiorColor = "Deep Indigo Blue Suede / Leather",
      rating = 4.7,
      reviewCount = 64,
      dealerName = "Metro Ford Performance Center",
      dealerLocation = "Dallas, TX",
      dealerPhone = "(214) 555-0177",
      features = listOf(
        "TREMEC TR-3160 6-Speed Manual Transmission",
        "MagneRide Damping System with Track Calibration",
        "Brembo 6-Piston Front Brakes with Notched Rotors",
        "Titanium Anodized Blue Shift Ball",
        "K-Brace and Torsen Differential (3.73 ratio)",
        "Active Valve Performance Dual Exhaust"
      ),
      description = "Pure naturally aspirated American muscle. 500 horsepower Coyote V8 mated to a slick TREMEC 6-speed manual gearbox. Includes the Track Handling Package with wider Michelin Pilot Sport Cup 2 tires.",
      gradientColors = listOf(0xFF0369A1, 0xFF082F49)
    ),
    Car(
      id = "car_7",
      brand = "Ferrari",
      model = "296 GTB",
      year = 2023,
      trim = "Assetto Fiorano Package",
      price = 338000.0,
      originalPrice = 365000.0,
      isHotDeal = true,
      dealBadge = "Consignment Price Reduction $27,000",
      bodyType = "Sports",
      condition = "Certified Pre-Owned",
      mileage = 1100,
      fuelType = "3.0L Twin-Turbo 120° V6 Hybrid",
      transmission = "8-Speed Dual-Clutch F1",
      drivetrain = "RWD",
      horsepower = 819,
      zeroToSixty = 2.9,
      topSpeed = 205,
      rangeOrMpg = "15 mi EV / 20 MPG combined",
      exteriorColor = "Rosso Corsa with Bianco livery",
      interiorColor = "Nero Leather with Carbon Fiber Racing Seats",
      rating = 5.0,
      reviewCount = 19,
      dealerName = "Ferrari Silicon Valley",
      dealerLocation = "Redwood City, CA",
      dealerPhone = "(650) 555-0190",
      features = listOf(
        "Assetto Fiorano Track Package with Multimatic Shocks",
        "Carbon Fiber Front Flaps and Rear Active Spoiler",
        "Passenger Display with G-Force & Telemetry",
        "JBL Professional Audio System",
        "Carbon Fiber Steering Wheel with LED Shift Lights",
        "Factory 7-Year Genuine Maintenance Program"
      ),
      description = "The new era of Maranello performance. Combines a screaming 120° twin-turbo V6 with plug-in hybrid electric motor for an astounding 819 horsepower. Equipped with the lightweight Assetto Fiorano pack.",
      gradientColors = listOf(0xFFDC2626, 0xFF7F1D1D)
    ),
    Car(
      id = "car_8",
      brand = "Toyota",
      model = "GR Supra 3.0 Premium",
      year = 2024,
      trim = "6-Speed Manual Edition",
      price = 56500.0,
      originalPrice = 61200.0,
      isHotDeal = true,
      dealBadge = "Save $4,700 • Factory Clearance",
      bodyType = "Coupe",
      condition = "Brand New",
      mileage = 18,
      fuelType = "3.0L Twin-Scroll Turbo Inline-6",
      transmission = "Intelligent 6-Speed Manual (iMT)",
      drivetrain = "RWD",
      horsepower = 382,
      zeroToSixty = 3.9,
      topSpeed = 155,
      rangeOrMpg = "24 MPG combined",
      exteriorColor = "Stratosphere Blue",
      interiorColor = "Tan Leather Sport Seats",
      rating = 4.8,
      reviewCount = 73,
      dealerName = "Longo Toyota GR Garage",
      dealerLocation = "El Monte, CA",
      dealerPhone = "(626) 555-0133",
      features = listOf(
        "iMT Intelligent Manual Transmission with Auto-Blip",
        "Active Rear Differential & Adaptive Variable Suspension",
        "12-Speaker JBL HiFi Audio System",
        "Head-Up Display with Navigation Sync",
        "19-inch Forged Aluminum Frozen Gunmetal Wheels",
        "Brembo 4-Piston Ventilated Front Disc Brakes"
      ),
      description = "The purist's driver car. Turbocharged inline-6 powerhouse paired with an exhilarating 6-speed manual transmission tuned specifically for driving enthusiasts. Brand new with complimentary 1-year NASA membership.",
      gradientColors = listOf(0xFF0284C7, 0xFF0369A1)
    ),
    Car(
      id = "car_9",
      brand = "Mercedes-Benz",
      model = "EQS 580 4MATIC Sedan",
      year = 2024,
      trim = "Pinnacle Trim with Hyperscreen",
      price = 104500.0,
      originalPrice = 126900.0,
      isHotDeal = true,
      dealBadge = "Massive Deal: $22,400 Total Credit",
      bodyType = "Electric",
      condition = "Brand New",
      mileage = 35,
      fuelType = "Dual Permanent Magnet Electric Motors",
      transmission = "Single-Speed Automatic",
      drivetrain = "e-AWD",
      horsepower = 516,
      zeroToSixty = 4.1,
      topSpeed = 130,
      rangeOrMpg = "345 mi range",
      exteriorColor = "Obsidian Black Metallic",
      interiorColor = "Neva Grey / Balao Brown Nappa Leather",
      rating = 4.6,
      reviewCount = 38,
      dealerName = "Mercedes-Benz of Chicago",
      dealerLocation = "Chicago, IL",
      dealerPhone = "(312) 555-0155",
      features = listOf(
        "56-inch MBUX Hyperscreen Glass Cockpit",
        "Burmester 3D Surround Sound with Dolby Atmos",
        "Rear-Axle Steering (Up to 10 degrees)",
        "Executive Rear Seating with Massage & Tablets",
        "Airmatic Air Suspension with Adaptive Damping",
        "Two Years Complimentary Electrify America Charging"
      ),
      description = "Electric flagship luxury reimagined. Revolutionary 56-inch curved glass Hyperscreen, whisper-quiet cabin acoustics, and 345 miles of range. Unprecedented dealer and manufacturer EV incentive applied.",
      gradientColors = listOf(0xFF1E293B, 0xFF0B132B)
    ),
    Car(
      id = "car_10",
      brand = "Chevrolet",
      model = "Corvette Z06",
      year = 2024,
      trim = "3LZ Convertible Z07 Package",
      price = 134900.0,
      originalPrice = 142000.0,
      isHotDeal = true,
      dealBadge = "Dealer Discount: Save $7,100",
      bodyType = "Convertible",
      condition = "Brand New",
      mileage = 9,
      fuelType = "5.5L Flat-Plane Crank LT6 V8",
      transmission = "8-Speed Dual-Clutch Tremec",
      drivetrain = "RWD",
      horsepower = 670,
      zeroToSixty = 2.6,
      topSpeed = 195,
      rangeOrMpg = "15 MPG combined",
      exteriorColor = "Torch Red",
      interiorColor = "Adrenaline Red / Jet Black Nappa Leather",
      rating = 4.9,
      reviewCount = 52,
      dealerName = "Classic Chevrolet Performance",
      dealerLocation = "Grapevine, TX",
      dealerPhone = "(817) 555-0160",
      features = listOf(
        "8,600 RPM Flat-Plane Crank Naturally Aspirated V8",
        "Z07 Performance Package with Carbon Aero",
        "Brembo Carbon Ceramic Brakes",
        "Bose Performance Series 14-Speaker Audio",
        "Power Retractable Hardtop in 16 seconds",
        "Performance Data Recorder with 1080p Telemetry"
      ),
      description = "The highest horsepower naturally aspirated production V8 in automotive history. Screams all the way to an 8,600 RPM redline. Equipped with Z07 aero pack, carbon ceramic brakes, and drop-top convertible theater.",
      gradientColors = listOf(0xFFB91C1C, 0xFF18181B)
    ),
    Car(
      id = "car_11",
      brand = "BMW",
      model = "X5 M Competition",
      year = 2024,
      trim = "M Sport Ultimate Edition",
      price = 118400.0,
      originalPrice = 127800.0,
      isHotDeal = true,
      dealBadge = "Holiday Deal: $9,400 Off",
      bodyType = "SUV",
      condition = "Brand New",
      mileage = 14,
      fuelType = "4.4L Twin-Turbo V8 + 48V Mild Hybrid",
      transmission = "8-Speed M Steptronic",
      drivetrain = "M xDrive AWD",
      horsepower = 617,
      zeroToSixty = 3.7,
      topSpeed = 177,
      rangeOrMpg = "16 MPG combined",
      exteriorColor = "Isle of Man Green Metallic",
      interiorColor = "Silverstone / Black Full Merino Leather",
      rating = 4.8,
      reviewCount = 41,
      dealerName = "BMW of Austin Premier",
      dealerLocation = "Austin, TX",
      dealerPhone = "(512) 555-0188",
      features = listOf(
        "M Sport Exhaust with Quad 100mm Tailpipes",
        "Active Roll Stabilization & M Adaptive Suspension",
        "Bowers & Wilkins Diamond Surround Sound (1,500W)",
        "Panoramic Sky Lounge LED Roof",
        "Heated & Cooled Cupholders + Massage Seats",
        "M Carbon Mirror Caps & Engine Cover"
      ),
      description = "Supercar velocity disguised as a family SUV. 617 horsepower, twin-turbo electrified V8, and razor-sharp M chassis engineering with luxurious five-passenger seating and immense cargo room.",
      gradientColors = listOf(0xFF065F46, 0xFF064E3B)
    ),
    Car(
      id = "car_12",
      brand = "Porsche",
      model = "Taycan Turbo S Cross Turismo",
      year = 2023,
      trim = "Offroad Design Package",
      price = 168900.0,
      originalPrice = 197500.0,
      isHotDeal = true,
      dealBadge = "Executive Certified: Save $28,600",
      bodyType = "Electric",
      condition = "Certified Pre-Owned",
      mileage = 3900,
      fuelType = "Dual Permanent Magnet Electric Motors",
      transmission = "2-Speed Rear / 1-Speed Front Automatic",
      drivetrain = "AWD",
      horsepower = 750,
      zeroToSixty = 2.7,
      topSpeed = 155,
      rangeOrMpg = "222 mi range / 800V Ultra-Fast Charging",
      exteriorColor = "Neptune Blue",
      interiorColor = "Atacama Beige / Basalt Black Olea Club Leather",
      rating = 4.9,
      reviewCount = 27,
      dealerName = "Porsche San Diego",
      dealerLocation = "San Diego, CA",
      dealerPhone = "(858) 555-0122",
      features = listOf(
        "Overboost Power with Launch Control (750 hp)",
        "Porsche Ceramic Composite Brakes (PCCB)",
        "Adaptive Air Suspension with Smart Lift & Gravel Mode",
        "Burmester 3D High-End Audio System",
        "Rear-Axle Steering with Power Steering Plus",
        "Fixed Panoramic Glass Roof with Variable Light Control"
      ),
      description = "Electric adventure wagon engineered with race-proven 800-volt architecture. Accelerates to 60 mph in 2.7 seconds while offering gravel mode clearance and elevated utility.",
      gradientColors = listOf(0xFF0369A1, 0xFF1E293B)
    )
  )

  val allBrands: List<String> = listOf(
    "All",
    "Porsche",
    "BMW",
    "Mercedes-Benz",
    "Tesla",
    "Audi",
    "Ford",
    "Ferrari",
    "Toyota",
    "Chevrolet"
  )

  val bodyTypes: List<String> = listOf("All", "Coupe", "Sedan", "SUV", "Electric", "Sports", "Convertible")
  val conditions: List<String> = listOf("All", "Brand New", "Certified Pre-Owned", "Pre-Owned")
  val fuelTypes: List<String> = listOf("All", "Electric", "Twin-Turbo V8", "Twin-Turbo Flat-6", "Hybrid", "Petrol")

  fun toggleFavorite(carId: String) {
    _favoriteIds.update { current ->
      if (current.contains(carId)) current - carId else current + carId
    }
  }

  fun toggleComparison(carId: String): Boolean {
    var added = false
    _comparisonIds.update { current ->
      if (current.contains(carId)) {
        current - carId
      } else {
        if (current.size >= 2) {
          // Replace second car
          val first = current.first()
          added = true
          setOf(first, carId)
        } else {
          added = true
          current + carId
        }
      }
    }
    return added
  }

  fun removeComparison(carId: String) {
    _comparisonIds.update { it - carId }
  }

  fun clearComparison() {
    _comparisonIds.value = emptySet()
  }

  fun bookTestDrive(booking: TestDriveBooking) {
    _testDrives.update { listOf(booking) + it }
  }

  fun submitOffer(offer: OfferInquiry) {
    _offers.update { listOf(offer) + it }
  }

  fun filterCars(cars: List<Car>, filters: CarFilterState): List<Car> {
    return cars.filter { car ->
      // Brand filter
      val matchesBrand = if (filters.selectedBrands.isEmpty() || filters.selectedBrands.contains("All")) {
        true
      } else {
        filters.selectedBrands.contains(car.brand)
      }

      // Deals only filter
      val matchesDeals = if (filters.onlyDeals) car.isHotDeal else true

      // Price filter
      val matchesPrice = car.price >= filters.minPrice && car.price <= filters.maxPrice

      // Body Type filter
      val matchesBodyType = if (filters.selectedBodyTypes.isEmpty() || filters.selectedBodyTypes.contains("All")) {
        true
      } else {
        filters.selectedBodyTypes.contains(car.bodyType)
      }

      // Condition filter
      val matchesCondition = if (filters.selectedConditions.isEmpty() || filters.selectedConditions.contains("All")) {
        true
      } else {
        filters.selectedConditions.contains(car.condition)
      }

      // Fuel Type filter
      val matchesFuel = if (filters.selectedFuelTypes.isEmpty() || filters.selectedFuelTypes.contains("All")) {
        true
      } else {
        filters.selectedFuelTypes.any { car.fuelType.contains(it, ignoreCase = true) }
      }

      // Search query
      val matchesSearch = if (filters.searchQuery.isBlank()) {
        true
      } else {
        val q = filters.searchQuery.trim().lowercase()
        car.brand.lowercase().contains(q) ||
            car.model.lowercase().contains(q) ||
            car.trim.lowercase().contains(q) ||
            car.bodyType.lowercase().contains(q) ||
            car.features.any { it.lowercase().contains(q) } ||
            car.description.lowercase().contains(q)
      }

      matchesBrand && matchesDeals && matchesPrice && matchesBodyType && matchesCondition && matchesFuel && matchesSearch
    }.let { list ->
      // Sort
      when (filters.sortBy) {
        SortOption.FEATURED -> list
        SortOption.PRICE_LOW_HIGH -> list.sortedBy { it.price }
        SortOption.PRICE_HIGH_LOW -> list.sortedByDescending { it.price }
        SortOption.BEST_DEALS -> list.sortedByDescending { it.discountAmount }
        SortOption.NEWEST -> list.sortedByDescending { it.year }
        SortOption.LOWEST_MILEAGE -> list.sortedBy { it.mileage }
      }
    }
  }
}
