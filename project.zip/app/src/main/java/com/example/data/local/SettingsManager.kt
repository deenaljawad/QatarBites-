package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class AppSettings(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val isPinProtectionEnabled: Boolean = false,
    val hasPinSet: Boolean = false
)

class SettingsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("passforge_prefs", Context.MODE_PRIVATE)

    private val _settingsState = MutableStateFlow(readCurrentSettings())
    val settingsState: StateFlow<AppSettings> = _settingsState.asStateFlow()

    private fun readCurrentSettings(): AppSettings {
        val themeStr = prefs.getString(KEY_THEME_MODE, AppThemeMode.SYSTEM.name) ?: AppThemeMode.SYSTEM.name
        val themeMode = try {
            AppThemeMode.valueOf(themeStr)
        } catch (_: Exception) {
            AppThemeMode.SYSTEM
        }
        val isPinEnabled = prefs.getBoolean(KEY_PIN_ENABLED, false)
        val pinHash = prefs.getString(KEY_PIN_HASH, null)
        val hasPin = !pinHash.isNullOrEmpty()

        return AppSettings(
            themeMode = themeMode,
            isPinProtectionEnabled = isPinEnabled && hasPin,
            hasPinSet = hasPin
        )
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _settingsState.value = _settingsState.value.copy(themeMode = mode)
    }

    fun setPin(pin: String): Boolean {
        if (pin.length < 4) return false
        val hash = hashPin(pin)
        prefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_PIN_ENABLED, true)
            .apply()
        _settingsState.value = _settingsState.value.copy(
            isPinProtectionEnabled = true,
            hasPinSet = true
        )
        return true
    }

    fun verifyPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return storedHash == hashPin(pin)
    }

    fun setPinProtectionEnabled(enabled: Boolean): Boolean {
        if (enabled && !_settingsState.value.hasPinSet) {
            return false // Cannot enable without setting PIN first
        }
        prefs.edit().putBoolean(KEY_PIN_ENABLED, enabled).apply()
        _settingsState.value = _settingsState.value.copy(isPinProtectionEnabled = enabled)
        return true
    }

    fun clearPin() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .putBoolean(KEY_PIN_ENABLED, false)
            .apply()
        _settingsState.value = _settingsState.value.copy(
            isPinProtectionEnabled = false,
            hasPinSet = false
        )
    }

    private fun hashPin(pin: String): String {
        val salt = "passforge_salt_secure_2026"
        val bytes = MessageDigest.getInstance("SHA-256").digest((pin + salt).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_THEME_MODE = "key_theme_mode"
        private const val KEY_PIN_ENABLED = "key_pin_enabled"
        private const val KEY_PIN_HASH = "key_pin_hash"
    }
}
