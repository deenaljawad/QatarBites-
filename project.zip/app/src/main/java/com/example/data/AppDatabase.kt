package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.models.Booking
import com.example.data.models.BookingStatus
import com.example.data.models.PaymentStatus
import com.example.data.models.ScamReport
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import com.example.data.models.UrgencyLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TechService::class, Booking::class, ScamReport::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun serviceDao(): ServiceDao
    abstract fun bookingDao(): BookingDao
    abstract fun scamReportDao(): ScamReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "techhelp4u_database.db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: AppDatabase) {
            val serviceDao = database.serviceDao()
            val bookingDao = database.bookingDao()
            val scamDao = database.scamReportDao()

            val defaultServices = listOf(
                // Virtual
                TechService(
                    id = "v_malware",
                    title = "Remote Virus & Spyware Removal",
                    category = ServiceCategory.VIRTUAL,
                    tagline = "Clean infected systems remotely",
                    description = "Comprehensive remote diagnostic, rootkit/trojan elimination, browser hijacker removal, and enterprise-grade antivirus configuration.",
                    price = 49.00,
                    durationMinutes = 45,
                    isEmergency = false,
                    features = "Full rootkit scan|Browser cleanup|Adware removal|Real-time defender setup",
                    iconType = "malware"
                ),
                TechService(
                    id = "v_tuneup",
                    title = "PC & Mac Speed Tune-Up",
                    category = ServiceCategory.VIRTUAL,
                    tagline = "Make your slow computer fast again",
                    description = "Clear bloatware, disable heavy startup services, optimize registry, disk defrag, and clean cache files.",
                    price = 39.00,
                    durationMinutes = 35,
                    isEmergency = false,
                    features = "Startup app trim|Disk cleanup|RAM memory boost|Temperature check",
                    iconType = "speed"
                ),
                TechService(
                    id = "v_network",
                    title = "Remote Wi-Fi & Network Fix",
                    category = ServiceCategory.VIRTUAL,
                    tagline = "Fix slow internet & disconnects",
                    description = "Remote router config, DNS acceleration, Wi-Fi channel optimization, VPN troubleshooting, and network printer reconnect.",
                    price = 45.00,
                    durationMinutes = 40,
                    isEmergency = false,
                    features = "Router security check|DNS switch|Printer network share|VPN fix",
                    iconType = "wifi"
                ),
                TechService(
                    id = "v_email",
                    title = "Cloud & Email Sync Setup",
                    category = ServiceCategory.VIRTUAL,
                    tagline = "Sync Outlook, Gmail & iCloud everywhere",
                    description = "Configure email clients, migrate mailbox data, solve sync errors, setup IMAP/Exchange, and enforce two-factor authentication.",
                    price = 35.00,
                    durationMinutes = 30,
                    isEmergency = false,
                    features = "Outlook & Gmail setup|2-Factor auth|Spam rule config|Backup sync",
                    iconType = "email"
                ),

                // Physical
                TechService(
                    id = "p_screen",
                    title = "Screen & Display Replacement",
                    category = ServiceCategory.PHYSICAL,
                    tagline = "Cracked screen & glass repair",
                    description = "Certified hardware repair for cracked laptop screens, touch monitors, and tablet displays. OEM grade panels with warranty.",
                    price = 89.00,
                    durationMinutes = 90,
                    isEmergency = false,
                    features = "OEM replacement panel|Hinge alignment|Dead pixel zero-check|90-day parts warranty",
                    iconType = "screen"
                ),
                TechService(
                    id = "p_battery",
                    title = "Battery & Power Port Repair",
                    category = ServiceCategory.PHYSICAL,
                    tagline = "Fix charging & dying batteries",
                    description = "Replace degraded batteries, fix loose charging jacks / USB-C ports, and inspect power motherboard circuits.",
                    price = 65.00,
                    durationMinutes = 60,
                    isEmergency = false,
                    features = "Grade-A fresh cell|USB-C solder check|Heat test|Safe battery disposal",
                    iconType = "battery"
                ),
                TechService(
                    id = "p_hardware",
                    title = "Fast NVMe SSD Upgrade & Clone",
                    category = ServiceCategory.PHYSICAL,
                    tagline = "10x speed boost with cloned OS",
                    description = "Upgrade slow hard drive to lightning-fast NVMe/SATA SSD. Full clone preserving all your programs, games, files, and settings.",
                    price = 79.00,
                    durationMinutes = 75,
                    isEmergency = false,
                    features = "Exact 1:1 drive clone|Zero data loss|Drive health report|Thermal pad install",
                    iconType = "hardware"
                ),
                TechService(
                    id = "p_onsite",
                    title = "On-Site Home / Office Tech Visit",
                    category = ServiceCategory.PHYSICAL,
                    tagline = "Technician comes directly to you",
                    description = "In-person technician visits your home or office. Cable management, smart TV setup, mesh Wi-Fi installation, and workstation setup.",
                    price = 99.00,
                    durationMinutes = 120,
                    isEmergency = false,
                    features = "Home/Office visit|Mesh Wi-Fi layout|Smart device setup|Workstation ergonomics",
                    iconType = "onsite"
                ),

                // Scamming & Spamming
                TechService(
                    id = "s_emergency",
                    title = "Emergency Scam & Remote Lockout",
                    category = ServiceCategory.SCAM_SPAM,
                    tagline = "URGENT: Scammer has access or money taken",
                    description = "Immediate emergency intervention: Kill malicious remote software (AnyDesk, TeamViewer, UltraViewer), disconnect scammer session, assist bank account freeze, and collect forensic evidence.",
                    price = 59.00,
                    durationMinutes = 30,
                    isEmergency = true,
                    features = "Immediate remote session kill|Bank fraud guide|Malicious file purge|FTC report documentation",
                    iconType = "scam"
                ),
                TechService(
                    id = "s_phishing",
                    title = "Phishing & Fake Message Audit",
                    category = ServiceCategory.SCAM_SPAM,
                    tagline = "Inspect suspicious link, SMS or invoice",
                    description = "Full analysis of suspicious messages, spoofed sender headers, fraudulent Geek Squad / Norton invoices, and compromised credentials.",
                    price = 29.00,
                    durationMinutes = 20,
                    isEmergency = false,
                    features = "Header inspection|Domain reputation test|Credential leak check|Safe-practice briefing",
                    iconType = "phishing"
                ),
                TechService(
                    id = "s_antispam",
                    title = "Anti-Spam & Robo-Call Shield",
                    category = ServiceCategory.SCAM_SPAM,
                    tagline = "Silence spam calls & junk text messages",
                    description = "Setup carrier-level spam blocking, activate STIR/SHAKEN filtering, configure SMS spam filters, and register on National Do Not Call.",
                    price = 39.00,
                    durationMinutes = 35,
                    isEmergency = false,
                    features = "Robocall filter setup|SMS keyword blocker|Do Not Call register|Spam whitelist tuning",
                    iconType = "spam_shield"
                ),
                TechService(
                    id = "s_identity",
                    title = "Full Identity Theft Recovery Plan",
                    category = ServiceCategory.SCAM_SPAM,
                    tagline = "Secure compromised accounts & identity",
                    description = "Step-by-step identity reclamation: Equifax/Experian/TransUnion credit freezes, password manager rollout, dark web scans, and security key setup.",
                    price = 75.00,
                    durationMinutes = 60,
                    isEmergency = false,
                    features = "Credit bureau freeze|Password manager setup|Dark web breach check|Recovery checklist PDF",
                    iconType = "identity"
                )
            )
            serviceDao.insertAll(defaultServices)

            val now = System.currentTimeMillis()
            val sampleBookings = listOf(
                Booking(
                    id = "TH-94182",
                    serviceId = "s_emergency",
                    serviceTitle = "Emergency Scam & Remote Lockout",
                    category = ServiceCategory.SCAM_SPAM,
                    customerName = "Robert Henderson",
                    customerEmail = "robert.h@example.com",
                    customerPhone = "+1 (555) 349-1102",
                    appointmentDate = "Today",
                    appointmentTimeSlot = "Immediate Priority",
                    serviceModeDetail = "Scammer called pretending to be Amazon refund dept. Installed AnyDesk.",
                    issueDescription = "Caller asked to buy Apple gift cards. Mouse was moving on screen. Disconnected Wi-Fi immediately.",
                    urgencyLevel = UrgencyLevel.CRITICAL_EMERGENCY,
                    assignedTechnician = "Alex Rivera (Lead Security)",
                    status = BookingStatus.IN_PROGRESS,
                    paymentStatus = PaymentStatus.PAID,
                    paymentMethod = "Credit Card (•••• 8821)",
                    amountPaid = 59.00,
                    transactionId = "TXN-SCAM-9941",
                    createdAtTimestamp = now - 3600000,
                    adminNotes = "AnyDesk session terminated. Customer contacted Chase Bank fraud line. Running malware cleanup."
                ),
                Booking(
                    id = "TH-72019",
                    serviceId = "v_malware",
                    serviceTitle = "Remote Virus & Spyware Removal",
                    category = ServiceCategory.VIRTUAL,
                    customerName = "Emily Watson",
                    customerEmail = "emily.watson@example.com",
                    customerPhone = "+1 (555) 782-9934",
                    appointmentDate = "Tomorrow",
                    appointmentTimeSlot = "10:00 AM - 11:00 AM",
                    serviceModeDetail = "Remote Desktop / Zoom: 839 201 4492",
                    issueDescription = "Browser keeps redirecting to search.yahoo-look.com and popups are appearing every 5 minutes.",
                    urgencyLevel = UrgencyLevel.HIGH,
                    assignedTechnician = "David Miller (Remote Specialist)",
                    status = BookingStatus.CONFIRMED,
                    paymentStatus = PaymentStatus.PAID,
                    paymentMethod = "Google Pay",
                    amountPaid = 49.00,
                    transactionId = "TXN-GPAY-7729",
                    createdAtTimestamp = now - 18000000,
                    adminNotes = "Sent prep link to customer. Technician queued."
                ),
                Booking(
                    id = "TH-61540",
                    serviceId = "p_hardware",
                    serviceTitle = "Fast NVMe SSD Upgrade & Clone",
                    category = ServiceCategory.PHYSICAL,
                    customerName = "Marcus Vance",
                    customerEmail = "mvance99@example.com",
                    customerPhone = "+1 (555) 441-2309",
                    appointmentDate = "Yesterday",
                    appointmentTimeSlot = "2:00 PM - 3:30 PM",
                    serviceModeDetail = "On-site: 742 Evergreen Terrace, Springfield",
                    issueDescription = "Dell Inspiron laptop taking 8 minutes to boot. Upgrading from 1TB mechanical drive to 1TB Samsung 980 NVMe SSD.",
                    urgencyLevel = UrgencyLevel.NORMAL,
                    assignedTechnician = "Sarah Chen (Hardware Lead)",
                    status = BookingStatus.COMPLETED,
                    paymentStatus = PaymentStatus.PAID,
                    paymentMethod = "Credit Card (•••• 4242)",
                    amountPaid = 79.00,
                    transactionId = "TXN-STRIPE-4412",
                    createdAtTimestamp = now - 86400000,
                    adminNotes = "Clone completed successfully. Boot time reduced from 8 min to 14 seconds. Customer thrilled."
                )
            )
            sampleBookings.forEach { bookingDao.insertBooking(it) }

            val sampleScamReports = listOf(
                ScamReport(
                    id = "SR-102",
                    reporterName = "Eleanor Rigby",
                    contactPhone = "+1 (555) 601-9231",
                    scamType = "Fake Geek Squad Auto-Renewal Email",
                    details = "Received email claiming $499 was debited for renewal. Call center told her to download UltraViewer to get refund.",
                    financialLossReported = false,
                    lossAmount = 0.0,
                    urgency = UrgencyLevel.HIGH,
                    status = "Blocked & Documented",
                    timestamp = now - 7200000
                ),
                ScamReport(
                    id = "SR-101",
                    reporterName = "David Garcia",
                    contactPhone = "+1 (555) 819-2034",
                    scamType = "Impersonation / IRS Threat",
                    details = "Robo-call claiming arrest warrant unless $1,000 in Target cards purchased. Caller hung up when questioned.",
                    financialLossReported = false,
                    lossAmount = 0.0,
                    urgency = UrgencyLevel.NORMAL,
                    status = "Reported to FTC",
                    timestamp = now - 172800000
                )
            )
            sampleScamReports.forEach { scamDao.insertReport(it) }
        }
    }
}
