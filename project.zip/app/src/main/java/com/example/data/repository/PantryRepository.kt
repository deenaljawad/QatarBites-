package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.PantryItem
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class PantryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    fun observePantryItems(): Flow<List<PantryItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/pantryItems"
        emitAll(
            db.collection("users").document(uid).collection("pantryItems")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(PantryItem::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun addPantryItem(name: String, category: String, quantity: String, expiryDate: String = "") {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("pantryItems")
        val data = hashMapOf<String, Any>(
            "name" to name.trim(),
            "category" to category.trim(),
            "quantity" to quantity.trim(),
            "expiryDate" to expiryDate.trim(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            colRef.add(data).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, colRef.path)
            throw e
        }
    }

    suspend fun updatePantryItem(item: PantryItem) {
        val uid = requireUserId()
        require(item.id.isNotBlank()) { "Item ID cannot be blank for update" }
        requireNotNull(item.createdAt) { "Item createdAt must not be null for update" }
        val docRef = db.collection("users").document(uid).collection("pantryItems").document(item.id)
        try {
            docRef.set(item.copy(updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deletePantryItem(itemId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("pantryItems").document(itemId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun seedStarterPantry() {
        val starterItems = listOf(
            Triple("Olive Oil", "Pantry Staples", "500ml"),
            Triple("Garlic", "Produce", "1 bulb"),
            Triple("Yellow Onion", "Produce", "2 pcs"),
            Triple("Eggs", "Dairy & Eggs", "6 pcs"),
            Triple("Chicken Breast", "Proteins", "400g"),
            Triple("Jasmine Rice", "Grains & Pasta", "1 kg"),
            Triple("Penne Pasta", "Grains & Pasta", "500g"),
            Triple("Crushed Tomatoes", "Canned Goods", "1 can (400g)"),
            Triple("Butter", "Dairy & Eggs", "200g"),
            Triple("Black Pepper", "Spices & Seasoning", "1 container"),
            Triple("Sea Salt", "Spices & Seasoning", "1 container"),
            Triple("Soy Sauce", "Sauces & Condiments", "250ml")
        )
        for ((name, cat, qty) in starterItems) {
            addPantryItem(name, cat, qty)
        }
    }
}
