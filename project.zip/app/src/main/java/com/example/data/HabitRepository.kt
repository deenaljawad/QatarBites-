package com.example.data

import com.example.model.Badge
import com.example.model.BadgeCatalog
import com.example.model.GamificationManager
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class GamificationEventResult(
    val xpEarned: Int,
    val leveledUp: Boolean,
    val newLevel: Int,
    val newlyUnlockedBadges: List<Badge>
)

class HabitRepository(private val dao: HabitDao) {

    val allHabits: Flow<List<HabitEntity>> = dao.getAllActiveHabits()
    val userStats: Flow<UserStatsEntity?> = dao.getUserStats()

    fun getLogsForDate(dateString: String): Flow<List<HabitLogEntity>> =
        dao.getLogsForDate(dateString)

    fun getLogsForYear(yearPrefix: String): Flow<List<HabitLogEntity>> =
        dao.getLogsForYear(yearPrefix)

    suspend fun getHabitById(id: Long): HabitEntity? = dao.getHabitById(id)

    suspend fun insertHabit(habit: HabitEntity): Long {
        val currentHabits = dao.getAllActiveHabitsSync()
        val maxOrder = currentHabits.maxOfOrNull { it.orderIndex } ?: -1
        val habitWithOrder = if (habit.orderIndex == 0 && maxOrder >= 0) {
            habit.copy(orderIndex = maxOrder + 1)
        } else {
            habit
        }
        val id = dao.insertHabit(habitWithOrder)
        return id
    }

    suspend fun updateHabit(habit: HabitEntity) {
        dao.updateHabit(habit)
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        dao.deleteHabit(habit)
    }

    suspend fun moveHabit(habitId: Long, direction: Int) {
        val habits = dao.getAllActiveHabitsSync()
        val currentIndex = habits.indexOfFirst { it.id == habitId }
        if (currentIndex == -1) return
        val targetIndex = currentIndex + direction
        if (targetIndex !in habits.indices) return

        val mutable = habits.toMutableList()
        val item = mutable.removeAt(currentIndex)
        mutable.add(targetIndex, item)

        val updated = mutable.mapIndexed { idx, h ->
            h.copy(orderIndex = idx)
        }
        dao.updateHabits(updated)
    }

    suspend fun toggleHabitCompletion(
        habit: HabitEntity,
        dateString: String
    ): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val wasCompleted = existingLog?.isCompleted ?: false
        val willBeCompleted = !wasCompleted

        val updatedValue = if (willBeCompleted) habit.targetValue else 0.0

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = updatedValue,
            isCompleted = willBeCompleted,
            xpClaimed = willBeCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        val xpAmount = GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET

        if (willBeCompleted && !wasCompleted) {
            // Checked off: award XP
            return awardXpAndCheckBadges(xpAmount, habit, isCompletion = true)
        } else if (!willBeCompleted && wasCompleted) {
            // Unchecked: take back the XP it gave
            return deductXp(xpAmount)
        }

        return GamificationEventResult(0, false, 0, emptyList())
    }

    suspend fun incrementHabitProgress(
        habit: HabitEntity,
        dateString: String,
        delta: Double
    ): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val wasCompleted = existingLog?.isCompleted ?: false
        val currentValue = existingLog?.value ?: 0.0
        val newValue = (currentValue + delta).coerceAtLeast(0.0)
        val isCompleted = newValue >= habit.targetValue

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = newValue,
            isCompleted = isCompleted,
            xpClaimed = isCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        val xpAmount = GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET

        if (isCompleted && !wasCompleted) {
            return awardXpAndCheckBadges(xpAmount, habit, isCompletion = true)
        } else if (!isCompleted && wasCompleted) {
            return deductXp(xpAmount)
        }

        return GamificationEventResult(0, false, 0, emptyList())
    }

    suspend fun recordQuitSlip(habitId: Long) {
        val habit = dao.getHabitById(habitId) ?: return
        val updated = habit.copy(
            quitCleanStartTimestamp = System.currentTimeMillis(),
            quitTotalSlips = habit.quitTotalSlips + 1
        )
        dao.updateHabit(updated)
    }

    suspend fun checkCleanDay(habit: HabitEntity, dateString: String): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val wasCompleted = existingLog?.isCompleted ?: false
        val willBeCompleted = !wasCompleted

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = if (willBeCompleted) 1.0 else 0.0,
            isCompleted = willBeCompleted,
            xpClaimed = willBeCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        val xpAmount = GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET

        if (willBeCompleted && !wasCompleted) {
            // Checked clean: award XP
            return awardXpAndCheckBadges(xpAmount, habit, isCompletion = true)
        } else if (!willBeCompleted && wasCompleted) {
            // Unchecked: take back the XP it gave
            return deductXp(xpAmount)
        }
        return GamificationEventResult(0, false, 0, emptyList())
    }

    private suspend fun deductXp(xpToDeduct: Int): GamificationEventResult {
        var currentStats = dao.getUserStatsSync() ?: UserStatsEntity()
        val newTotalXp = (currentStats.xp - xpToDeduct).coerceAtLeast(0)
        val newLevelInfo = GamificationManager.getLevelInfo(newTotalXp)
        val newCompletions = (currentStats.totalCompletions - 1).coerceAtLeast(0)

        val updatedStats = currentStats.copy(
            xp = newTotalXp,
            level = newLevelInfo.currentLevel,
            totalCompletions = newCompletions
        )
        dao.upsertUserStats(updatedStats)

        return GamificationEventResult(
            xpEarned = -xpToDeduct,
            leveledUp = false,
            newLevel = newLevelInfo.currentLevel,
            newlyUnlockedBadges = emptyList()
        )
    }

    private suspend fun checkBadgesOnHabitCreated() {
        // Check Yin-Yang badge
        val habits = dao.getAllActiveHabits()
        // Collect synchronously by querying or checking
        // Let's do badge checks in awardXpAndCheckBadges
    }

    private suspend fun awardXpAndCheckBadges(
        xp: Int,
        habit: HabitEntity?,
        isCompletion: Boolean = false,
        isCraving: Boolean = false
    ): GamificationEventResult {
        var currentStats = dao.getUserStatsSync() ?: UserStatsEntity()
        val oldLevelInfo = GamificationManager.getLevelInfo(currentStats.xp)

        val newTotalXp = currentStats.xp + xp
        val newLevelInfo = GamificationManager.getLevelInfo(newTotalXp)
        val didLevelUp = newLevelInfo.currentLevel > oldLevelInfo.currentLevel

        val newCompletions = if (isCompletion) currentStats.totalCompletions + 1 else currentStats.totalCompletions

        // Calculate streaks & calendar stats
        val allCompleted = dao.getAllCompletedLogs()
        val uniqueDays = allCompleted.map { it.dateString }.distinct()

        // Today's completions count
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val todayCompletions = allCompleted.count { it.dateString == todayStr }

        // Max streak calculation
        val currentMaxStreak = calculateMaxStreak(uniqueDays)
        val longestStreak = maxOf(currentStats.longestStreakAllTime, currentMaxStreak)

        val unlockedBadges = currentStats.unlockedBadgeIds.toMutableList()
        val newlyAwarded = mutableListOf<Badge>()

        // Hour check for early bird / night owl
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)

        // Evaluate all catalog badges
        for (badge in BadgeCatalog.ALL_BADGES) {
            if (unlockedBadges.contains(badge.id)) continue

            var isEligible = false
            when (badge.id) {
                "first_step" -> if (newCompletions >= 1) isEligible = true
                "three_peat" -> if (todayCompletions >= 3) isEligible = true
                "streak_3" -> if (currentMaxStreak >= 3) isEligible = true
                "streak_7" -> if (currentMaxStreak >= 7) isEligible = true
                "streak_14" -> if (currentMaxStreak >= 14) isEligible = true
                "streak_30" -> if (currentMaxStreak >= 30) isEligible = true
                "craving_slayer" -> {
                    if (habit?.type == HabitType.BREAK) {
                        val cleanDays = (System.currentTimeMillis() - habit.quitCleanStartTimestamp) / (1000 * 60 * 60 * 24)
                        if (cleanDays >= 3) isEligible = true
                    }
                }
                "century_club" -> if (newCompletions >= 100) isEligible = true
                "level_5" -> if (newLevelInfo.currentLevel >= 5) isEligible = true
                "level_10" -> if (newLevelInfo.currentLevel >= 10) isEligible = true
                "early_bird" -> if (isCompletion && currentHour < 8) isEligible = true
                "night_sentinel" -> if (isCompletion && currentHour >= 21) isEligible = true
                "clean_7" -> {
                    if (habit?.type == HabitType.BREAK) {
                        val cleanDays = (System.currentTimeMillis() - habit.quitCleanStartTimestamp) / (1000 * 60 * 60 * 24)
                        if (cleanDays >= 7) isEligible = true
                    }
                }
            }

            if (isEligible) {
                unlockedBadges.add(badge.id)
                newlyAwarded.add(badge)
            }
        }

        val bonusBadgeXp = newlyAwarded.sumOf { it.xpReward }
        val finalXp = newTotalXp + bonusBadgeXp
        val finalLevelInfo = GamificationManager.getLevelInfo(finalXp)

        val updatedStats = currentStats.copy(
            xp = finalXp,
            level = finalLevelInfo.currentLevel,
            unlockedBadgeIds = unlockedBadges,
            totalCompletions = newCompletions,
            longestStreakAllTime = longestStreak,
            lastActiveDate = todayStr
        )
        dao.upsertUserStats(updatedStats)

        return GamificationEventResult(
            xpEarned = xp + bonusBadgeXp,
            leveledUp = didLevelUp || (finalLevelInfo.currentLevel > oldLevelInfo.currentLevel),
            newLevel = finalLevelInfo.currentLevel,
            newlyUnlockedBadges = newlyAwarded
        )
    }

    private fun calculateMaxStreak(uniqueDateStrings: List<String>): Int {
        if (uniqueDateStrings.isEmpty()) return 0
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sortedDates = uniqueDateStrings.mapNotNull {
            try { sdf.parse(it) } catch (_: Exception) { null }
        }.sorted()

        if (sortedDates.isEmpty()) return 0

        var maxStreak = 1
        var currentStreak = 1

        val oneDayMillis = 24 * 60 * 60 * 1000L

        for (i in 1 until sortedDates.size) {
            val diff = sortedDates[i].time - sortedDates[i - 1].time
            // Check if dates are consecutive (allowing timezone drift 20h - 28h)
            if (diff in (20 * 3600 * 1000L)..(28 * 3600 * 1000L)) {
                currentStreak++
                maxStreak = maxOf(maxStreak, currentStreak)
            } else if (diff > 28 * 3600 * 1000L) {
                currentStreak = 1
            }
        }
        return maxStreak
    }

    suspend fun seedSampleDataIfEmpty() {
        val existing = dao.getUserStatsSync()
        if (existing == null) {
            dao.upsertUserStats(
                UserStatsEntity(
                    id = 1,
                    xp = 0,
                    level = 1,
                    unlockedBadgeIds = emptyList(),
                    lastActiveDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                    cravingsResistedCount = 0,
                    totalCompletions = 0,
                    longestStreakAllTime = 0
                )
            )

            // Seed initial starter habits ready for the user to complete:
            // 1. Positive Start habits with goals and units
            // 2. Quit habit with clean timer
            val now = System.currentTimeMillis()

            val h1 = HabitEntity(
                title = "Go to the Gym",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.SPECIFIC_DAYS,
                targetDaysOfWeek = listOf(1, 3, 5), // Mon, Wed, Fri
                targetValue = 1.0,
                unit = "workout",
                reminderHour = 7,
                reminderMinute = 30,
                reminderEnabled = true,
                colorHex = "#10B981", // Emerald
                iconName = "fitness",
                createdAt = now
            )

            val h2 = HabitEntity(
                title = "Quit Smoking",
                type = HabitType.BREAK,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 1.0,
                unit = "day clean",
                reminderHour = 20,
                reminderMinute = 0,
                reminderEnabled = true,
                colorHex = "#EF4444", // Crimson
                iconName = "quit",
                createdAt = now,
                quitCleanStartTimestamp = now
            )

            val h3 = HabitEntity(
                title = "Daily Running",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 5.0,
                unit = "km",
                reminderHour = 6,
                reminderMinute = 45,
                reminderEnabled = true,
                colorHex = "#0EA5E9", // Sky Blue
                iconName = "run",
                createdAt = now
            )

            val h4 = HabitEntity(
                title = "Drink Clean Water",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 8.0,
                unit = "glasses",
                reminderHour = 10,
                reminderMinute = 0,
                reminderEnabled = false,
                colorHex = "#06B6D4", // Cyan
                iconName = "water",
                createdAt = now
            )

            dao.insertHabit(h1)
            dao.insertHabit(h2)
            dao.insertHabit(h3)
            dao.insertHabit(h4)
        } else if (existing.xp == 180 && existing.level == 2) {
            // Clean up any previous test state to Level 1 with 0 XP
            dao.upsertUserStats(
                existing.copy(
                    xp = 0,
                    level = 1,
                    unlockedBadgeIds = emptyList(),
                    totalCompletions = 0,
                    longestStreakAllTime = 0
                )
            )
        }
    }
}
