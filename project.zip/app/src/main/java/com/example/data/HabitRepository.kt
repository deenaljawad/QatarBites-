package com.example.data

import com.example.model.Badge
import com.example.model.BadgeCatalog
import com.example.model.GamificationManager
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class GamificationEventResult(
    val xpEarned: Int,
    val leveledUp: Boolean,
    val newLevel: Int,
    val newlyUnlockedBadges: List<Badge>
)

class HabitRepository(private val dao: HabitDao) {

    val allHabits: Flow<List<HabitEntity>> = dao.getAllActiveHabits()
    val userStats: Flow<UserStatsEntity?> = dao.getUserStats()

    fun getLogsForDate(dateString: String): Flow<List<HabitLogEntity>> =
        dao.getLogsForDate(dateString)

    fun getLogsForYear(yearPrefix: String): Flow<List<HabitLogEntity>> =
        dao.getLogsForYear(yearPrefix)

    suspend fun getHabitById(id: Long): HabitEntity? = dao.getHabitById(id)

    suspend fun insertHabit(habit: HabitEntity): Long {
        val id = dao.insertHabit(habit)
        checkBadgesOnHabitCreated()
        return id
    }

    suspend fun updateHabit(habit: HabitEntity) {
        dao.updateHabit(habit)
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        dao.deleteHabit(habit)
    }

    suspend fun toggleHabitCompletion(
        habit: HabitEntity,
        dateString: String
    ): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val willBeCompleted = !(existingLog?.isCompleted ?: false)

        val updatedValue = if (willBeCompleted) habit.targetValue else 0.0

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = updatedValue,
            isCompleted = willBeCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        if (willBeCompleted) {
            val xpGain = GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET
            return awardXpAndCheckBadges(xpGain, habit, isCompletion = true)
        }

        return GamificationEventResult(0, false, 0, emptyList())
    }

    suspend fun incrementHabitProgress(
        habit: HabitEntity,
        dateString: String,
        delta: Double
    ): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val currentValue = existingLog?.value ?: 0.0
        val newValue = (currentValue + delta).coerceAtLeast(0.0)
        val isCompleted = newValue >= habit.targetValue

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = newValue,
            isCompleted = isCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        val wasAlreadyCompleted = existingLog?.isCompleted ?: false
        var xpGain = GamificationManager.XP_HABIT_INCREMENT
        if (!wasAlreadyCompleted && isCompleted) {
            xpGain += GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET
        }

        return awardXpAndCheckBadges(xpGain, habit, isCompletion = (!wasAlreadyCompleted && isCompleted))
    }

    suspend fun resistCraving(habit: HabitEntity): GamificationEventResult {
        var stats = dao.getUserStatsSync() ?: UserStatsEntity()
        val newCravingCount = stats.cravingsResistedCount + 1
        stats = stats.copy(cravingsResistedCount = newCravingCount)
        dao.upsertUserStats(stats)

        return awardXpAndCheckBadges(GamificationManager.XP_CRAVING_RESISTED, habit, isCraving = true)
    }

    suspend fun recordQuitSlip(habitId: Long) {
        val habit = dao.getHabitById(habitId) ?: return
        val updated = habit.copy(
            quitCleanStartTimestamp = System.currentTimeMillis(),
            quitTotalSlips = habit.quitTotalSlips + 1
        )
        dao.updateHabit(updated)
    }

    suspend fun checkCleanDay(habit: HabitEntity, dateString: String): GamificationEventResult {
        val existingLog = dao.getLog(habit.id, dateString)
        val willBeCompleted = !(existingLog?.isCompleted ?: false)

        val newLog = HabitLogEntity(
            id = existingLog?.id ?: 0,
            habitId = habit.id,
            dateString = dateString,
            value = if (willBeCompleted) 1.0 else 0.0,
            isCompleted = willBeCompleted,
            timestamp = System.currentTimeMillis()
        )
        dao.upsertLog(newLog)

        if (willBeCompleted) {
            return awardXpAndCheckBadges(GamificationManager.XP_CLEAN_DAY_CHECK, habit, isCompletion = true)
        }
        return GamificationEventResult(0, false, 0, emptyList())
    }

    private suspend fun checkBadgesOnHabitCreated() {
        // Check Yin-Yang badge
        val habits = dao.getAllActiveHabits()
        // Collect synchronously by querying or checking
        // Let's do badge checks in awardXpAndCheckBadges
    }

    private suspend fun awardXpAndCheckBadges(
        xp: Int,
        habit: HabitEntity?,
        isCompletion: Boolean = false,
        isCraving: Boolean = false
    ): GamificationEventResult {
        var currentStats = dao.getUserStatsSync() ?: UserStatsEntity()
        val oldLevelInfo = GamificationManager.getLevelInfo(currentStats.xp)

        val newTotalXp = currentStats.xp + xp
        val newLevelInfo = GamificationManager.getLevelInfo(newTotalXp)
        val didLevelUp = newLevelInfo.currentLevel > oldLevelInfo.currentLevel

        val newCompletions = if (isCompletion) currentStats.totalCompletions + 1 else currentStats.totalCompletions

        // Calculate streaks & calendar stats
        val allCompleted = dao.getAllCompletedLogs()
        val uniqueDays = allCompleted.map { it.dateString }.distinct()

        // Today's completions count
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val todayCompletions = allCompleted.count { it.dateString == todayStr }

        // Max streak calculation
        val currentMaxStreak = calculateMaxStreak(uniqueDays)
        val longestStreak = maxOf(currentStats.longestStreakAllTime, currentMaxStreak)

        val unlockedBadges = currentStats.unlockedBadgeIds.toMutableList()
        val newlyAwarded = mutableListOf<Badge>()

        // Hour check for early bird / night owl
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)

        // Evaluate all catalog badges
        for (badge in BadgeCatalog.ALL_BADGES) {
            if (unlockedBadges.contains(badge.id)) continue

            var isEligible = false
            when (badge.id) {
                "first_step" -> if (newCompletions >= 1) isEligible = true
                "three_peat" -> if (todayCompletions >= 3) isEligible = true
                "streak_3" -> if (currentMaxStreak >= 3) isEligible = true
                "streak_7" -> if (currentMaxStreak >= 7) isEligible = true
                "streak_14" -> if (currentMaxStreak >= 14) isEligible = true
                "streak_30" -> if (currentMaxStreak >= 30) isEligible = true
                "century_club" -> if (newCompletions >= 100) isEligible = true
                "craving_slayer" -> if (currentStats.cravingsResistedCount >= 5) isEligible = true
                "level_5" -> if (newLevelInfo.currentLevel >= 5) isEligible = true
                "level_10" -> if (newLevelInfo.currentLevel >= 10) isEligible = true
                "early_bird" -> if (isCompletion && currentHour < 8) isEligible = true
                "night_sentinel" -> if (isCompletion && currentHour >= 21) isEligible = true
                "clean_7" -> {
                    if (habit?.type == HabitType.BREAK) {
                        val cleanDays = (System.currentTimeMillis() - habit.quitCleanStartTimestamp) / (1000 * 60 * 60 * 24)
                        if (cleanDays >= 7) isEligible = true
                    }
                }
            }

            if (isEligible) {
                unlockedBadges.add(badge.id)
                newlyAwarded.add(badge)
            }
        }

        val bonusBadgeXp = newlyAwarded.sumOf { it.xpReward }
        val finalXp = newTotalXp + bonusBadgeXp
        val finalLevelInfo = GamificationManager.getLevelInfo(finalXp)

        val updatedStats = currentStats.copy(
            xp = finalXp,
            level = finalLevelInfo.currentLevel,
            unlockedBadgeIds = unlockedBadges,
            totalCompletions = newCompletions,
            longestStreakAllTime = longestStreak,
            lastActiveDate = todayStr
        )
        dao.upsertUserStats(updatedStats)

        return GamificationEventResult(
            xpEarned = xp + bonusBadgeXp,
            leveledUp = didLevelUp || (finalLevelInfo.currentLevel > oldLevelInfo.currentLevel),
            newLevel = finalLevelInfo.currentLevel,
            newlyUnlockedBadges = newlyAwarded
        )
    }

    private fun calculateMaxStreak(uniqueDateStrings: List<String>): Int {
        if (uniqueDateStrings.isEmpty()) return 0
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sortedDates = uniqueDateStrings.mapNotNull {
            try { sdf.parse(it) } catch (_: Exception) { null }
        }.sorted()

        if (sortedDates.isEmpty()) return 0

        var maxStreak = 1
        var currentStreak = 1

        val oneDayMillis = 24 * 60 * 60 * 1000L

        for (i in 1 until sortedDates.size) {
            val diff = sortedDates[i].time - sortedDates[i - 1].time
            // Check if dates are consecutive (allowing timezone drift 20h - 28h)
            if (diff in (20 * 3600 * 1000L)..(28 * 3600 * 1000L)) {
                currentStreak++
                maxStreak = maxOf(maxStreak, currentStreak)
            } else if (diff > 28 * 3600 * 1000L) {
                currentStreak = 1
            }
        }
        return maxStreak
    }

    suspend fun seedSampleDataIfEmpty() {
        val existing = dao.getUserStatsSync()
        if (existing == null) {
            dao.upsertUserStats(
                UserStatsEntity(
                    id = 1,
                    xp = 180,
                    level = 2,
                    unlockedBadgeIds = listOf("first_step", "streak_3"),
                    lastActiveDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                    cravingsResistedCount = 2,
                    totalCompletions = 8,
                    longestStreakAllTime = 4
                )
            )

            // Seed initial habits showcasing the requested capabilities:
            // 1. Start habit with target and unit (e.g. 5 km or 1 time)
            // 2. Quit habit (e.g. Quit smoking / Junk food)
            // 3. Weekly/Specific days habit
            val now = System.currentTimeMillis()
            val fiveDaysAgo = now - (5 * 24 * 60 * 60 * 1000L)

            val h1 = HabitEntity(
                title = "Go to the Gym",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.SPECIFIC_DAYS,
                targetDaysOfWeek = listOf(1, 3, 5), // Mon, Wed, Fri
                targetValue = 1.0,
                unit = "workout",
                reminderHour = 7,
                reminderMinute = 30,
                reminderEnabled = true,
                colorHex = "#10B981", // Emerald
                iconName = "fitness",
                createdAt = fiveDaysAgo
            )

            val h2 = HabitEntity(
                title = "Quit Smoking",
                type = HabitType.BREAK,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 1.0,
                unit = "day clean",
                reminderHour = 20,
                reminderMinute = 0,
                reminderEnabled = true,
                colorHex = "#EF4444", // Crimson
                iconName = "quit",
                createdAt = fiveDaysAgo - (7 * 24 * 60 * 60 * 1000L),
                quitCleanStartTimestamp = fiveDaysAgo - (7 * 24 * 60 * 60 * 1000L)
            )

            val h3 = HabitEntity(
                title = "Daily Running",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 5.0,
                unit = "km",
                reminderHour = 6,
                reminderMinute = 45,
                reminderEnabled = true,
                colorHex = "#0EA5E9", // Sky Blue
                iconName = "run",
                createdAt = fiveDaysAgo
            )

            val h4 = HabitEntity(
                title = "Drink Clean Water",
                type = HabitType.BUILD,
                frequencyType = FrequencyType.DAILY,
                targetDaysOfWeek = listOf(1, 2, 3, 4, 5, 6, 7),
                targetValue = 8.0,
                unit = "glasses",
                reminderHour = 10,
                reminderMinute = 0,
                reminderEnabled = false,
                colorHex = "#06B6D4", // Cyan
                iconName = "water",
                createdAt = fiveDaysAgo
            )

            val id1 = dao.insertHabit(h1)
            val id2 = dao.insertHabit(h2)
            val id3 = dao.insertHabit(h3)
            val id4 = dao.insertHabit(h4)

            // Seed some past logs for calendar visualization
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val cal = Calendar.getInstance()

            for (dayOffset in listOf(-4, -3, -2, -1, 0)) {
                cal.time = Date()
                cal.add(Calendar.DAY_OF_YEAR, dayOffset)
                val dateStr = sdf.format(cal.time)

                if (dayOffset != 0) {
                    dao.upsertLog(HabitLogEntity(habitId = id1, dateString = dateStr, value = 1.0, isCompleted = true))
                    dao.upsertLog(HabitLogEntity(habitId = id2, dateString = dateStr, value = 1.0, isCompleted = true))
                    dao.upsertLog(HabitLogEntity(habitId = id3, dateString = dateStr, value = 5.0, isCompleted = true))
                    dao.upsertLog(HabitLogEntity(habitId = id4, dateString = dateStr, value = 8.0, isCompleted = true))
                } else {
                    // Today: partially done
                    dao.upsertLog(HabitLogEntity(habitId = id4, dateString = dateStr, value = 4.0, isCompleted = false))
                }
            }
        }
    }
}
