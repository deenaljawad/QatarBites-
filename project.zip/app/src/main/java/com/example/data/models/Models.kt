package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ServiceCategory(val label: String, val iconDescription: String) {
    VIRTUAL("Virtual Support", "Remote screen share, virus scans & software"),
    PHYSICAL("Physical Support", "Hardware repairs, on-site setup & parts"),
    SCAM_SPAM("Scam & Spam Defense", "Fraud emergency, phishing & account lockdown")
}

enum class UrgencyLevel(val label: String, val badgeColorHex: Long) {
    NORMAL("Standard", 0xFF0284C7),
    HIGH("Priority (Within 2 hrs)", 0xFFF59E0B),
    CRITICAL_EMERGENCY("Critical Emergency (Immediate)", 0xFFEF4444)
}

enum class BookingStatus(val label: String, val stepIndex: Int) {
    PENDING("Booking Received", 0),
    CONFIRMED("Confirmed", 1),
    IN_PROGRESS("In Progress", 2),
    COMPLETED("Resolved & Completed", 3),
    CANCELLED("Cancelled", -1)
}

enum class PaymentStatus(val label: String) {
    UNPAID("Unpaid"),
    PAID("Paid"),
    REFUNDED("Refunded")
}

@Entity(tableName = "tech_services")
data class TechService(
    @PrimaryKey val id: String,
    val title: String,
    val category: ServiceCategory,
    val tagline: String,
    val description: String,
    val price: Double,
    val durationMinutes: Int,
    val isEmergency: Boolean = false,
    val features: String, // Comma separated items
    val iconType: String, // e.g. "remote", "malware", "hardware", "wifi", "shield", "scam"
    val isAvailable: Boolean = true
) {
    val featuresList: List<String>
        get() = features.split("|").map { it.trim() }.filter { it.isNotEmpty() }
}

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey val id: String,
    val serviceId: String,
    val serviceTitle: String,
    val category: ServiceCategory,
    val customerName: String,
    val customerEmail: String,
    val customerPhone: String,
    val appointmentDate: String,
    val appointmentTimeSlot: String,
    val serviceModeDetail: String, // Address or Remote Tool ID or Emergency Callback notes
    val issueDescription: String,
    val urgencyLevel: UrgencyLevel,
    val assignedTechnician: String? = null,
    val status: BookingStatus,
    val paymentStatus: PaymentStatus,
    val paymentMethod: String,
    val amountPaid: Double,
    val transactionId: String,
    val createdAtTimestamp: Long,
    val adminNotes: String = ""
)

@Entity(tableName = "scam_reports")
data class ScamReport(
    @PrimaryKey val id: String,
    val reporterName: String,
    val contactPhone: String,
    val scamType: String,
    val details: String,
    val financialLossReported: Boolean,
    val lossAmount: Double,
    val urgency: UrgencyLevel,
    val status: String = "Pending Review",
    val timestamp: Long = System.currentTimeMillis()
)
