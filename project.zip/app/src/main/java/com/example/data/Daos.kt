package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.models.Booking
import com.example.data.models.ScamReport
import com.example.data.models.ServiceCategory
import com.example.data.models.TechService
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceDao {
    @Query("SELECT * FROM tech_services ORDER BY price ASC")
    fun getAllServices(): Flow<List<TechService>>

    @Query("SELECT * FROM tech_services WHERE category = :category ORDER BY price ASC")
    fun getServicesByCategory(category: ServiceCategory): Flow<List<TechService>>

    @Query("SELECT * FROM tech_services WHERE id = :id LIMIT 1")
    suspend fun getServiceById(id: String): TechService?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(services: List<TechService>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertService(service: TechService)

    @Update
    suspend fun updateService(service: TechService)

    @Delete
    suspend fun deleteService(service: TechService)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY createdAtTimestamp DESC")
    fun getAllBookings(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
    fun getBookingById(id: String): Flow<Booking?>

    @Query("SELECT * FROM bookings WHERE category = :category ORDER BY createdAtTimestamp DESC")
    fun getBookingsByCategory(category: ServiceCategory): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)

    @Delete
    suspend fun deleteBooking(booking: Booking)
}

@Dao
interface ScamReportDao {
    @Query("SELECT * FROM scam_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<ScamReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ScamReport)

    @Update
    suspend fun updateReport(report: ScamReport)
}
