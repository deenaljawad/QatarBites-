package com.example.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromIntList(list: List<Int>?): String {
        return list?.joinToString(separator = ",") ?: ""
    }

    @TypeConverter
    fun toIntList(data: String?): List<Int> {
        if (data.isNullOrEmpty()) return emptyList()
        return data.split(",").mapNotNull { it.trim().toIntOrNull() }
    }

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        return list?.joinToString(separator = ";") ?: ""
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrEmpty()) return emptyList()
        return data.split(";").map { it.trim() }.filter { it.isNotEmpty() }
    }

    @TypeConverter
    fun fromHabitType(type: HabitType?): String {
        return type?.name ?: HabitType.BUILD.name
    }

    @TypeConverter
    fun toHabitType(value: String?): HabitType {
        return try {
            value?.let { HabitType.valueOf(it) } ?: HabitType.BUILD
        } catch (_: Exception) {
            HabitType.BUILD
        }
    }

    @TypeConverter
    fun fromFrequencyType(type: FrequencyType?): String {
        return type?.name ?: FrequencyType.DAILY.name
    }

    @TypeConverter
    fun toFrequencyType(value: String?): FrequencyType {
        return try {
            value?.let { FrequencyType.valueOf(it) } ?: FrequencyType.DAILY
        } catch (_: Exception) {
            FrequencyType.DAILY
        }
    }
}
