package com.example.data

import androidx.room.TypeConverter
import com.example.data.models.BookingStatus
import com.example.data.models.PaymentStatus
import com.example.data.models.ServiceCategory
import com.example.data.models.UrgencyLevel

class AppTypeConverters {
    @TypeConverter
    fun fromCategory(category: ServiceCategory): String = category.name

    @TypeConverter
    fun toCategory(value: String): ServiceCategory = runCatching {
        ServiceCategory.valueOf(value)
    }.getOrDefault(ServiceCategory.VIRTUAL)

    @TypeConverter
    fun fromUrgency(urgency: UrgencyLevel): String = urgency.name

    @TypeConverter
    fun toUrgency(value: String): UrgencyLevel = runCatching {
        UrgencyLevel.valueOf(value)
    }.getOrDefault(UrgencyLevel.NORMAL)

    @TypeConverter
    fun fromBookingStatus(status: BookingStatus): String = status.name

    @TypeConverter
    fun toBookingStatus(value: String): BookingStatus = runCatching {
        BookingStatus.valueOf(value)
    }.getOrDefault(BookingStatus.PENDING)

    @TypeConverter
    fun fromPaymentStatus(status: PaymentStatus): String = status.name

    @TypeConverter
    fun toPaymentStatus(value: String): PaymentStatus = runCatching {
        PaymentStatus.valueOf(value)
    }.getOrDefault(PaymentStatus.UNPAID)
}
