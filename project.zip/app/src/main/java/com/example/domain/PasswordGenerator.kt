package com.example.domain

import androidx.compose.ui.graphics.Color
import java.security.SecureRandom
import kotlin.math.log2

enum class PasswordStrength(val label: String, val score: Int, val color: Color) {
    VERY_WEAK("Very Weak", 1, Color(0xFFEF4444)),
    WEAK("Weak", 2, Color(0xFFF97316)),
    FAIR("Fair", 3, Color(0xFFEAB308)),
    STRONG("Strong", 4, Color(0xFF10B981)),
    FORTRESS("Very Strong", 5, Color(0xFF06B6D4))
}

data class GeneratorOptions(
    val length: Int = 18,
    val includeUppercase: Boolean = true,
    val includeLowercase: Boolean = true,
    val includeNumbers: Boolean = true,
    val includeSymbols: Boolean = true,
    val excludeAmbiguous: Boolean = false
)

data class PasswordEvaluation(
    val password: String,
    val strength: PasswordStrength,
    val entropyBits: Int,
    val uppercaseCount: Int,
    val lowercaseCount: Int,
    val numberCount: Int,
    val symbolCount: Int
)

object PasswordGenerator {

    private const val UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    private const val LOWERCASE = "abcdefghijklmnopqrstuvwxyz"
    private const val NUMBERS = "0123456789"
    private const val SYMBOLS = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    private const val AMBIGUOUS = "0O1lI|"

    private val secureRandom = SecureRandom()

    fun generate(options: GeneratorOptions): String {
        var upperPool = if (options.includeUppercase) UPPERCASE else ""
        var lowerPool = if (options.includeLowercase) LOWERCASE else ""
        var numberPool = if (options.includeNumbers) NUMBERS else ""
        var symbolPool = if (options.includeSymbols) SYMBOLS else ""

        if (options.excludeAmbiguous) {
            upperPool = upperPool.filter { it !in AMBIGUOUS }
            lowerPool = lowerPool.filter { it !in AMBIGUOUS }
            numberPool = numberPool.filter { it !in AMBIGUOUS }
            symbolPool = symbolPool.filter { it !in AMBIGUOUS }
        }

        val allPool = upperPool + lowerPool + numberPool + symbolPool
        if (allPool.isEmpty()) {
            return ""
        }

        val requiredChars = mutableListOf<Char>()
        if (options.includeUppercase && upperPool.isNotEmpty()) {
            requiredChars.add(upperPool[secureRandom.nextInt(upperPool.length)])
        }
        if (options.includeLowercase && lowerPool.isNotEmpty()) {
            requiredChars.add(lowerPool[secureRandom.nextInt(lowerPool.length)])
        }
        if (options.includeNumbers && numberPool.isNotEmpty()) {
            requiredChars.add(numberPool[secureRandom.nextInt(numberPool.length)])
        }
        if (options.includeSymbols && symbolPool.isNotEmpty()) {
            requiredChars.add(symbolPool[secureRandom.nextInt(symbolPool.length)])
        }

        val passwordChars = mutableListOf<Char>()
        passwordChars.addAll(requiredChars)

        val remaining = options.length - passwordChars.size
        for (i in 0 until remaining) {
            passwordChars.add(allPool[secureRandom.nextInt(allPool.length)])
        }

        // Shuffle securely
        for (i in passwordChars.indices.reversed()) {
            val j = secureRandom.nextInt(i + 1)
            val temp = passwordChars[i]
            passwordChars[i] = passwordChars[j]
            passwordChars[j] = temp
        }

        return passwordChars.joinToString("")
    }

    fun evaluate(password: String): PasswordEvaluation {
        if (password.isEmpty()) {
            return PasswordEvaluation(
                password = "",
                strength = PasswordStrength.VERY_WEAK,
                entropyBits = 0,
                uppercaseCount = 0,
                lowercaseCount = 0,
                numberCount = 0,
                symbolCount = 0
            )
        }

        var poolSize = 0
        var hasUpper = false
        var hasLower = false
        var hasNumber = false
        var hasSymbol = false

        var upperCount = 0
        var lowerCount = 0
        var numberCount = 0
        var symbolCount = 0

        for (ch in password) {
            when {
                ch.isUpperCase() -> {
                    hasUpper = true
                    upperCount++
                }
                ch.isLowerCase() -> {
                    hasLower = true
                    lowerCount++
                }
                ch.isDigit() -> {
                    hasNumber = true
                    numberCount++
                }
                else -> {
                    hasSymbol = true
                    symbolCount++
                }
            }
        }

        if (hasUpper) poolSize += 26
        if (hasLower) poolSize += 26
        if (hasNumber) poolSize += 10
        if (hasSymbol) poolSize += 30
        if (poolSize == 0) poolSize = 10

        val entropy = (password.length * log2(poolSize.toDouble())).toInt()

        val strength = when {
            password.length < 8 || entropy < 35 -> PasswordStrength.VERY_WEAK
            entropy < 50 -> PasswordStrength.WEAK
            entropy < 65 -> PasswordStrength.FAIR
            entropy < 85 -> PasswordStrength.STRONG
            else -> PasswordStrength.FORTRESS
        }

        return PasswordEvaluation(
            password = password,
            strength = strength,
            entropyBits = entropy,
            uppercaseCount = upperCount,
            lowercaseCount = lowerCount,
            numberCount = numberCount,
            symbolCount = symbolCount
        )
    }
}
