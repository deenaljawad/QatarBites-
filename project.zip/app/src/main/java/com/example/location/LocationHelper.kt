package com.example.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.tasks.await

data class QatarPresetLocation(
    val name: String,
    val arabicName: String,
    val latitude: Double,
    val longitude: Double
)

class LocationHelper(private val context: Context) {

    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    companion object {
        val QATAR_PRESETS = listOf(
            QatarPresetLocation("Doha Corniche", "كورنيش الدوحة", 25.2917, 51.5310),
            QatarPresetLocation("Souq Waqif", "سوق واقف", 25.2867, 51.5333),
            QatarPresetLocation("The Pearl-Qatar", "اللؤلؤة قطر", 25.3700, 51.5450),
            QatarPresetLocation("Katara Cultural Village", "حي كتارا الثقافي", 25.3570, 51.5270),
            QatarPresetLocation("Lusail City", "مدينة لوسيل", 25.4200, 51.5200),
            QatarPresetLocation("Hamad Int'l Airport (HIA)", "مطار حمد الدولي", 25.2609, 51.6138)
        )
    }

    fun hasLocationPermission(): Boolean {
        val fineLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fineLocation || coarseLocation
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): Location? {
        if (!hasLocationPermission()) {
            return null
        }

        return try {
            val cancellationTokenSource = CancellationTokenSource()
            val location = fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                cancellationTokenSource.token
            ).await()

            location ?: fusedLocationClient.lastLocation.await() ?: getFallbackSystemLocation()
        } catch (e: Exception) {
            getFallbackSystemLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getFallbackSystemLocation(): Location? {
        if (!hasLocationPermission()) return null
        return try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val gpsLoc = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            val netLoc = locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            val passiveLoc = locationManager?.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)

            gpsLoc ?: netLoc ?: passiveLoc
        } catch (e: Exception) {
            null
        }
    }
}
