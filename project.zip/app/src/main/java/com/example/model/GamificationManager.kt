package com.example.model

object GamificationManager {

    data class LevelInfo(
        val currentLevel: Int,
        val rankTitle: String,
        val currentLevelXp: Int,
        val nextLevelTargetXp: Int,
        val progressRatio: Float // 0.0 to 1.0
    )

    // Progressive thresholds
    private val LEVEL_THRESHOLDS = intArrayOf(
        0,      // Level 1 starts at 0
        100,    // Level 2
        250,    // Level 3
        450,    // Level 4
        700,    // Level 5
        1050,   // Level 6
        1500,   // Level 7
        2100,   // Level 8
        2850,   // Level 9
        3800,   // Level 10
        5000,   // Level 11
        6500,   // Level 12
        8500,   // Level 13
        11000   // Level 14+
    )

    private val RANK_TITLES = listOf(
        "Novice Initiate",      // Lvl 1
        "Apprentice",           // Lvl 2
        "Habit Warrior",        // Lvl 3
        "Consistency Scout",    // Lvl 4
        "Iron Will Veteran",    // Lvl 5
        "Discipline Knight",    // Lvl 6
        "Habit Champion",       // Lvl 7
        "Master of Will",       // Lvl 8
        "Grandmaster",          // Lvl 9
        "Titan of Willpower",   // Lvl 10
        "Mythic Paragon"        // Lvl 11+
    )

    fun getLevelInfo(totalXp: Int): LevelInfo {
        var level = 1
        for (i in LEVEL_THRESHOLDS.indices.reversed()) {
            if (totalXp >= LEVEL_THRESHOLDS[i]) {
                level = i + 1
                break
            }
        }

        val rankIndex = (level - 1).coerceIn(0, RANK_TITLES.lastIndex)
        val rankTitle = RANK_TITLES[rankIndex]

        val currentThreshold = if (level - 1 < LEVEL_THRESHOLDS.size) LEVEL_THRESHOLDS[level - 1] else LEVEL_THRESHOLDS.last()
        val nextThreshold = if (level < LEVEL_THRESHOLDS.size) {
            LEVEL_THRESHOLDS[level]
        } else {
            currentThreshold + 1500
        }

        val span = (nextThreshold - currentThreshold).coerceAtLeast(1)
        val gainedInLevel = (totalXp - currentThreshold).coerceAtLeast(0)
        val progressRatio = (gainedInLevel.toFloat() / span).coerceIn(0f, 1f)

        return LevelInfo(
            currentLevel = level,
            rankTitle = rankTitle,
            currentLevelXp = gainedInLevel,
            nextLevelTargetXp = span,
            progressRatio = progressRatio
        )
    }

    const val XP_HABIT_INCREMENT = 10
    const val XP_HABIT_COMPLETE = 25
    const val XP_DAILY_GOAL_MET = 35
    const val XP_CRAVING_RESISTED = 40
    const val XP_CLEAN_DAY_CHECK = 30
}
