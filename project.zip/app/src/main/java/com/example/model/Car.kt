package com.example.model

enum class SortOption(val displayName: String) {
  FEATURED("Featured"),
  PRICE_LOW_HIGH("Price: Low to High"),
  PRICE_HIGH_LOW("Price: High to Low"),
  BEST_DEALS("Biggest Discount"),
  NEWEST("Newest Year"),
  LOWEST_MILEAGE("Lowest Mileage")
}

data class Car(
  val id: String,
  val brand: String,
  val model: String,
  val year: Int,
  val trim: String,
  val price: Double,
  val originalPrice: Double? = null,
  val isHotDeal: Boolean = false,
  val dealBadge: String? = null,
  val bodyType: String, // SUV, Sedan, Coupe, Convertible, Electric, Sports
  val condition: String, // Brand New, Certified Pre-Owned, Pre-Owned
  val mileage: Int, // miles
  val fuelType: String, // Electric, Hybrid, Twin-Turbo V8, Turbo 6-Cyl, Petrol
  val transmission: String,
  val drivetrain: String, // AWD, RWD, FWD, e-AWD
  val horsepower: Int,
  val zeroToSixty: Double, // in seconds
  val topSpeed: Int, // mph
  val rangeOrMpg: String, // e.g. "396 mi range" or "24 MPG combined"
  val exteriorColor: String,
  val interiorColor: String,
  val rating: Double,
  val reviewCount: Int,
  val dealerName: String,
  val dealerLocation: String,
  val dealerPhone: String,
  val features: List<String>,
  val description: String,
  val gradientColors: List<Long> = listOf(0xFF1E293B, 0xFF0F172A),
  val vin: String = "1HGCR2F83HA00" + (1000..9999).random()
) {
  val discountAmount: Double
    get() = if (originalPrice != null && originalPrice > price) originalPrice - price else 0.0

  val discountPercent: Int
    get() = if (originalPrice != null && originalPrice > price) {
      (((originalPrice - price) / originalPrice) * 100).toInt()
    } else 0

  // Estimated monthly payment assuming 10% down, 60 mo, 5.5% APR
  val estimatedMonthlyPayment: Int
    get() {
      val principal = price * 0.90
      val monthlyRate = 0.055 / 12
      val months = 60
      val monthly = principal * (monthlyRate * Math.pow(1 + monthlyRate, months.toDouble())) / (Math.pow(1 + monthlyRate, months.toDouble()) - 1)
      return monthly.toInt()
    }
}

data class CarFilterState(
  val selectedBrands: Set<String> = emptySet(),
  val onlyDeals: Boolean = false,
  val minPrice: Float = 15000f,
  val maxPrice: Float = 250000f,
  val selectedBodyTypes: Set<String> = emptySet(),
  val selectedConditions: Set<String> = emptySet(),
  val selectedFuelTypes: Set<String> = emptySet(),
  val searchQuery: String = "",
  val sortBy: SortOption = SortOption.FEATURED
) {
  val hasActiveFilters: Boolean
    get() = selectedBrands.isNotEmpty() ||
        onlyDeals ||
        minPrice > 15000f ||
        maxPrice < 250000f ||
        selectedBodyTypes.isNotEmpty() ||
        selectedConditions.isNotEmpty() ||
        selectedFuelTypes.isNotEmpty() ||
        searchQuery.isNotBlank() ||
        sortBy != SortOption.FEATURED

  val activeFilterCount: Int
    get() {
      var count = 0
      if (selectedBrands.isNotEmpty()) count += selectedBrands.size
      if (onlyDeals) count += 1
      if (minPrice > 15000f || maxPrice < 250000f) count += 1
      if (selectedBodyTypes.isNotEmpty()) count += selectedBodyTypes.size
      if (selectedConditions.isNotEmpty()) count += selectedConditions.size
      if (selectedFuelTypes.isNotEmpty()) count += selectedFuelTypes.size
      if (sortBy != SortOption.FEATURED) count += 1
      return count
    }
}

data class TestDriveBooking(
  val id: String,
  val carId: String,
  val carTitle: String,
  val date: String,
  val timeSlot: String,
  val customerName: String,
  val customerPhone: String,
  val status: String = "Confirmed"
)

data class OfferInquiry(
  val id: String,
  val carId: String,
  val carTitle: String,
  val offerPrice: Double,
  val hasTradeIn: Boolean,
  val message: String,
  val timestamp: String
)
