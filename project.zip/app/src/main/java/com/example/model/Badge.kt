package com.example.model

data class Badge(
    val id: String,
    val title: String,
    val description: String,
    val category: BadgeCategory,
    val iconName: String,
    val xpReward: Int,
    val maxProgress: Int = 1
)

enum class BadgeCategory {
    STREAK,
    MILESTONES,
    QUIT_HABITS,
    MASTERY
}

object BadgeCatalog {
    val ALL_BADGES = listOf(
        Badge(
            id = "first_step",
            title = "First Spark",
            description = "Log your first habit completion and begin the quest.",
            category = BadgeCategory.MILESTONES,
            iconName = "spark",
            xpReward = 50,
            maxProgress = 1
        ),
        Badge(
            id = "three_peat",
            title = "Triple Threat",
            description = "Complete 3 distinct habits on a single calendar day.",
            category = BadgeCategory.MILESTONES,
            iconName = "trophy",
            xpReward = 100,
            maxProgress = 3
        ),
        Badge(
            id = "streak_3",
            title = "Flame Ignited",
            description = "Maintain a 3-day continuous habit streak.",
            category = BadgeCategory.STREAK,
            iconName = "fire",
            xpReward = 100,
            maxProgress = 3
        ),
        Badge(
            id = "streak_7",
            title = "Week Warrior",
            description = "Maintain a 7-day unbroken habit streak.",
            category = BadgeCategory.STREAK,
            iconName = "shield_fire",
            xpReward = 250,
            maxProgress = 7
        ),
        Badge(
            id = "streak_14",
            title = "Fortitude",
            description = "Maintain a 14-day habit streak across any habit.",
            category = BadgeCategory.STREAK,
            iconName = "swords",
            xpReward = 500,
            maxProgress = 14
        ),
        Badge(
            id = "streak_30",
            title = "Iron Will",
            description = "Reach a 30-day streak of disciplined consistency.",
            category = BadgeCategory.STREAK,
            iconName = "crown",
            xpReward = 1000,
            maxProgress = 30
        ),
        Badge(
            id = "clean_7",
            title = "Freedom Fighter",
            description = "Stay clean for 7 full days on a Quit habit.",
            category = BadgeCategory.QUIT_HABITS,
            iconName = "shield_check",
            xpReward = 300,
            maxProgress = 7
        ),
        Badge(
            id = "craving_slayer",
            title = "Willpower Shield",
            description = "Log 5 cravings successfully resisted on Quit habits.",
            category = BadgeCategory.QUIT_HABITS,
            iconName = "sword_shield",
            xpReward = 200,
            maxProgress = 5
        ),
        Badge(
            id = "century_club",
            title = "Century Legend",
            description = "Achieve 100 total habit check-offs across your journey.",
            category = BadgeCategory.MILESTONES,
            iconName = "medal",
            xpReward = 800,
            maxProgress = 100
        ),
        Badge(
            id = "early_bird",
            title = "Dawn Crusader",
            description = "Check off a habit before 8:00 AM.",
            category = BadgeCategory.MASTERY,
            iconName = "sun",
            xpReward = 75,
            maxProgress = 1
        ),
        Badge(
            id = "night_sentinel",
            title = "Night Sentinel",
            description = "Check off a habit after 9:00 PM.",
            category = BadgeCategory.MASTERY,
            iconName = "moon",
            xpReward = 75,
            maxProgress = 1
        ),
        Badge(
            id = "level_5",
            title = "Disciplined Veteran",
            description = "Earn enough XP to ascend to Level 5.",
            category = BadgeCategory.MASTERY,
            iconName = "star_filled",
            xpReward = 400,
            maxProgress = 5
        ),
        Badge(
            id = "level_10",
            title = "Titan of Willpower",
            description = "Ascend to Level 10 and enter the hall of titans.",
            category = BadgeCategory.MASTERY,
            iconName = "gem",
            xpReward = 1500,
            maxProgress = 10
        ),
        Badge(
            id = "yin_yang",
            title = "Master of Balance",
            description = "Have at least 1 active Start habit and 1 active Quit habit.",
            category = BadgeCategory.MASTERY,
            iconName = "yin_yang",
            xpReward = 150,
            maxProgress = 2
        )
    )
}
