package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HabitReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val habitId = intent.getLongExtra("habit_id", -1L)
        val habitTitle = intent.getStringExtra("habit_title") ?: "Habit"
        val habitTarget = intent.getStringExtra("habit_target") ?: "1 time"

        if (habitId != -1L) {
            NotificationHelper.showReminderNotification(
                context = context,
                notificationId = habitId.toInt(),
                habitTitle = habitTitle,
                habitTarget = habitTarget
            )

            // Re-schedule for the next day
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val habit = db.habitDao().getHabitById(habitId)
                if (habit != null && habit.reminderEnabled) {
                    ReminderScheduler.scheduleHabitReminder(context, habit)
                }
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val habits = db.habitDao().getAllActiveHabits()
                // Collect once to restore alarms
                habits.collect { habitList ->
                    habitList.filter { it.reminderEnabled }.forEach { habit ->
                        ReminderScheduler.scheduleHabitReminder(context, habit)
                    }
                }
            }
        }
    }
}
