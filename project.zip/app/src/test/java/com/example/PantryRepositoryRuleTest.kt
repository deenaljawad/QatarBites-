package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.DietaryProfile
import com.example.data.model.Recipe
import com.example.data.repository.DietaryRepository
import com.example.data.repository.PantryRepository
import com.example.data.repository.RecipeRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PantryRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun testPantryItemLifecycle() = runBlocking {
        val uid = signInTestUser("alice_${System.currentTimeMillis()}@test.com")
        val repo = PantryRepository(firestore, auth)

        repo.addPantryItem("Olive Oil", "Pantry", "500ml")
        val items = repo.observePantryItems().first { it.isNotEmpty() }
        assertEquals(1, items.size)
        assertEquals("Olive Oil", items[0].name)
        assertEquals("500ml", items[0].quantity)

        val item = items[0]
        repo.updatePantryItem(item.copy(quantity = "750ml"))
        val updated = repo.observePantryItems().first { it.any { it.quantity == "750ml" } }
        assertEquals("750ml", updated[0].quantity)

        repo.deletePantryItem(item.id)
        val empty = repo.observePantryItems().first { it.isEmpty() }
        assertTrue(empty.isEmpty())
    }

    @Test
    fun testDietaryProfileLifecycle() = runBlocking {
        val uid = signInTestUser("bob_${System.currentTimeMillis()}@test.com")
        val repo = DietaryRepository(firestore, auth)

        val profile = DietaryProfile(
            diets = listOf("Keto"),
            allergies = listOf("Peanuts"),
            dislikes = listOf("Cilantro"),
            calorieTarget = 2100,
            servingsPreference = 2,
            cookingTimePreference = "Under 30 mins"
        )
        repo.saveDietaryProfile(profile)

        val loaded = repo.observeDietaryProfile().first { it != null }
        assertNotNull(loaded)
        assertEquals(listOf("Keto"), loaded?.diets)
        assertEquals(2100, loaded?.calorieTarget)
    }

    @Test
    fun testRecipeLifecycle() = runBlocking {
        val uid = signInTestUser("carol_${System.currentTimeMillis()}@test.com")
        val repo = RecipeRepository(firestore, auth)

        val recipe = Recipe(
            title = "Lemon Herb Salmon",
            description = "Crispy pan-seared salmon with lemon and dill.",
            mealType = "Dinner",
            prepTime = 10,
            cookTime = 12,
            servings = 2,
            calories = 420,
            protein = 38,
            carbs = 2,
            fat = 26,
            ingredients = listOf("2 salmon fillets", "1 lemon", "Fresh dill", "1 tbsp olive oil"),
            instructions = listOf("Season salmon.", "Sear skin-down for 5 mins.", "Flip and finish with lemon."),
            matchingPantryIngredients = listOf("Olive oil"),
            missingIngredients = listOf("Salmon", "Lemon", "Dill"),
            isFavorite = false
        )
        val docId = repo.saveRecipe(recipe)
        assertTrue(docId.isNotBlank())

        val recipes = repo.observeRecipes().first { it.isNotEmpty() }
        assertEquals(1, recipes.size)
        assertEquals("Lemon Herb Salmon", recipes[0].title)

        repo.toggleFavorite(recipes[0])
        val favRecipes = repo.observeRecipes().first { it.any { it.isFavorite } }
        assertTrue(favRecipes[0].isFavorite)
    }
}
