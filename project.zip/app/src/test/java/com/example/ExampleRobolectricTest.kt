package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("QatarBites", appName)
  }

  @Test
  fun `verify restaurant repository contains high rated Qatar dining`() {
    val repository = com.example.data.repository.RestaurantRepository()
    val restaurants = repository.getAllRestaurants()
    org.junit.Assert.assertTrue(restaurants.isNotEmpty())
    org.junit.Assert.assertTrue(restaurants.all { it.rating >= 4.5 })
    org.junit.Assert.assertTrue(restaurants.any { it.area.contains("Katara") })
    org.junit.Assert.assertTrue(restaurants.any { it.area.contains("Souq Waqif") })
  }
}
