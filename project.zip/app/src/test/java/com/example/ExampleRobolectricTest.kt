package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.FrequencyType
import com.example.data.HabitEntity
import com.example.data.HabitRepository
import com.example.data.HabitType
import com.example.model.GamificationManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("HabitCraft", appName)
  }

  @Test
  fun `test gamification level info calculation`() {
    val level1 = GamificationManager.getLevelInfo(50)
    assertEquals(1, level1.currentLevel)
    assertEquals("Novice Initiate", level1.rankTitle)

    val level2 = GamificationManager.getLevelInfo(150)
    assertEquals(2, level2.currentLevel)
    assertEquals("Apprentice", level2.rankTitle)

    val highLevel = GamificationManager.getLevelInfo(5000)
    assertTrue(highLevel.currentLevel >= 10)
  }

  @Test
  fun `checking and unchecking habit does not grant infinite XP`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = AppDatabase.getDatabase(context)
    val repo = HabitRepository(db.habitDao())

    val habit = HabitEntity(
      id = 101L,
      title = "Read Books",
      type = HabitType.BUILD,
      frequencyType = FrequencyType.DAILY,
      targetValue = 1.0,
      unit = "time"
    )
    repo.insertHabit(habit)

    val dateStr = "2026-10-30"

    // First check: awards XP
    val result1 = repo.toggleHabitCompletion(habit, dateStr)
    assertTrue("First checkoff should earn XP", result1.xpEarned > 0)

    // Uncheck: should award 0 XP
    val result2 = repo.toggleHabitCompletion(habit, dateStr)
    assertEquals("Unchecking should earn 0 XP", 0, result2.xpEarned)

    // Second check on the same date: should earn 0 XP (no infinite XP loophole)
    val result3 = repo.toggleHabitCompletion(habit, dateStr)
    assertEquals("Re-checking on same day must not earn additional XP", 0, result3.xpEarned)

    // Third check on the same date: still 0 XP
    repo.toggleHabitCompletion(habit, dateStr) // uncheck
    val result4 = repo.toggleHabitCompletion(habit, dateStr) // check again
    assertEquals("Repeated check on same day must earn 0 XP", 0, result4.xpEarned)
  }
}
