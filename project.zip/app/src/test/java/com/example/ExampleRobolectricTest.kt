package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.GeneratorOptions
import com.example.domain.PasswordGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PassForge", appName)
  }

  @Test
  fun `password generator generates requested length`() {
    val options = GeneratorOptions(length = 24, includeUppercase = true, includeLowercase = true, includeNumbers = true, includeSymbols = true)
    val password = PasswordGenerator.generate(options)
    assertEquals(24, password.length)
  }

  @Test
  fun `password evaluation returns positive entropy`() {
    val options = GeneratorOptions(length = 20)
    val password = PasswordGenerator.generate(options)
    val eval = PasswordGenerator.evaluate(password)
    assertTrue(eval.entropyBits > 60)
  }
}
