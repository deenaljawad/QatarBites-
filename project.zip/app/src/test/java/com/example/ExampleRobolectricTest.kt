package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.GamificationManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("HabitCraft", appName)
  }

  @Test
  fun `test gamification level info calculation`() {
    val level1 = GamificationManager.getLevelInfo(50)
    assertEquals(1, level1.currentLevel)
    assertEquals("Novice Initiate", level1.rankTitle)

    val level2 = GamificationManager.getLevelInfo(150)
    assertEquals(2, level2.currentLevel)
    assertEquals("Apprentice", level2.rankTitle)

    val highLevel = GamificationManager.getLevelInfo(5000)
    assertTrue(highLevel.currentLevel >= 10)
  }
}
