package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.FrequencyType
import com.example.data.HabitEntity
import com.example.data.HabitRepository
import com.example.data.HabitType
import com.example.model.GamificationManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("HabitCraft", appName)
  }

  @Test
  fun `test gamification level info calculation`() {
    val level1 = GamificationManager.getLevelInfo(0)
    assertEquals(1, level1.currentLevel)
    assertEquals("Novice Initiate", level1.rankTitle)

    val level2 = GamificationManager.getLevelInfo(150)
    assertEquals(2, level2.currentLevel)
    assertEquals("Apprentice", level2.rankTitle)

    val highLevel = GamificationManager.getLevelInfo(5000)
    assertTrue(highLevel.currentLevel >= 10)
  }

  @Test
  fun `user starts at level 1 with 0 XP`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = AppDatabase.getDatabase(context)
    val repo = HabitRepository(db.habitDao())
    repo.seedSampleDataIfEmpty()

    val stats = repo.userStats.first()
    assertEquals("Initial XP must be 0", 0, stats?.xp ?: -1)
    assertEquals("Initial Level must be 1", 1, stats?.level ?: -1)
    assertTrue("Initial unlocked badges must be empty", stats?.unlockedBadgeIds?.isEmpty() == true)
  }

  @Test
  fun `unchecking habit takes back the XP it gave`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = AppDatabase.getDatabase(context)
    val repo = HabitRepository(db.habitDao())

    val habit = HabitEntity(
      id = 101L,
      title = "Read Books",
      type = HabitType.BUILD,
      frequencyType = FrequencyType.DAILY,
      targetValue = 1.0,
      unit = "time"
    )
    repo.insertHabit(habit)

    val dateStr = "2026-10-30"

    // 1. Check off habit: awards XP
    val result1 = repo.toggleHabitCompletion(habit, dateStr)
    assertTrue("Checking off should earn positive XP", result1.xpEarned > 0)
    val xpAfterCheck = repo.userStats.first()?.xp ?: 0

    val habitXp = GamificationManager.XP_HABIT_COMPLETE + GamificationManager.XP_DAILY_GOAL_MET

    // 2. Uncheck habit: takes back the XP it gave (-60 XP)
    val result2 = repo.toggleHabitCompletion(habit, dateStr)
    assertEquals("Unchecking should have -habitXp earned", -habitXp, result2.xpEarned)
    val xpAfterUncheck = repo.userStats.first()?.xp ?: 0
    assertEquals("XP should be reduced by the exact habit amount after unchecking", xpAfterCheck - habitXp, xpAfterUncheck)

    // 3. Re-check habit: awards the habit XP again (+60 XP)
    val result3 = repo.toggleHabitCompletion(habit, dateStr)
    assertEquals("Re-checking should earn habit XP again", habitXp, result3.xpEarned)
    val xpAfterRecheck = repo.userStats.first()?.xp ?: 0
    assertEquals("XP should be restored after rechecking", xpAfterUncheck + habitXp, xpAfterRecheck)
  }
}
