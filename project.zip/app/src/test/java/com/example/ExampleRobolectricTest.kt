package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.RiskLevel
import com.example.data.TechHelpRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TechHelp4U", appName)
  }

  @Test
  fun `verify scam analyzer detects remote tool and gift card red flags`() {
    // Test the scam analysis heuristics directly
    val sampleText = "URGENT: Install AnyDesk immediately and pay $500 in Target gift card to cancel arrest warrant."
    val lower = sampleText.lowercase()
    val isAnyDesk = lower.contains("anydesk")
    val isGiftCard = lower.contains("gift card")
    val isUrgent = lower.contains("urgent")

    assertTrue(isAnyDesk)
    assertTrue(isGiftCard)
    assertTrue(isUrgent)
  }
}
