package com.example

import com.example.data.CarRepository
import com.example.model.CarFilterState
import com.example.model.SortOption
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  private val repository = CarRepository()

  @Test
  fun testAllCarsCatalogNotEmpty() {
    assertTrue(repository.allCars.isNotEmpty())
    assertTrue(repository.allCars.size >= 10)
  }

  @Test
  fun testBrandFiltering() {
    val porscheCars = repository.filterCars(
      repository.allCars,
      CarFilterState(selectedBrands = setOf("Porsche"))
    )
    assertTrue(porscheCars.isNotEmpty())
    assertTrue(porscheCars.all { it.brand == "Porsche" })

    val bmwCars = repository.filterCars(
      repository.allCars,
      CarFilterState(selectedBrands = setOf("BMW"))
    )
    assertTrue(bmwCars.isNotEmpty())
    assertTrue(bmwCars.all { it.brand == "BMW" })
  }

  @Test
  fun testDealsOnlyFiltering() {
    val dealCars = repository.filterCars(
      repository.allCars,
      CarFilterState(onlyDeals = true)
    )
    assertTrue(dealCars.isNotEmpty())
    assertTrue(dealCars.all { it.isHotDeal })
    assertTrue(dealCars.all { it.discountAmount > 0.0 })
  }

  @Test
  fun testPriceSorting() {
    val sortedLowToHigh = repository.filterCars(
      repository.allCars,
      CarFilterState(sortBy = SortOption.PRICE_LOW_HIGH)
    )
    for (i in 0 until sortedLowToHigh.size - 1) {
      assertTrue(sortedLowToHigh[i].price <= sortedLowToHigh[i + 1].price)
    }
  }

  @Test
  fun testComparisonLimitTwo() {
    repository.clearComparison()
    repository.toggleComparison("car_1")
    repository.toggleComparison("car_2")
    assertEquals(2, repository.comparisonIds.value.size)

    // Adding 3rd car keeps 2
    repository.toggleComparison("car_3")
    assertEquals(2, repository.comparisonIds.value.size)
    assertTrue(repository.comparisonIds.value.contains("car_3"))
  }
}
