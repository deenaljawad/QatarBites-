const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
const DATABASE_ID = "ai-studio-android-pantrycr-36197675-2510-487a-83b3-574df4ae39b5";

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      databaseId: DATABASE_ID,
      rules: fs.readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8085
    }
  });
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

test("Unauthenticated user cannot read or write pantry items", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.doc("users/alice/pantryItems/item1").get());
  await assertFails(unauthDb.doc("users/alice/pantryItems/item1").set({
    name: "Olive Oil",
    category: "Pantry",
    quantity: "1 bottle",
    createdAt: new Date(),
    updatedAt: new Date()
  }));
});

test("Authenticated user can write valid pantry item", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore();
  await assertSucceeds(aliceDb.doc("users/alice/pantryItems/item1").set({
    name: "Olive Oil",
    category: "Pantry",
    quantity: "1 bottle",
    createdAt: new Date(),
    updatedAt: new Date()
  }));
});

test("Authenticated user Bob cannot access Alice's data", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore();
  await aliceDb.doc("users/alice/pantryItems/item1").set({
    name: "Olive Oil",
    category: "Pantry",
    quantity: "1 bottle",
    createdAt: new Date(),
    updatedAt: new Date()
  });

  const bobDb = testEnv.authenticatedContext("bob").firestore();
  await assertFails(bobDb.doc("users/alice/pantryItems/item1").get());
  await assertFails(bobDb.doc("users/alice/pantryItems/item2").set({
    name: "Butter",
    category: "Dairy",
    quantity: "200g",
    createdAt: new Date(),
    updatedAt: new Date()
  }));
});

test("User can create and update dietary profile", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore();
  await assertSucceeds(aliceDb.doc("users/alice/profile/dietary").set({
    diets: ["Keto", "High-Protein"],
    allergies: ["Peanuts"],
    dislikes: ["Cilantro"],
    calorieTarget: 2200,
    servingsPreference: 2,
    cookingTimePreference: "Under 30 mins",
    updatedAt: new Date()
  }));
});

test("User can save valid recipe, but invalid schema fails", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore();
  await assertSucceeds(aliceDb.doc("users/alice/recipes/rec1").set({
    title: "Garlic Butter Chicken",
    description: "Tender chicken breasts in a rich garlic butter sauce.",
    mealType: "Dinner",
    prepTime: 10,
    cookTime: 15,
    servings: 2,
    calories: 450,
    protein: 42,
    carbs: 4,
    fat: 28,
    ingredients: ["2 chicken breasts", "3 cloves garlic", "2 tbsp butter"],
    instructions: ["Season chicken.", "Sear in butter.", "Add garlic and simmer."],
    matchingPantryIngredients: ["Garlic", "Butter"],
    missingIngredients: ["Chicken breasts"],
    isFavorite: false,
    createdAt: new Date(),
    updatedAt: new Date()
  }));

  // Missing required fields should fail
  await assertFails(aliceDb.doc("users/alice/recipes/rec2").set({
    title: "Incomplete Recipe",
    createdAt: new Date()
  }));
});
